(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 52 ], {
    115: function(e, a, s) {
        e.exports = s.p + "assets/images/my/bill.png";
    },
    116: function(e, a, s) {
        e.exports = s.p + "assets/images/my/box.png";
    },
    117: function(e, a, s) {
        e.exports = s.p + "assets/images/my/help.png";
    },
    118: function(e, a, s) {
        e.exports = s.p + "assets/images/my/kefu.png";
    },
    119: function(e, a, s) {
        e.exports = s.p + "assets/images/my/address.png";
    },
    120: function(e, a, s) {
        e.exports = s.p + "assets/images/my/receive.png";
    },
    121: function(e, a, s) {
        e.exports = s.p + "assets/images/my/coupon.png";
    },
    122: function(e, a, s) {
        e.exports = s.p + "assets/images/my/transporter.png";
    },
    220: function(e, a, s) {
        e.exports = s.p + "assets/images/my/setting.png";
    },
    221: function(e, a, s) {},
    275: function(e, a, s) {
        "use strict";
        s.r(a);
        var n = s(7), t = s(3), c = s(2), i = s(4), o = s.n(i), l = s(1), r = s(20), u = s(5), j = s(115), d = s.n(j), b = s(116), m = s.n(b), x = s(117), g = s.n(x), p = s(118), h = s.n(p), f = s(119), O = s.n(f), w = s(120), y = s.n(w), v = (s(220), 
        s(121)), N = s.n(v), V = (s(103), s(122)), S = s.n(V), C = (s(221), s(0)), k = function() {
            var e = Object(c["useState"])({}), a = Object(t["a"])(e, 2), s = a[0], n = a[1];
            console.log(s), Object(c["useEffect"])(function() {
                Object(u["f"])(n), f();
            }, []), Object(i["useDidShow"])(function() {
                f();
            });
            var j = Object(c["useState"])({}), b = Object(t["a"])(j, 2), x = b[0], p = b[1], f = function() {
                Object(u["d"])({
                    url: "entry/wxapp/MemberInfo",
                    success: function(e) {
                        p(e);
                    }
                });
            }, w = function() {
                o.a.chooseAddress();
            };
            Object(i["useShareAppMessage"])(function() {
                var e = o.a.getStorageSync("userInfo"), a = e.uid;
                return {
                    title: s.share_title,
                    path: a ? "/pages/index/index?fuid=".concat(a) : "/pages/index/index",
                    imageUrl: "".concat(s.attachurl).concat(s.share_image)
                };
            });
            var v = function(e, a, s, n, t) {
                return Object(C["jsxs"])(l["Button"], {
                    className: "nocss-button l-item",
                    openType: t,
                    onClick: function() {
                        s && s();
                    },
                    children: [ Object(C["jsx"])(l["View"], {
                        className: "icon",
                        children: Object(C["jsx"])(l["Image"], {
                            src: a,
                            className: "icon-image"
                        })
                    }), Object(C["jsx"])(l["View"], {
                        className: "content",
                        children: e
                    }) ]
                });
            };
            return Object(C["jsxs"])(l["View"], {
                className: "my-page",
                children: [ Object(C["jsx"])(l["View"], {
                    className: "head",
                    children: Object(C["jsxs"])(l["View"], {
                        className: "head-v ",
                        children: [ Object(C["jsxs"])(l["View"], {
                            className: "info ",
                            children: [ Object(C["jsx"])(l["View"], {
                                className: "avatar",
                                children: Object(C["jsx"])(l["OpenData"], {
                                    type: "userAvatarUrl"
                                })
                            }), Object(C["jsxs"])(l["View"], {
                                className: "nickname",
                                children: [ Object(C["jsx"])(l["View"], {
                                    children: Object(C["jsx"])(l["OpenData"], {
                                        type: "userNickName"
                                    })
                                }), Object(C["jsxs"])(l["Button"], {
                                    className: "nocss-button sync-btn",
                                    children: [ "ID:", x.uid ]
                                }) ]
                            }), Object(C["jsx"])(l["View"], {
                                children: Object(C["jsx"])(l["Text"], {
                                    className: "notice iconfont icon-renwuzhongxin-kaiqixiaoxitongzhi",
                                    onClick: function() {
                                        o.a.navigateTo({
                                            url: "/pages/my/notice/index"
                                        });
                                    }
                                })
                            }) ]
                        }), Object(C["jsxs"])(l["View"], {
                            className: "myinfo b-shadow",
                            children: [ Object(C["jsxs"])(l["View"], {
                                onClick: function() {
                                    o.a.switchTab({
                                        url: "/pages/box/index"
                                    });
                                },
                                className: "col",
                                children: [ Object(C["jsx"])(l["View"], {
                                    className: "num",
                                    children: x.box_count
                                }), Object(C["jsx"])(l["View"], {
                                    children: "我的盒子"
                                }) ]
                            }), Object(C["jsxs"])(l["View"], {
                                className: "col",
                                onClick: function() {
                                    o.a.navigateTo({
                                        url: "/pages/my/withdrawal/index"
                                    });
                                },
                                children: [ Object(C["jsx"])(l["View"], {
                                    className: "num",
                                    children: void 0 !== x.user_bal ? Object(u["i"])(x.user_bal) : "-"
                                }), Object(C["jsx"])(l["View"], {
                                    children: "我的余额"
                                }) ]
                            }), Object(C["jsxs"])(l["View"], {
                                onClick: function() {
                                    o.a.navigateTo({
                                        url: "/pages/my/delivery/index?tab=0"
                                    });
                                },
                                className: "col",
                                children: [ Object(C["jsx"])(l["View"], {
                                    className: "num",
                                    children: x.delivery_status_0
                                }), Object(C["jsx"])(l["View"], {
                                    children: "待发货"
                                }) ]
                            }), Object(C["jsxs"])(l["View"], {
                                onClick: function() {
                                    o.a.navigateTo({
                                        url: "/pages/my/delivery/index?tab=1"
                                    });
                                },
                                className: "col",
                                children: [ Object(C["jsx"])(l["View"], {
                                    className: "num",
                                    children: x.delivery_status_1
                                }), Object(C["jsx"])(l["View"], {
                                    children: "待收货"
                                }) ]
                            }) ]
                        }) ]
                    })
                }), Object(C["jsx"])(l["View"], {
                    className: "mthead"
                }), Object(C["jsx"])(l["View"], {
                    className: "ad",
                    children: Object(C["jsx"])(l["Image"], {
                        className: "image",
                        mode: "widthFix",
                        onClick: function() {
                            o.a.navigateTo({
                                url: "/pages/my/invitation/index"
                            });
                        },
                        src: "".concat(s.attachurl).concat(s.spread_banner)
                    })
                }), Object(C["jsxs"])(l["View"], {
                    className: "list-muen b-shadow",
                    children: [ v("优惠券", N.a, function() {
                        o.a.navigateTo({
                            url: "/pages/my/coupons/index"
                        });
                    }), v("消费账单", d.a, function() {
                        o.a.navigateTo({
                            url: "/pages/my/bill/index?tab=2"
                        });
                    }), v("盒子订单", m.a, function() {
                        o.a.navigateTo({
                            url: "/pages/my/bill/index?tab=0"
                        });
                    }), v("回收记录", y.a, function() {
                        o.a.navigateTo({
                            url: "/pages/my/bill/index?tab=1"
                        });
                    }), v("发货管理", S.a, function() {
                        o.a.navigateTo({
                            url: "/pages/my/delivery/index?tab=0"
                        });
                    }, ""), v("我的地址", O.a, w), v("常见问题", g.a, function() {
                        o.a.navigateTo({
                            url: "/pages/my/help/index"
                        });
                    }), v("在线客服", h.a, function() {}, "", "contact") ]
                }), Object(C["jsxs"])(r["c"], {
                    className: "switch-muen",
                    hasBorder: !1,
                    children: [ Object(C["jsx"])(r["d"], {
                        title: "自动关闭弹幕",
                        isSwitch: !0,
                        switchIsCheck: o.a.getStorageSync("autoCloseDan"),
                        onSwitchChange: function(e) {
                            o.a.setStorageSync("autoCloseDan", e.detail.value);
                        },
                        switchColor: "#247fb1"
                    }), Object(C["jsx"])(r["d"], {
                        title: "自动关闭音乐",
                        hasBorder: !1,
                        isSwitch: !0,
                        switchIsCheck: o.a.getStorageSync("autoCloseMusic"),
                        onSwitchChange: function(e) {
                            o.a.setStorageSync("autoCloseMusic", e.detail.value);
                        },
                        switchColor: "#247fb1"
                    }) ]
                }), Object(C["jsx"])(l["View"], {
                    className: "version",
                    children: Object(C["jsx"])(l["View"], {
                        children: "v1.2.1"
                    })
                }) ]
            });
        }, T = k, _ = {
            navigationBarTitleText: "",
            navigationBarBackgroundColor: "#f6f6f6",
            enableShareAppMessage: !0
        };
        T.enableShareAppMessage = !0;
        Page(Object(n["createPageConfig"])(T, "pages/my/index", {
            root: {
                cn: []
            }
        }, _ || {}));
    }
}, [ [ 275, 0, 2, 1, 3 ] ] ]);