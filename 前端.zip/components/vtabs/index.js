(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 11 ], {
    259: function(t, e, a) {
        var n = a(21);
        t.exports = function(t) {
            var e = {};
            function a(n) {
                if (e[n]) return e[n].exports;
                var r = e[n] = {
                    i: n,
                    l: !1,
                    exports: {}
                };
                return t[n].call(r.exports, r, r.exports, a), r.l = !0, r.exports;
            }
            return a.m = t, a.c = e, a.d = function(t, e, n) {
                a.o(t, e) || Object.defineProperty(t, e, {
                    enumerable: !0,
                    get: n
                });
            }, a.r = function(t) {
                "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(t, "__esModule", {
                    value: !0
                });
            }, a.t = function(t, e) {
                if (1 & e && (t = a(t)), 8 & e) return t;
                if (4 & e && "object" === n(t) && t && t.__esModule) return t;
                var r = Object.create(null);
                if (a.r(r), Object.defineProperty(r, "default", {
                    enumerable: !0,
                    value: t
                }), 2 & e && "string" != typeof t) for (var i in t) a.d(r, i, function(e) {
                    return t[e];
                }.bind(null, i));
                return r;
            }, a.n = function(t) {
                var e = t && t.__esModule ? function() {
                    return t["default"];
                } : function() {
                    return t;
                };
                return a.d(e, "a", e), e;
            }, a.o = function(t, e) {
                return Object.prototype.hasOwnProperty.call(t, e);
            }, a.p = "", a(a.s = 6);
        }({
            6: function(t, e, a) {
                "use strict";
                Component({
                    options: {
                        addGlobalClass: !0,
                        pureDataPattern: /^_/,
                        multipleSlots: !0
                    },
                    properties: {
                        vtabs: {
                            type: Array,
                            value: []
                        },
                        tabBarClass: {
                            type: String,
                            value: ""
                        },
                        activeClass: {
                            type: String,
                            value: ""
                        },
                        tabBarLineColor: {
                            type: String,
                            value: "#ff0000"
                        },
                        tabBarInactiveTextColor: {
                            type: String,
                            value: "#000000"
                        },
                        tabBarActiveTextColor: {
                            type: String,
                            value: "#ff0000"
                        },
                        tabBarInactiveBgColor: {
                            type: String,
                            value: "#eeeeee"
                        },
                        tabBarActiveBgColor: {
                            type: String,
                            value: "#ffffff"
                        },
                        activeTab: {
                            type: Number,
                            value: 0
                        },
                        animation: {
                            type: Boolean,
                            value: !0
                        }
                    },
                    data: {
                        currentView: 0,
                        contentScrollTop: 0,
                        _heightRecords: [],
                        _contentHeight: {}
                    },
                    observers: {
                        activeTab: function(t) {
                            this.scrollTabBar(t);
                        }
                    },
                    relations: {
                        "../vtabs-content/index": {
                            type: "child",
                            linked: function(t) {
                                var e = this;
                                t.calcHeight(function(a) {
                                    e.data._contentHeight[t.data.tabIndex] = a.height, e._calcHeightTimer && clearTimeout(e._calcHeightTimer), 
                                    e._calcHeightTimer = setTimeout(function() {
                                        e.calcHeight();
                                    }, 100);
                                });
                            },
                            unlinked: function(t) {
                                delete this.data._contentHeight[t.data.tabIndex];
                            }
                        }
                    },
                    lifetimes: {
                        attached: function() {}
                    },
                    methods: {
                        calcHeight: function() {
                            for (var t = this.data.vtabs.length, e = this.data._contentHeight, a = [], n = 0, r = 0; r < t; r++) a[r] = n + (e[r] || 0), 
                            n = a[r];
                            this.data._heightRecords = a;
                        },
                        scrollTabBar: function(t) {
                            var e = this.data.vtabs.length;
                            if (0 !== e) {
                                var a = t < 6 ? 0 : t - 5;
                                a >= e && (a = e - 1), this.setData({
                                    currentView: a
                                });
                            }
                        },
                        handleTabClick: function(t) {
                            var e = this.data._heightRecords, a = t.currentTarget.dataset.index, n = e[a - 1] || 0;
                            this.triggerEvent("tabclick", {
                                index: a
                            }), this.setData({
                                activeTab: a,
                                contentScrollTop: n
                            });
                        },
                        handleContentScroll: function(t) {
                            var e = this.data._heightRecords;
                            if (0 !== e.length) {
                                var a = this.data.vtabs.length, n = t.detail.scrollTop, r = 0;
                                if (n >= e[0]) for (var i = 1; i < a; i++) if (n >= e[i - 1] && n < e[i]) {
                                    r = i;
                                    break;
                                }
                                r !== this.data.activeTab && (this.triggerEvent("change", {
                                    index: r
                                }), this.setData({
                                    activeTab: r
                                }));
                            }
                        }
                    }
                });
            }
        });
    }
}, [ [ 259, 0, 1 ] ] ]);