(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 20 ], {
    211: function(e, t, c) {},
    273: function(e, t, c) {
        "use strict";
        c.r(t);
        var a = c(7), s = c(3), n = c(2), i = c(4), j = c.n(i), r = c(1), l = (c(211), c(44)), b = c(5), u = c(10), o = c(9), O = c(0), x = function() {
            var e = Object(n["useState"])([]), t = Object(s["a"])(e, 2), c = t[0], a = t[1], x = Object(n["useState"])(0), d = Object(s["a"])(x, 2), h = d[0], g = d[1], p = Object(n["useState"])(0), f = Object(s["a"])(p, 2), m = f[0], w = f[1], S = Object(n["useState"])(0), V = Object(s["a"])(S, 2), v = V[0], y = V[1], N = Object(n["useState"])({}), _ = Object(s["a"])(N, 2), T = _[0], k = _[1], A = Object(n["useState"])(!0), C = Object(s["a"])(A, 2), M = C[0], B = C[1];
            Object(i["useShareAppMessage"])(function() {
                var e = j.a.getStorageSync("userInfo"), t = e.uid;
                return {
                    title: T.share_title,
                    path: t ? "/pages/index/index?fuid=".concat(t) : "/pages/index/index",
                    imageUrl: "".concat(T.attachurl).concat(T.share_image)
                };
            }), Object(i["useDidShow"])(function() {
                M || J();
            }), Object(n["useEffect"])(function() {
                Object(b["f"])(k), J();
            }, []);
            var J = function() {
                Object(b["d"])({
                    url: "entry/wxapp/UserBoxList",
                    data: {},
                    success: function(e) {
                        a(e.list), g(e.box_count), w(e.delivery_status_0), y(e.delivery_status_1), setTimeout(function() {
                            B(!1);
                        }, 300);
                    }
                });
            };
            return Object(O["jsx"])(r["View"], {
                className: "box-page",
                children: M ? Object(O["jsx"])(o["a"], {
                    iconStyle: {
                        color: "rgba(0,0,0,0.4)"
                    },
                    style: {
                        minHeight: "100vh"
                    }
                }) : Object(O["jsxs"])(r["View"], {
                    children: [ Object(O["jsxs"])(r["View"], {
                        className: "header",
                        children: [ Object(O["jsxs"])(r["View"], {
                            className: "col",
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "num",
                                children: h
                            }), Object(O["jsx"])(r["View"], {
                                children: "我的"
                            }) ]
                        }), Object(O["jsxs"])(r["View"], {
                            className: "col",
                            onClick: function() {
                                j.a.navigateTo({
                                    url: "/pages/my/delivery/index?tab=0"
                                });
                            },
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "num",
                                children: m
                            }), Object(O["jsx"])(r["View"], {
                                children: "待发货"
                            }) ]
                        }), Object(O["jsxs"])(r["View"], {
                            className: "col",
                            onClick: function() {
                                j.a.navigateTo({
                                    url: "/pages/my/delivery/index?tab=1"
                                });
                            },
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "num",
                                children: v
                            }), Object(O["jsx"])(r["View"], {
                                children: "待收货"
                            }) ]
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        children: [ 0 == c.length ? Object(O["jsx"])(u["a"], {
                            style: {
                                height: "400px"
                            }
                        }) : null, c.map(function(e, t) {
                            return Object(O["jsx"])(l["a"], {
                                config: T,
                                item: e
                            }, t);
                        }) ]
                    }) ]
                })
            });
        }, d = x, h = {
            navigationBarTitleText: "我的盒柜",
            enableShareAppMessage: !0
        };
        d.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(d, "pages/box/index", {
            root: {
                cn: []
            }
        }, h || {}));
    }
}, [ [ 273, 0, 2, 1, 3 ] ] ]);