(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 24 ], {
    240: function(e, t, a) {},
    288: function(e, t, a) {
        "use strict";
        a.r(t);
        var c = a(7), n = a(3), i = a(2), s = a(4), o = a.n(s), r = a(1), b = (a(240), a(5)), l = a(0), j = function() {
            var e = Object(i["useState"])([]), t = Object(n["a"])(e, 2), a = t[0], c = t[1], s = Object(i["useState"])(0), j = Object(n["a"])(s, 2), u = j[0], f = j[1], m = Object(i["useState"])({}), g = Object(n["a"])(m, 2), d = g[0], x = g[1];
            Object(i["useEffect"])(function() {
                Object(b["f"])(x), p();
            }, []);
            var p = function() {
                Object(b["d"])({
                    url: "entry/wxapp/Category",
                    success: function(e) {
                        c(e);
                    }
                });
            }, O = a.map(function(e) {
                return {
                    title: e.name,
                    icon: "".concat(d.attachurl).concat(e.image)
                };
            });
            return Object(l["jsx"])(r["View"], {
                className: "category-page",
                children: Object(l["jsx"])("mp-vtabs", {
                    vtabs: O,
                    activeTab: u,
                    tabBarInactiveBgColor: "#f5f5f9",
                    tabBarActiveBgColor: "#ffffff",
                    onChange: function(e) {
                        f(e.detail.index);
                    },
                    children: a && a.map(function(e, t) {
                        return Object(l["jsx"])("mp-vtabs-content", {
                            tabIndex: t,
                            children: Object(l["jsxs"])(l["Fragment"], {
                                children: [ Object(l["jsx"])(r["View"], {
                                    className: "c-title",
                                    children: e.name
                                }), Object(l["jsx"])(r["View"], {
                                    className: "cateicons",
                                    children: e.chlidren.map(function(e, t) {
                                        return Object(l["jsxs"])(r["View"], {
                                            className: "icon-cate",
                                            onClick: function() {
                                                o.a.navigateTo({
                                                    url: "/pages/category/details/index?cid=".concat(e.id)
                                                });
                                            },
                                            children: [ Object(l["jsx"])(r["View"], {
                                                className: "image-v",
                                                children: Object(l["jsx"])(r["Image"], {
                                                    className: "image",
                                                    mode: "widthFix",
                                                    src: "".concat(d.attachurl).concat(e.image)
                                                })
                                            }), Object(l["jsx"])(r["View"], {
                                                className: "title-v",
                                                children: e.name
                                            }) ]
                                        }, t);
                                    })
                                }) ]
                            })
                        });
                    })
                })
            });
        }, u = j, f = {
            navigationBarTitleText: "分类",
            navigationBarTextStyle: "black",
            navigationBarBackgroundColor: "#f5f5f9",
            usingComponents: {
                "mp-vtabs": "../../components/vtabs/index",
                "mp-vtabs-content": "../../components/vtabs-content/index"
            }
        };
        Page(Object(c["createPageConfig"])(u, "pages/category/index", {
            root: {
                cn: []
            }
        }, f || {}));
    }
}, [ [ 288, 0, 2, 1, 3 ] ] ]);