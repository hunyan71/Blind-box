(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 22 ], {
    241: function(e, t, a) {},
    289: function(e, t, a) {
        "use strict";
        a.r(t);
        var c = a(7), n = a(3), i = a(2), s = a(4), o = a(1), r = (a(241), a(5)), b = a(63), g = a(0), j = function() {
            var e = Object(i["useState"])({}), t = Object(n["a"])(e, 2), a = t[0], c = t[1], j = Object(s["useRouter"])(), u = j.params;
            return Object(i["useEffect"])(function() {
                Object(r["f"])(c);
            }, []), Object(g["jsx"])(o["View"], {
                className: "category-details-page",
                children: Object(g["jsx"])(o["View"], {
                    className: "index-page",
                    children: Object(g["jsx"])(b["a"], {
                        categoryId: u.cid,
                        show: !0,
                        config: a,
                        showSort: !0
                    })
                })
            });
        }, u = j, f = {
            navigationBarTitleText: "分类详情",
            navigationBarTextStyle: "black"
        };
        Page(Object(c["createPageConfig"])(u, "pages/category/details/index", {
            root: {
                cn: []
            }
        }, f || {}));
    }
}, [ [ 289, 0, 2, 1, 3 ] ] ]);