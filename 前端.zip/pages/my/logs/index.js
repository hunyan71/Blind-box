(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 56 ], {
    123: function(e, t, c) {
        e.exports = c.p + "assets/lq.png";
    },
    228: function(e, t, c) {},
    229: function(e, t, c) {},
    271: function(e, t, c) {
        "use strict";
        c.r(t);
        var a = c(7), s = c(3), n = c(2), i = c.n(n), o = c(4), l = c.n(o), r = c(1), j = (c(228), 
        c(5)), u = c(9), b = c(10), d = c(16), O = (c(229), c(0)), h = function(e) {
            var t = e.data, c = void 0 === t ? {} : t, a = e.onClose, s = void 0 === a ? function() {} : a, n = function() {
                l.a.downloadFile({
                    url: c.get_code,
                    success: function(e) {
                        200 === e.statusCode && l.a.saveImageToPhotosAlbum({
                            filePath: e.tempFilePath,
                            success: function() {
                                l.a.showToast({
                                    title: "保存成功",
                                    icon: "none"
                                });
                            },
                            fail: function() {
                                l.a.showModal({
                                    title: "提示",
                                    content: "保存失败",
                                    showCancel: !1
                                });
                            }
                        });
                    }
                });
            }, i = function() {
                l.a.setClipboardData({
                    data: c.get_code,
                    success: function() {
                        l.a.showToast({
                            title: "复制成功",
                            icon: "none"
                        });
                    },
                    fail: function() {
                        l.a.showModal({
                            title: "提示",
                            content: "复制失败",
                            showCancel: !1
                        });
                    }
                });
            }, o = function() {
                return Object(O["jsxs"])(r["View"], {
                    className: "add-f",
                    children: [ Object(O["jsx"])(r["View"], {
                        children: "添加好友后领取"
                    }), Object(O["jsx"])(r["Image"], {
                        className: "qrcode",
                        src: c.get_code,
                        mode: "widthFix"
                    }), Object(O["jsx"])(r["Button"], {
                        className: "nocss-button du_btn",
                        style: {
                            width: "80%"
                        },
                        onClick: n,
                        children: "保存二维码到相册"
                    }) ]
                });
            }, j = function() {
                return Object(O["jsxs"])(r["View"], {
                    className: "add-f",
                    children: [ Object(O["jsx"])(r["View"], {
                        children: "兑换码"
                    }), Object(O["jsx"])(r["View"], {
                        className: "code",
                        children: Object(O["jsx"])(r["Text"], {
                            children: c.get_code
                        })
                    }), Object(O["jsx"])(r["Button"], {
                        className: "nocss-button du_btn",
                        style: {
                            width: "80%"
                        },
                        onClick: i,
                        children: "复制兑换码"
                    }), Object(O["jsx"])(r["View"], {
                        className: "desc",
                        style: {
                            marginTop: 10
                        },
                        children: "使用方法请查看活动说明"
                    }) ]
                });
            };
            return Object(O["jsx"])(r["View"], {
                className: "get-com",
                children: Object(O["jsx"])(d["a"], {
                    title: "领取记录",
                    onClose: s,
                    children: Object(O["jsxs"])(O["Fragment"], {
                        children: [ 2 == c.get_type ? o() : null, 1 == c.get_type || 3 == c.get_type ? j() : null ]
                    })
                })
            });
        }, m = i.a.memo(h), g = c(123), x = c.n(g), f = function() {
            var e = Object(n["useState"])(-1), t = Object(s["a"])(e, 2), c = t[0], a = t[1], i = Object(n["useState"])({}), d = Object(s["a"])(i, 2), h = d[0], g = d[1], f = [ "盒子物品", "幸运盒子", "集卡兑换" ], p = Object(o["useRouter"])(), w = Object(n["useState"])(!0), N = Object(s["a"])(w, 2), V = N[0], _ = N[1], S = Object(n["useState"])(!1), y = Object(s["a"])(S, 2), v = y[0], C = y[1], T = Object(n["useState"])([]), I = Object(s["a"])(T, 2), k = I[0], B = I[1], F = Object(n["useState"])(0), M = Object(s["a"])(F, 2), P = (M[0], 
            M[1]), A = Object(n["useState"])(1), q = Object(s["a"])(A, 2), E = q[0], J = q[1], R = Object(n["useState"])(0), D = Object(s["a"])(R, 2), L = D[0], U = D[1], z = Object(n["useState"])(-1), G = Object(s["a"])(z, 2), H = (G[0], 
            G[1], Object(n["useState"])(!1)), K = Object(s["a"])(H, 2), Q = K[0], W = K[1];
            Object(n["useEffect"])(function() {
                Object(j["f"])(function(e) {
                    g(e), a(p.params.tab ? p.params.tab : 0);
                });
            }, []), Object(n["useEffect"])(function() {
                B([]), X(1), l.a.setNavigationBarTitle({
                    title: f[c] + "的领取记录"
                });
            }, [ c ]), Object(o["useReachBottom"])(function() {
                X();
            }), Object(o["useShareAppMessage"])(function() {
                var e = l.a.getStorageSync("userInfo"), t = e.uid;
                return {
                    title: h.share_title,
                    path: t ? "/pages/index/index?fuid=".concat(t) : "/pages/index/index",
                    imageUrl: "".concat(h.attachurl).concat(h.share_image)
                };
            });
            var X = function(e) {
                if (!e && L >= E) return !1;
                C(!0), Object(j["d"])({
                    url: "entry/wxapp/Logs",
                    data: {
                        page: e || parseInt(L) + 1,
                        type: parseInt(c) + 1,
                        box_id: p.params.box_id
                    },
                    success: function(e) {
                        var t = e.current_page, c = e.list, a = e.total, s = e.total_page;
                        B(1 == t ? c : k.concat(c)), P(a), J(s), U(t), C(!1), V && _(!1);
                    }
                });
            }, Y = function(e, t) {
                return Object(O["jsxs"])(r["View"], {
                    className: "order-item",
                    children: [ Object(O["jsxs"])(r["View"], {
                        className: "order-content",
                        children: [ Object(O["jsx"])(r["Image"], {
                            src: "".concat(h.attachurl).concat(e.item_image),
                            className: "item-image"
                        }), Object(O["jsxs"])(r["View"], {
                            className: "pay-info",
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "info",
                                children: Object(O["jsxs"])(r["View"], {
                                    className: "desc",
                                    children: [ e.item_name, Object(O["jsx"])(r["View"], {
                                        style: {
                                            color: "rgba(0,0,0,0.5)"
                                        },
                                        children: e.item_desc
                                    }) ]
                                })
                            }), Object(O["jsx"])(r["View"], {
                                className: "right-price",
                                children: Object(O["jsx"])(r["View"], {
                                    className: "right ",
                                    onClick: function() {
                                        return W(e);
                                    },
                                    children: "查看领取内容"
                                })
                            }) ]
                        }), Object(O["jsx"])(r["Image"], {
                            src: x.a,
                            className: "hexiaoimage"
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        className: "pay-time",
                        children: [ "操作时间:", e.updated_at ]
                    }) ]
                }, t);
            };
            return Object(O["jsxs"])(O["Fragment"], {
                children: [ Object(O["jsx"])(r["View"], {
                    className: "logs-order-page",
                    children: Object(O["jsxs"])(r["View"], {
                        className: "content",
                        children: [ V ? Object(O["jsx"])(u["a"], {
                            iconStyle: {
                                color: "rgba(0,0,0,0.5)"
                            }
                        }) : k.map(Y), k.length > 0 && !V && L >= E ? Object(O["jsx"])(r["View"], {
                            className: "footer-desc",
                            children: "已经到底拉~"
                        }) : null, 0 != k.length || V ? null : Object(O["jsx"])(b["a"], {
                            title: "没有领取记录哦~"
                        }), !V && v ? Object(O["jsx"])(u["a"], {
                            style: {
                                height: "40px"
                            },
                            iconStyle: {
                                color: "rgba(0,0,0,0.5)"
                            }
                        }) : null ]
                    })
                }), Q ? Object(O["jsx"])(m, {
                    data: Q,
                    onClose: function() {
                        return W(!1);
                    }
                }) : null ]
            });
        }, p = f, w = {
            navigationBarTitleText: "领取记录",
            enableShareAppMessage: !0
        };
        p.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(p, "pages/my/logs/index", {
            root: {
                cn: []
            }
        }, w || {}));
    }
}, [ [ 271, 0, 2, 1, 3 ] ] ]);