(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 46 ], {
    233: function(e, t, a) {},
    282: function(e, t, a) {
        "use strict";
        a.r(t);
        var c = a(7), s = a(3), n = a(2), i = a(4), r = a.n(i), j = a(1), b = (a(233), a(5)), l = a(9), o = a(10), u = a(78), O = a.n(u), g = a(0), m = function() {
            var e = Object(n["useState"])(-1), t = Object(s["a"])(e, 2), a = t[0], c = t[1], u = Object(n["useState"])({}), m = Object(s["a"])(u, 2), p = m[0], d = m[1], x = [ "盒子物品", "幸运盒子", "集卡兑换" ], h = Object(i["useRouter"])(), f = Object(n["useState"])(!0), S = Object(s["a"])(f, 2), w = S[0], N = S[1], V = Object(n["useState"])(!1), y = Object(s["a"])(V, 2), _ = y[0], v = y[1], I = Object(n["useState"])([]), A = Object(s["a"])(I, 2), B = A[0], M = A[1], T = Object(n["useState"])(0), k = Object(s["a"])(T, 2), E = (k[0], 
            k[1]), J = Object(n["useState"])(1), P = Object(s["a"])(J, 2), R = P[0], C = P[1], F = Object(n["useState"])(0), H = Object(s["a"])(F, 2), L = H[0], U = H[1], q = Object(n["useState"])(-1), z = Object(s["a"])(q, 2), D = (z[0], 
            z[1], Object(n["useState"])(!1)), G = Object(s["a"])(D, 2);
            G[0], G[1];
            Object(n["useEffect"])(function() {
                Object(b["f"])(function(e) {
                    d(e), c(h.params.tab ? h.params.tab : 0);
                });
            }, []), Object(n["useEffect"])(function() {
                M([]), K(1), r.a.setNavigationBarTitle({
                    title: x[a] + "的核销记录"
                });
            }, [ a ]), Object(i["useReachBottom"])(function() {
                K();
            }), Object(i["useShareAppMessage"])(function() {
                var e = r.a.getStorageSync("userInfo"), t = e.uid;
                return {
                    title: p.share_title,
                    path: t ? "/pages/index/index?fuid=".concat(t) : "/pages/index/index",
                    imageUrl: "".concat(p.attachurl).concat(p.share_image)
                };
            });
            var K = function(e) {
                if (!e && L >= R) return !1;
                v(!0), Object(b["d"])({
                    url: "entry/wxapp/HeLogs",
                    data: {
                        page: e || parseInt(L) + 1,
                        type: parseInt(a) + 1,
                        box_id: h.params.box_id
                    },
                    success: function(e) {
                        var t = e.current_page, a = e.list, c = e.total, s = e.total_page;
                        M(1 == t ? a : B.concat(a)), E(c), C(s), U(t), v(!1), w && N(!1);
                    }
                });
            }, Q = function(e, t) {
                return Object(g["jsxs"])(j["View"], {
                    className: "order-item",
                    children: [ Object(g["jsxs"])(j["View"], {
                        className: "order-content",
                        children: [ Object(g["jsx"])(j["Image"], {
                            src: "".concat(p.attachurl).concat(e.item_image),
                            className: "item-image"
                        }), Object(g["jsxs"])(j["View"], {
                            className: "pay-info",
                            children: [ Object(g["jsx"])(j["View"], {
                                className: "info",
                                children: Object(g["jsxs"])(j["View"], {
                                    className: "desc",
                                    children: [ e.item_name, Object(g["jsx"])(j["View"], {
                                        style: {
                                            color: "rgba(0,0,0,0.5)"
                                        },
                                        children: e.item_desc
                                    }) ]
                                })
                            }), Object(g["jsx"])(j["View"], {
                                className: "right-price",
                                children: Object(g["jsx"])(j["Image"], {
                                    src: O.a,
                                    className: "hexiaoimage"
                                })
                            }) ]
                        }) ]
                    }), Object(g["jsxs"])(j["View"], {
                        className: "pay-time",
                        children: [ "操作时间:", e.updated_at ]
                    }) ]
                }, t);
            };
            return Object(g["jsx"])(g["Fragment"], {
                children: Object(g["jsx"])(j["View"], {
                    className: "logs-order-page",
                    children: Object(g["jsxs"])(j["View"], {
                        className: "content",
                        children: [ w ? Object(g["jsx"])(l["a"], {
                            iconStyle: {
                                color: "rgba(0,0,0,0.5)"
                            }
                        }) : B.map(Q), B.length > 0 && !w && L >= R ? Object(g["jsx"])(j["View"], {
                            className: "footer-desc",
                            children: "已经到底拉~"
                        }) : null, 0 != B.length || w ? null : Object(g["jsx"])(o["a"], {
                            title: "没有核销记录哦~"
                        }), !w && _ ? Object(g["jsx"])(l["a"], {
                            style: {
                                height: "40px"
                            },
                            iconStyle: {
                                color: "rgba(0,0,0,0.5)"
                            }
                        }) : null ]
                    })
                })
            });
        }, p = m, d = {
            navigationBarTitleText: "领取记录",
            enableShareAppMessage: !0
        };
        p.enableShareAppMessage = !0;
        Page(Object(c["createPageConfig"])(p, "pages/my/helogs/index", {
            root: {
                cn: []
            }
        }, d || {}));
    }
}, [ [ 282, 0, 2, 1, 3 ] ] ]);