(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 58 ], {
    225: function(e, t, c) {},
    278: function(e, t, c) {
        "use strict";
        c.r(t);
        var n = c(7), i = c(3), s = c(2), a = (c(4), c(1)), r = (c(225), c(5)), o = c(0), j = function() {
            var e = Object(s["useState"])([]), t = Object(i["a"])(e, 2), c = t[0], n = t[1];
            Object(s["useEffect"])(function() {
                j();
            }, []);
            var j = function() {
                Object(r["d"])({
                    url: "entry/wxapp/NoticeList",
                    success: function(e) {
                        n(e);
                    }
                });
            };
            return Object(o["jsx"])(a["View"], {
                className: "notice-page",
                children: c.map(function(e, t) {
                    return Object(o["jsxs"])(a["View"], {
                        className: "notice-row",
                        children: [ Object(o["jsxs"])(a["View"], {
                            className: "notice-title",
                            children: [ Object(o["jsx"])(a["View"], {
                                className: "tt",
                                children: e.title
                            }), Object(o["jsx"])(a["View"], {
                                children: e.created_at
                            }) ]
                        }), Object(o["jsx"])(a["View"], {
                            className: "notice-text",
                            children: e.text
                        }) ]
                    }, t);
                })
            });
        }, l = j, u = {
            navigationBarTitleText: "系统通知"
        };
        Page(Object(n["createPageConfig"])(l, "pages/my/notice/index", {
            root: {
                cn: []
            }
        }, u || {}));
    }
}, [ [ 278, 0, 2, 1, 3 ] ] ]);