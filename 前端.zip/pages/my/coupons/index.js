(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 42 ], {
    234: function(e, t, c) {},
    283: function(e, t, c) {
        "use strict";
        c.r(t);
        var a = c(7), s = c(3), n = c(2), i = c(4), l = c.n(i), r = c(1), j = (c(234), c(5)), o = c(9), u = c(10), b = (c(78), 
        c(0)), O = function() {
            var e = Object(n["useState"])({}), t = Object(s["a"])(e, 2), c = t[0], a = t[1], O = Object(n["useState"])(!0), p = Object(s["a"])(O, 2), d = p[0], x = p[1], h = Object(n["useState"])(!1), g = Object(s["a"])(h, 2), m = g[0], f = g[1], w = Object(n["useState"])([]), S = Object(s["a"])(w, 2), N = S[0], V = S[1], v = Object(n["useState"])(0), y = Object(s["a"])(v, 2), _ = (y[0], 
            y[1]), A = Object(n["useState"])(1), M = Object(s["a"])(A, 2), T = M[0], k = M[1], B = Object(n["useState"])(0), C = Object(s["a"])(B, 2), I = C[0], J = C[1];
            Object(n["useEffect"])(function() {
                Object(j["f"])(function(e) {
                    a(e);
                }), P();
            }, []);
            var P = function(e) {
                if (!e && I >= T) return !1;
                f(!0), Object(j["d"])({
                    url: "entry/wxapp/Coupons",
                    data: {
                        page: e || parseInt(I) + 1
                    },
                    success: function(e) {
                        var t = e.current_page, c = e.list, a = e.total, s = e.total_page;
                        console.log(t, c, a, s), V(1 == t ? c : N.concat(c)), _(a), k(s), J(t), f(!1), d && x(!1);
                    }
                });
            };
            Object(i["useReachBottom"])(function() {}), Object(i["useShareAppMessage"])(function() {
                var e = l.a.getStorageSync("userInfo"), t = e.uid;
                return {
                    title: c.share_title,
                    path: t ? "/pages/index/index?fuid=".concat(t) : "/pages/index/index",
                    imageUrl: "".concat(c.attachurl).concat(c.share_image)
                };
            });
            var E = function(e, t) {
                return Object(b["jsxs"])(r["View"], {
                    className: "coupon ".concat(0 == e.status ? "" : "coupon_disabled"),
                    children: [ Object(b["jsxs"])(r["View"], {
                        className: "c-left",
                        children: [ Object(b["jsx"])(r["View"], {
                            className: "desc",
                            children: 0 == e.limit ? "无门槛" : "满".concat(Object(j["i"])(e.limit), "元可用")
                        }), Object(b["jsxs"])(r["View"], {
                            className: "ppr",
                            children: [ Object(b["jsx"])(r["Text"], {
                                className: "yuan",
                                children: "¥"
                            }), Object(j["i"])(e.price) ]
                        }) ]
                    }), Object(b["jsxs"])(r["View"], {
                        className: "c-right",
                        children: [ Object(b["jsx"])(r["View"], {
                            className: "title",
                            children: e.name
                        }), 0 == e.status ? Object(b["jsxs"])(r["View"], {
                            className: "desc",
                            children: [ "有效期至 ", -1 == e.expr ? "永不过期" : e.expr ]
                        }) : null, 2 == e.status ? Object(b["jsx"])(r["View"], {
                            className: "desc",
                            children: "已使用"
                        }) : null, 3 == e.status ? Object(b["jsx"])(r["View"], {
                            className: "desc",
                            children: "已过期"
                        }) : null ]
                    }) ]
                }, t);
            };
            return Object(b["jsx"])(r["View"], {
                className: "logs-order-page",
                children: Object(b["jsxs"])(r["View"], {
                    className: "content",
                    children: [ d ? Object(b["jsx"])(o["a"], {
                        iconStyle: {
                            color: "rgba(0,0,0,0.5)"
                        }
                    }) : N.map(E), N.length > 0 && !d && I >= T ? Object(b["jsx"])(r["View"], {
                        className: "footer-desc",
                        children: "已经到底拉~"
                    }) : null, 0 != N.length || d ? null : Object(b["jsx"])(u["a"], {
                        title: "暂无优惠券"
                    }), !d && m ? Object(b["jsx"])(o["a"], {
                        style: {
                            height: "40px"
                        },
                        iconStyle: {
                            color: "rgba(0,0,0,0.5)"
                        }
                    }) : null ]
                })
            });
        }, p = O, d = {
            navigationBarTitleText: "我的优惠券",
            enableShareAppMessage: !0
        };
        p.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(p, "pages/my/coupons/index", {
            root: {
                cn: []
            }
        }, d || {}));
    }
}, [ [ 283, 0, 2, 1, 3 ] ] ]);