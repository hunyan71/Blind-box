(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 54 ], {
    232: function(e, c, t) {},
    281: function(e, c, t) {
        "use strict";
        t.r(c);
        var a = t(7), s = t(3), n = t(2), i = t(4), l = t.n(i), r = t(1), j = (t(232), t(14)), o = t(10), d = t(30), b = t(5), x = t(15), h = t(0), O = function() {
            var e = Object(n["useState"])({}), c = Object(s["a"])(e, 2), t = c[0], a = c[1], O = Object(n["useState"])({}), u = Object(s["a"])(O, 2), m = u[0], p = u[1], w = Object(n["useState"])({
                coupon_data: {},
                count: 0,
                spread_level_1: 0,
                spread_level_2: 0,
                price_level_1: 0,
                price_level_2: 0,
                team: []
            }), g = Object(s["a"])(w, 2), V = g[0], N = g[1];
            Object(i["useShareAppMessage"])(function() {
                var e = l.a.getStorageSync("userInfo"), c = e.uid;
                return console.log({
                    title: m.share_title,
                    path: c ? "/pages/index/index?fuid=".concat(c) : "/pages/index/index",
                    imageUrl: "".concat(m.attachurl).concat(m.share_image)
                }), {
                    title: m.share_title,
                    path: c ? "/pages/index/index?fuid=".concat(c) : "/pages/index/index",
                    imageUrl: "".concat(m.attachurl).concat(m.share_image)
                };
            }), Object(n["useEffect"])(function() {
                Object(b["f"])(function(e) {
                    p(e);
                }), a(Object(x["a"])()), _();
            }, []);
            var _ = function() {
                Object(b["d"])({
                    url: "entry/wxapp/InvitationData",
                    success: function(e) {
                        console.log(e), N(e);
                    }
                });
            };
            return Object(h["jsxs"])(r["View"], {
                className: "invitation-page",
                style: {
                    backgroundImage: "url(".concat(m.attachurl).concat(m.invitation_top_image, ")")
                },
                children: [ Object(h["jsx"])(r["View"], {
                    class: "header-bar",
                    style: {
                        paddingTop: "".concat(t.paddingTop, "px")
                    },
                    children: Object(h["jsx"])(d["a"], {
                        safeArea: t,
                        pageConfig: {}
                    })
                }), Object(h["jsx"])(r["View"], {
                    className: "box",
                    style: {
                        backgroundColor: "transparent"
                    },
                    children: Object(h["jsxs"])(r["View"], {
                        className: "content yaoqing",
                        children: [ Object(h["jsx"])(r["Text"], {
                            children: "邀请好友得 现金抵用券"
                        }), Object(h["jsxs"])(r["View"], {
                            className: "coupon coupon22",
                            children: [ Object(h["jsxs"])(r["View"], {
                                className: "c-left",
                                children: [ Object(h["jsx"])(r["View"], {
                                    className: "desc2",
                                    children: 0 == V.coupon_data.limit ? "无门槛" : "满".concat(Object(b["i"])(V.coupon_data.limit), "元可用")
                                }), Object(h["jsxs"])(r["View"], {
                                    className: "ppr",
                                    children: [ Object(h["jsx"])(r["Text"], {
                                        className: "yuan",
                                        children: "¥"
                                    }), Object(b["i"])(V.coupon_data.price) ]
                                }) ]
                            }), Object(h["jsxs"])(r["View"], {
                                className: "c-right",
                                children: [ Object(h["jsx"])(r["View"], {
                                    className: "title2",
                                    children: V.coupon_data.name
                                }), Object(h["jsxs"])(r["View"], {
                                    className: "desc2",
                                    children: [ "有效期至 ", V.coupon_data.expr ]
                                }) ]
                            }) ]
                        }), Object(h["jsx"])(j["a"], {
                            className: "du_btn nocss-button",
                            openType: "share",
                            children: "立即邀请"
                        }) ]
                    })
                }), Object(h["jsxs"])(r["View"], {
                    className: "box",
                    children: [ Object(h["jsx"])(r["View"], {
                        className: "title",
                        children: "我的团队"
                    }), Object(h["jsx"])(r["View"], {
                        className: "content",
                        children: Object(h["jsxs"])(r["View"], {
                            className: "myinfo b-shadow",
                            children: [ Object(h["jsxs"])(r["View"], {
                                className: "col",
                                children: [ Object(h["jsx"])(r["View"], {
                                    className: "num",
                                    children: V.count
                                }), Object(h["jsx"])(r["View"], {
                                    children: "邀请总人数"
                                }) ]
                            }), Object(h["jsxs"])(r["View"], {
                                className: "col",
                                children: [ Object(h["jsx"])(r["View"], {
                                    className: "num",
                                    children: Object(b["i"])(V.price_level_1)
                                }), Object(h["jsx"])(r["View"], {
                                    children: "一级收益"
                                }) ]
                            }), Object(h["jsxs"])(r["View"], {
                                className: "col ",
                                style: {
                                    borderRight: "0"
                                },
                                children: [ Object(h["jsx"])(r["View"], {
                                    className: "num",
                                    children: Object(b["i"])(V.price_level_2)
                                }), Object(h["jsx"])(r["View"], {
                                    children: "二级收益"
                                }) ]
                            }) ]
                        })
                    }) ]
                }), Object(h["jsxs"])(r["View"], {
                    className: "box",
                    children: [ Object(h["jsx"])(r["View"], {
                        className: "title",
                        children: "邀请记录"
                    }), Object(h["jsxs"])(r["View"], {
                        className: "content",
                        children: [ 0 == V.team.length ? Object(h["jsx"])(o["a"], {}) : null, V.team.map(function(e, c) {
                            return Object(h["jsxs"])(r["View"], {
                                className: "irow",
                                children: [ Object(h["jsx"])(r["Image"], {
                                    className: "irow-avatar",
                                    src: e.avatar
                                }), Object(h["jsxs"])(r["View"], {
                                    className: "irow-info",
                                    children: [ Object(h["jsx"])(r["View"], {
                                        children: e.nickname
                                    }), Object(h["jsx"])(r["View"], {
                                        className: "nk",
                                        children: e.created_at
                                    }) ]
                                }) ]
                            }, c);
                        }) ]
                    }) ]
                }), Object(h["jsx"])(r["View"], {
                    className: "box",
                    children: Object(h["jsxs"])(r["View"], {
                        className: "content",
                        children: [ Object(h["jsx"])(r["Text"], {
                            class: "rule-title",
                            style: {
                                marginTop: 0
                            },
                            children: "邀请即送："
                        }), Object(h["jsx"])(r["View"], {
                            class: "rule-content",
                            children: Object(h["jsxs"])(r["Text"], {
                                class: "rule-content-text",
                                children: [ "好友通过您的分享进入授权登录后即算邀请成功，一个成功邀请即送", V.coupon_data.name, "。" ]
                            })
                        }), Object(h["jsx"])(r["Text"], {
                            class: "rule-title",
                            children: "好友下单奖励："
                        }), Object(h["jsxs"])(r["View"], {
                            class: "rule-content",
                            children: [ Object(h["jsx"])(r["View"], {
                                class: "rule-content-text",
                                children: "好友下单奖励是好友活跃奖励系统，团队好友活跃越多自己奖励越多："
                            }), Object(h["jsx"])(r["View"], {
                                class: "rule-content-text",
                                children: "1.好友成员分成两部分：直邀好友（自己直接邀请的好友）和扩散好友（直邀好友邀请的好友）。"
                            }), Object(h["jsxs"])(r["View"], {
                                class: "rule-content-text",
                                children: [ "2.直邀好友获得代金券后您将额外获得其购买盒子金额的", V.spread_level_1, "%，扩散好友的比例为", V.spread_level_2, "%，此奖励不会和好友的利益冲突。" ]
                            }), Object(h["jsx"])(r["View"], {
                                class: "rule-content-text",
                                children: "3.任意作弊或者恶意刷返佣的行为，平台将取消其参加活动的资格，并扣除相应的奖励不予结算。"
                            }) ]
                        }) ]
                    })
                }) ]
            });
        }, u = O, m = {
            navigationBarTitleText: "邀请好友",
            navigationBarBackgroundColor: "#ffffff",
            navigationBarTextStyle: "white",
            navigationStyle: "custom",
            enableShareAppMessage: !0
        };
        u.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(u, "pages/my/invitation/index", {
            root: {
                cn: []
            }
        }, m || {}));
    }
}, [ [ 281, 0, 2, 1, 3 ] ] ]);