(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 64 ], {
    237: function(e, c, t) {},
    285: function(e, c, t) {
        "use strict";
        t.r(c);
        var a = t(7), s = t(3), n = t(2), i = t(4), r = t.n(i), l = t(1), o = (t(33), t(5)), u = (t(237), 
        t(10), t(0)), j = function() {
            var e = Object(n["useState"])([]), c = Object(s["a"])(e, 2), t = c[0], a = c[1], i = Object(n["useState"])({}), j = Object(s["a"])(i, 2), h = (j[0], 
            j[1]), b = Object(n["useState"])([]), O = Object(s["a"])(b, 2), f = O[0], g = O[1], x = Object(n["useState"])(""), d = Object(s["a"])(x, 2), p = d[0], w = d[1];
            Object(n["useEffect"])(function() {
                N(), Object(o["f"])(h), m();
            }, []), Object(n["useEffect"])(function() {
                r.a.setStorageSync("search-history", JSON.stringify(t));
            }, [ t ]);
            var m = function() {
                Object(o["d"])({
                    url: "entry/wxapp/SearchHotKey",
                    success: function(e) {
                        g(e);
                    }
                });
            }, N = function() {
                var e = r.a.getStorageSync("search-history");
                if (e) try {
                    var c = JSON.parse(e);
                    a(c);
                } catch (e) {}
            }, y = function(e) {
                if (e) {
                    var c = r.a.getStorageSync("search-history"), t = [];
                    if (c) try {
                        t = JSON.parse(c).slice(0, 10), t.unshift(e);
                    } catch (e) {} else t = [ e ];
                    a(t), w(e), r.a.navigateTo({
                        url: "/pages/search/result/index?s_key=".concat(e)
                    });
                }
            };
            return Object(u["jsxs"])(l["View"], {
                className: "search-page",
                children: [ Object(u["jsxs"])(l["View"], {
                    className: "nav_search",
                    children: [ Object(u["jsxs"])(l["View"], {
                        className: "input",
                        children: [ Object(u["jsx"])(l["Text"], {
                            className: "iconfont icon-sousuo"
                        }), Object(u["jsx"])(l["Input"], {
                            className: "input_value",
                            autoFocus: !0,
                            onConfirm: function(e) {
                                return y(e.detail.value);
                            },
                            confirmType: "search",
                            value: p,
                            placeholder: "大家都在搜索 ".concat(f[0] ? f[0].search_key : "")
                        }) ]
                    }), Object(u["jsx"])(l["View"], {
                        className: "notice",
                        onClick: function() {
                            return r.a.navigateBack();
                        },
                        children: "取消"
                    }) ]
                }), t.length > 0 ? Object(u["jsxs"])(l["View"], {
                    className: "log",
                    children: [ Object(u["jsx"])(l["View"], {
                        className: "log-title",
                        children: "历史记录"
                    }), Object(u["jsx"])(l["View"], {
                        className: "log-logs",
                        children: t.map(function(e, c) {
                            return Object(u["jsx"])(l["View"], {
                                onClick: function() {
                                    return y(e);
                                },
                                className: "log-log b-shadow",
                                children: e
                            }, c);
                        })
                    }) ]
                }) : null, f.length > 0 ? Object(u["jsxs"])(l["View"], {
                    className: "log",
                    children: [ Object(u["jsx"])(l["View"], {
                        className: "log-title",
                        children: "热门搜索"
                    }), Object(u["jsx"])(l["View"], {
                        className: "log-logs",
                        children: f.map(function(e, c) {
                            return Object(u["jsx"])(l["View"], {
                                onClick: function() {
                                    return y(e.search_key);
                                },
                                className: "log-log b-shadow",
                                children: e.search_key
                            }, c);
                        })
                    }) ]
                }) : null ]
            });
        }, h = j, b = {
            navigationBarTitleText: "搜索"
        };
        Page(Object(a["createPageConfig"])(h, "pages/search/index", {
            root: {
                cn: []
            }
        }, b || {}));
    }
}, [ [ 285, 0, 2, 1, 3 ] ] ]);