<?php
$sql="
CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_barrage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1 正常 2 审核中 3 拒绝',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_card_prize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `box_id` int(11) NOT NULL COMMENT '盲盒id',
  `type` int(11) NOT NULL COMMENT '盲盒id',
  `code` varchar(255) NOT NULL COMMENT '核销码',
  `status` int(11) DEFAULT '0' COMMENT '0 未发货 1 已发货或核销',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `delivery_order_id` int(11) DEFAULT '0' COMMENT ' 发货订单号',
  `get_type` int(11) DEFAULT '0' COMMENT ' 1 自动发码 2 固定二维码 2 固定码',
  `get_status` int(11) DEFAULT '0' COMMENT ' 1 已领取 0 未领取',
  `get_code` varchar(255) DEFAULT NULL COMMENT ' 1 虚拟 物品发货码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `uniacid` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT '0' COMMENT '上级id',
  `name` varchar(255) NOT NULL COMMENT '分类名称',
  `image` varchar(255) DEFAULT '' COMMENT '分类图片',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `is_recommend` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_commodity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1 正常盲盒 2 幸运盲盒',
  `title` varchar(255) NOT NULL COMMENT '盲盒标题',
  `category_id` int(11) NOT NULL DEFAULT '0' COMMENT '分类',
  `category_sub_id` int(11) NOT NULL DEFAULT '0' COMMENT '二级分类',
  `sub_title` varchar(255) NOT NULL COMMENT '盲盒副标题',
  `price` int(11) NOT NULL COMMENT '盲盒单价',
  `text_content` longtext COMMENT '详情图文',
  `text_rule` longtext COMMENT '规则图文',
  `cabinet_image` varchar(255) DEFAULT NULL COMMENT '盒子图片',
  `batch_num` int(11) DEFAULT NULL COMMENT '一共发送多少期',
  `batch_draw_num` int(11) DEFAULT NULL COMMENT '开奖数量 每期多少个',
  `prize_name` varchar(255) DEFAULT NULL COMMENT '奖品名称',
  `prize_image` varchar(255) DEFAULT NULL COMMENT '奖品图片',
  `prize_price` varchar(255) DEFAULT NULL COMMENT '奖品价值',
  `page_bg_color` varchar(255) DEFAULT NULL COMMENT '背景色',
  `page_bg_music` varchar(255) DEFAULT NULL COMMENT '页面背景音乐',
  `page_bg_image` varchar(255) DEFAULT NULL COMMENT '背景图片',
  `page_banner_image` varchar(255) DEFAULT NULL COMMENT '上部分跳动图片',
  `page_box_base_image` varchar(255) DEFAULT NULL COMMENT '盒子底座',
  `page_box_panel_image` varchar(255) DEFAULT NULL COMMENT '盒子前面板',
  `page_box_image` varchar(255) DEFAULT NULL COMMENT '盒子的图片',
  `page_one_box_image` varchar(255) DEFAULT NULL COMMENT '单个盒子的图片',
  `page_box_row_num` int(11) DEFAULT NULL COMMENT '盒子的大小 1 大[一排3个共9个] 2 小[一排4个共12个] ',
  `luck_image` varchar(255) DEFAULT NULL COMMENT '幸运盒子的首页图片',
  `item_image` varchar(255) DEFAULT NULL COMMENT '正常图片',
  `share_desc` varchar(255) DEFAULT NULL COMMENT '分享简介',
  `share_image` varchar(255) DEFAULT NULL COMMENT '分享图片',
  `share_title` varchar(255) DEFAULT NULL COMMENT '分享标题',
  `recommend` int(11) DEFAULT '0' COMMENT '是否推荐',
  `recommend_image` varchar(255) DEFAULT NULL COMMENT '推荐位图片',
  `dan_open` int(11) NOT NULL DEFAULT '0',
  `dan_prize_open` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '2' COMMENT '1 正常 2 待上传物品 3 下架',
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `prize_merchant_id` int(11) DEFAULT '0' COMMENT '商户id',
  `prize_ver_code` varchar(255) DEFAULT NULL COMMENT '核销码',
  `prize_ver_type` int(11) DEFAULT '1' COMMENT '核销方式',
  `prize_fahuo_tempid` int(11) DEFAULT '0' COMMENT '虚拟发货id',
  `prize_type` int(11) DEFAULT '0' COMMENT '物品类型 0 实物 1 虚拟 3 核销',
  `prize_desc` varchar(255) DEFAULT NULL COMMENT '奖品介绍',
  `merchant_id` int(11) DEFAULT '0' COMMENT '商户id',
  `ios_hidden` int(11) DEFAULT '1' COMMENT '0 ios 不显示 1 ios端显示',
  `style_type` int(11) DEFAULT '1' COMMENT '1 普通风格 2 商户风格',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_commodity_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `bid` int(11) NOT NULL COMMENT '盲盒id',
  `num` int(11) NOT NULL COMMENT '总数 0 不限制',
  `rate` float NOT NULL COMMENT '稀有度',
  `image` varchar(255) NOT NULL COMMENT '图片',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `special` int(11) NOT NULL DEFAULT '0' COMMENT '特殊款？',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `price` varchar(255) NOT NULL DEFAULT '0',
  `recovery_price` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `type` int(11) DEFAULT '0' COMMENT '物品类型 0 实物 1 虚拟 3 核销',
  `merchant_id` int(11) DEFAULT '0' COMMENT '所属商户',
  `desc` varchar(255) DEFAULT NULL COMMENT '介绍 商家模板会显示',
  `ver_code` varchar(255) DEFAULT NULL COMMENT '核销码',
  `ver_type` int(11) DEFAULT '1' COMMENT '核销方式',
  `fahuo_tempid` int(11) DEFAULT '0' COMMENT '虚拟发货id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=478 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `limit` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `is_new_user` int(11) NOT NULL DEFAULT '0',
  `use_key` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1 正常 2 已下线',
  `expr_type` int(11) NOT NULL DEFAULT '0',
  `expr_day` int(11) NOT NULL,
  `expr_time` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_coupon_user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `limit` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `is_new_user` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0 正常 2 已使用 3 过期了',
  `order_no` varchar(255) DEFAULT NULL,
  `expr_type` int(11) NOT NULL DEFAULT '0',
  `expr_day` int(11) NOT NULL,
  `expr_time` int(11) NOT NULL,
  `expr` int(11) NOT NULL,
  `use_time` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2414 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_delivery_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `out_trade_no` varchar(255) NOT NULL COMMENT '平台订单号',
  `transaction_id` varchar(255) DEFAULT NULL COMMENT '微信订单号',
  `total_price` int(11) NOT NULL,
  `wx_pay_price` int(11) NOT NULL,
  `balance_pay_price` int(11) NOT NULL,
  `ids` text NOT NULL,
  `address` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pay_status` int(11) NOT NULL DEFAULT '0',
  `pay_time` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '1',
  `remark` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 待发货 1 已发货',
  `express_number` varchar(255) DEFAULT NULL,
  `express_type` varchar(255) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_express_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `number` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `typename` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `list` text,
  `deliverystatus` int(11) DEFAULT NULL,
  `query_time` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_fictitious_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `ftid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_fictitious_tempalte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(11) DEFAULT '1',
  `qrcode` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_give_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `item_order_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `gei_uid` int(11) DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_help` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text,
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_luck_batch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `bid` int(11) NOT NULL COMMENT '盲盒id',
  `batch_no` int(11) NOT NULL COMMENT '期数',
  `stock` int(11) NOT NULL COMMENT '本期数量',
  `sold_num` int(11) NOT NULL COMMENT '已售数量',
  `status` int(11) NOT NULL COMMENT '1进行中 2已完成',
  `open_prize` int(11) NOT NULL DEFAULT '1' COMMENT '1 正常 2 待开奖 3 已开将',
  `open_time` int(11) DEFAULT NULL COMMENT '开奖时间',
  `params_a` varchar(255) DEFAULT NULL,
  `params_b` varchar(255) DEFAULT NULL,
  `params_b_time` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_luck_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `order_id` int(11) NOT NULL COMMENT '订单号',
  `box_id` int(11) NOT NULL COMMENT '盲盒id',
  `batch_no` int(11) NOT NULL COMMENT '批次',
  `order_item_id` int(11) NOT NULL COMMENT '订单物品号',
  `item_id` int(11) NOT NULL COMMENT '物品id',
  `code` varchar(255) NOT NULL COMMENT '抽奖码',
  `status` int(11) NOT NULL COMMENT '0 未开奖 1 中奖 2 未中奖',
  `is_fa` int(11) NOT NULL DEFAULT '0' COMMENT '是否发货',
  `ms_time` varchar(255) NOT NULL,
  `delivery_order_id` int(11) DEFAULT NULL COMMENT '回收订单id',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `get_type` int(11) DEFAULT '0' COMMENT ' 1 自动发码 2 固定二维码 2 固定码',
  `get_status` int(11) DEFAULT '0' COMMENT ' 1 已领取 0 未领取',
  `get_code` varchar(255) DEFAULT NULL COMMENT ' 1 虚拟 物品发货码',
  `vcode` varchar(255) DEFAULT NULL COMMENT '核销码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19834 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_merchant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `admin_uid` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_merchant_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `telphone` varchar(255) NOT NULL,
  `open_time` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text,
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `appid` varchar(255) NOT NULL,
  `mch_id` varchar(255) NOT NULL,
  `box_id` int(11) NOT NULL COMMENT '盲盒id',
  `box_type` int(11) NOT NULL COMMENT '盲盒类型',
  `out_trade_no` varchar(255) NOT NULL COMMENT '平台订单号',
  `transaction_id` varchar(255) DEFAULT NULL COMMENT '微信订单号',
  `unit_price` int(11) NOT NULL COMMENT '单价',
  `total_price` int(11) NOT NULL COMMENT '总价',
  `wxpay_price` int(11) NOT NULL COMMENT '微信支付金额',
  `balance_price` int(11) NOT NULL COMMENT '余额支付金额',
  `pay_status` int(11) NOT NULL COMMENT '支付状态，1 已支付 2 未支付',
  `pay_time` int(11) NOT NULL COMMENT '付款时间',
  `luck_order_time` varchar(255) NOT NULL COMMENT '毫秒时间戳',
  `buy_num` int(11) NOT NULL DEFAULT '1',
  `extract_status` int(11) NOT NULL DEFAULT '0' COMMENT '1 已抽物品 0 未抽取 2 异常',
  `extract_success` int(11) NOT NULL DEFAULT '0' COMMENT '发放成功数量',
  `extract_code_success` int(11) NOT NULL DEFAULT '0' COMMENT '发放成功数量',
  `preferential_price` int(11) NOT NULL DEFAULT '0' COMMENT '优惠金额',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `preferential_id` int(11) DEFAULT '0' COMMENT '优惠券id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=691 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `order_id` int(11) NOT NULL COMMENT '订单id',
  `box_id` int(11) NOT NULL COMMENT '盲盒id',
  `item_id` int(11) NOT NULL COMMENT '物品id',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1 正常 2 回收 3 发货',
  `recovery_order_id` int(11) DEFAULT NULL COMMENT '回收订单id',
  `delivery_order_id` int(11) DEFAULT NULL COMMENT '回收订单id',
  `recovery_transaction_price` int(11) DEFAULT NULL COMMENT '回收成交价格',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `he_status` int(11) DEFAULT '0' COMMENT '1 核销了 0 未核销',
  `exchange_card_order_id` int(11) DEFAULT NULL COMMENT '兑换订单id',
  `type` int(11) DEFAULT '0' COMMENT '物品类型 0 实物 1 虚拟 3 核销',
  `code` varchar(255) DEFAULT NULL COMMENT '核销码',
  `get_type` int(11) DEFAULT '0' COMMENT ' 1 自动发码 2 固定二维码 2 固定码',
  `get_status` int(11) DEFAULT '0' COMMENT ' 1 已领取 0 未领取',
  `get_code` varchar(255) DEFAULT NULL COMMENT ' 1 虚拟 物品发货码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20286 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_recommende_icon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `jump_type` int(11) NOT NULL DEFAULT '0',
  `jump_path` varchar(255) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `jump_appid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_recommende_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `top` int(11) NOT NULL DEFAULT '0',
  `jump_type` int(11) NOT NULL DEFAULT '0',
  `jump_path` varchar(255) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `jump_appid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_recovery_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `order_no` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `count_num` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_search_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `search_key` varchar(255) NOT NULL,
  `num` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `app_logo_a` varchar(255) NOT NULL COMMENT '淡色Logo',
  `app_logo_b` varchar(255) NOT NULL COMMENT '深色Logo',
  `delevery_price` int(11) NOT NULL COMMENT '发货运费',
  `delevery_api_appcode` varchar(255) DEFAULT NULL,
  `home_style` int(11) NOT NULL DEFAULT '1' COMMENT '1 简约版 2 电商版',
  `spread_coupon_id` int(11) DEFAULT '0',
  `new_user_coupon_image` varchar(255) DEFAULT NULL,
  `recommend_icon` varchar(255) DEFAULT NULL,
  `submsg_open` varchar(255) DEFAULT NULL COMMENT '订阅消息ID 开奖提醒',
  `submsg_1` varchar(255) DEFAULT NULL COMMENT '订阅消息ID 活动提醒1',
  `submsg_2` varchar(255) DEFAULT NULL COMMENT '订阅消息ID 活动提醒2',
  `submsg_3` varchar(255) DEFAULT NULL COMMENT '订阅消息ID 活动提醒',
  `share_title` varchar(255) NOT NULL COMMENT '分享标题',
  `share_desc` varchar(255) NOT NULL COMMENT '分享标题',
  `share_image` varchar(255) NOT NULL COMMENT '分享图片',
  `index_luck_open` int(11) NOT NULL DEFAULT '1',
  `index_luck_bgcolor` varchar(255) DEFAULT NULL,
  `index_luck_logo` varchar(255) DEFAULT NULL,
  `index_one_open` int(11) NOT NULL DEFAULT '1',
  `index_one_title` varchar(255) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `invitation_top_image` varchar(255) DEFAULT NULL,
  `spread_level_2` int(11) DEFAULT '0',
  `spread_level_1` int(11) DEFAULT '0',
  `spread_banner` varchar(255) DEFAULT NULL,
  `ktx` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `jump_type` int(11) NOT NULL DEFAULT '0',
  `jump_path` varchar(255) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `jump_appid` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_sub_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `tmp_id` varchar(255) NOT NULL,
  `num` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_sub_msg_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `msg_tmpl_id` varchar(255) DEFAULT NULL COMMENT '模板消息',
  `content` text,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0 未发送 1 待处理 2 已发送',
  `send_resp` text,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `parent_uid` int(11) DEFAULT NULL COMMENT '上级id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1103 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_user_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` int(11) NOT NULL COMMENT '1 收入 2 支出',
  `pay_type` int(11) NOT NULL COMMENT '1 微信 2 余额',
  `price` int(11) NOT NULL COMMENT '金额',
  `order_no` varchar(255) NOT NULL COMMENT '订单',
  `order_type` int(11) NOT NULL COMMENT '1 订单 2 回收 3 充值',
  `status` int(11) NOT NULL COMMENT '1 正常 2 审核中 3 拒绝',
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `from_uid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=554 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `ims_niuniu_mang_user_tx` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acid` int(11) NOT NULL,
  `uniacid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `image` longtext,
  `status` int(11) DEFAULT '0' COMMENT '0 待处理 1 已处理 2 已到账',
  `eid` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  `deleted_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

";
pdo_run($sql);
if(!pdo_fieldexists("niuniu_mang_barrage", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "bid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `bid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "message")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `message` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `status` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_barrage", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_barrage")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "box_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `box_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `type` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `code` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `status` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "delivery_order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `delivery_order_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "get_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `get_type` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "get_status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `get_status` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_card_prize", "get_code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_card_prize")." ADD `get_code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_category", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_category", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_category", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_category", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_category", "parent_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `parent_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_category", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_category", "image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `image` varchar(255) DEFAULT '';");
}
if(!pdo_fieldexists("niuniu_mang_category", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_category", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_category", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_category", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_category", "is_recommend")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_category")." ADD `is_recommend` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `type` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "title")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `title` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "category_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `category_id` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "category_sub_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `category_sub_id` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "sub_title")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `sub_title` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "text_content")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `text_content` longtext;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "text_rule")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `text_rule` longtext;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "cabinet_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `cabinet_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "batch_num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `batch_num` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "batch_draw_num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `batch_draw_num` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_name` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_price` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_bg_color")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_bg_color` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_bg_music")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_bg_music` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_bg_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_bg_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_banner_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_banner_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_box_base_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_box_base_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_box_panel_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_box_panel_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_box_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_box_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_one_box_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_one_box_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "page_box_row_num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `page_box_row_num` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "luck_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `luck_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "item_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `item_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "share_desc")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `share_desc` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "share_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `share_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "share_title")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `share_title` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "recommend")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `recommend` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "recommend_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `recommend_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "dan_open")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `dan_open` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "dan_prize_open")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `dan_prize_open` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `status` int(11) NOT NULL DEFAULT '2';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_merchant_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_merchant_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_ver_code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_ver_code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_ver_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_ver_type` int(11) DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_fahuo_tempid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_fahuo_tempid` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_type` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "prize_desc")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `prize_desc` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "merchant_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `merchant_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "ios_hidden")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `ios_hidden` int(11) DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_commodity", "style_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity")." ADD `style_type` int(11) DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "bid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `bid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `num` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "rate")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `rate` float NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `image` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "special")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `special` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `price` varchar(255) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "recovery_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `recovery_price` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `type` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "merchant_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `merchant_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "desc")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `desc` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "ver_code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `ver_code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "ver_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `ver_type` int(11) DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_commodity_item", "fahuo_tempid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_commodity_item")." ADD `fahuo_tempid` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "key")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `key` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "limit")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `limit` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `num` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "is_new_user")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `is_new_user` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "use_key")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `use_key` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `status` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "expr_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `expr_type` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "expr_day")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `expr_day` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "expr_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `expr_time` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "coupon_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `coupon_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "limit")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `limit` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "is_new_user")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `is_new_user` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `status` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "order_no")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `order_no` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "expr_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `expr_type` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "expr_day")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `expr_day` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "expr_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `expr_time` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "expr")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `expr` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "use_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `use_time` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_coupon_user_log", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_coupon_user_log")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `uid` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "out_trade_no")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `out_trade_no` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "transaction_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `transaction_id` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "total_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `total_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "wx_pay_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `wx_pay_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "balance_pay_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `balance_pay_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "ids")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `ids` text NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "address")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `address` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "tel")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `tel` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "pay_status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `pay_status` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "pay_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `pay_time` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `type` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "remark")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `remark` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `status` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "express_number")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `express_number` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "express_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `express_type` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_delivery_order", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_delivery_order")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "number")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `number` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `type` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "typename")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `typename` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "logo")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `logo` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "list")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `list` text;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "deliverystatus")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `deliverystatus` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "query_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `query_time` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_express_query", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_express_query")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "ftid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `ftid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `uid` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `code` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `status` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_code", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_code")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `type` int(11) DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "qrcode")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `qrcode` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_fictitious_tempalte", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_fictitious_tempalte")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "item_order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `item_order_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "token")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `token` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "gei_uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `gei_uid` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_give_log", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_give_log")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_help", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_help", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_help", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_help", "title")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `title` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_help", "text")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `text` text;");
}
if(!pdo_fieldexists("niuniu_mang_help", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_help", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_help", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_help", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_help", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_help")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "bid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `bid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "batch_no")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `batch_no` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "stock")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `stock` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "sold_num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `sold_num` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `status` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "open_prize")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `open_prize` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "open_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `open_time` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "params_a")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `params_a` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "params_b")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `params_b` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "params_b_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `params_b_time` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_batch", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_batch")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `order_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "box_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `box_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "batch_no")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `batch_no` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "order_item_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `order_item_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "item_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `item_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `code` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `status` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "is_fa")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `is_fa` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "ms_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `ms_time` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "delivery_order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `delivery_order_id` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "get_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `get_type` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "get_status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `get_status` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "get_code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `get_code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_luck_code", "vcode")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_luck_code")." ADD `vcode` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "admin_uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `admin_uid` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "merchant_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `merchant_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "telphone")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `telphone` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "open_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `open_time` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "address")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `address` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "location")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `location` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_merchant_store", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_merchant_store")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_notice", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_notice", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_notice", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_notice", "title")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `title` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_notice", "text")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `text` text;");
}
if(!pdo_fieldexists("niuniu_mang_notice", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_notice", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_notice", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_notice", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_notice", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_notice")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_order", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "appid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `appid` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "mch_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `mch_id` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "box_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `box_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "box_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `box_type` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "out_trade_no")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `out_trade_no` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "transaction_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `transaction_id` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_order", "unit_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `unit_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "total_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `total_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "wxpay_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `wxpay_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "balance_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `balance_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "pay_status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `pay_status` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "pay_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `pay_time` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "luck_order_time")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `luck_order_time` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "buy_num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `buy_num` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_order", "extract_status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `extract_status` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order", "extract_success")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `extract_success` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order", "extract_code_success")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `extract_code_success` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order", "preferential_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `preferential_price` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_order", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order", "preferential_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order")." ADD `preferential_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `order_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "box_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `box_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "item_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `item_id` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `status` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "recovery_order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `recovery_order_id` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "delivery_order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `delivery_order_id` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "recovery_transaction_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `recovery_transaction_price` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "he_status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `he_status` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "exchange_card_order_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `exchange_card_order_id` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `type` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "get_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `get_type` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "get_status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `get_status` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_order_item", "get_code")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_order_item")." ADD `get_code` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `image` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "name")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `name` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "jump_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `jump_type` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "jump_path")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `jump_path` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_icon", "jump_appid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_icon")." ADD `jump_appid` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `image` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "top")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `top` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "jump_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `jump_type` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "jump_path")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `jump_path` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recommende_slide", "jump_appid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recommende_slide")." ADD `jump_appid` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `uid` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "order_no")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `order_no` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "count_num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `count_num` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_recovery_order", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_recovery_order")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "search_key")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `search_key` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `num` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_search_key", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_search_key")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "app_logo_a")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `app_logo_a` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "app_logo_b")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `app_logo_b` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "delevery_price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `delevery_price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "delevery_api_appcode")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `delevery_api_appcode` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "home_style")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `home_style` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_setting", "spread_coupon_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `spread_coupon_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_setting", "new_user_coupon_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `new_user_coupon_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "recommend_icon")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `recommend_icon` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "submsg_open")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `submsg_open` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "submsg_1")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `submsg_1` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "submsg_2")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `submsg_2` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "submsg_3")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `submsg_3` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "share_title")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `share_title` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "share_desc")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `share_desc` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "share_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `share_image` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "index_luck_open")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `index_luck_open` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_setting", "index_luck_bgcolor")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `index_luck_bgcolor` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "index_luck_logo")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `index_luck_logo` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "index_one_open")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `index_one_open` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_setting", "index_one_title")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `index_one_title` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_setting", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_setting", "invitation_top_image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `invitation_top_image` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "spread_level_2")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `spread_level_2` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_setting", "spread_level_1")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `spread_level_1` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_setting", "spread_banner")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `spread_banner` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_setting", "ktx")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_setting")." ADD `ktx` int(11) NOT NULL DEFAULT '1';");
}
if(!pdo_fieldexists("niuniu_mang_slide", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_slide", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_slide", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_slide", "image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `image` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_slide", "jump_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `jump_type` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_slide", "jump_path")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `jump_path` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_slide", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_slide", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_slide", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_slide", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_slide", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_slide", "jump_appid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `jump_appid` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_slide", "category_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_slide")." ADD `category_id` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "tmp_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `tmp_id` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "num")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `num` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "key")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `key` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "msg_tmpl_id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `msg_tmpl_id` varchar(255);");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "content")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `content` text;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `status` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "send_resp")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `send_resp` text;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_sub_msg_task", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_sub_msg_task")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_user", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "nickname")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `nickname` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "openid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `openid` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "avatar")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `avatar` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "sort")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `sort` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_user", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_user", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_user", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user", "parent_uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user")." ADD `parent_uid` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `type` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "pay_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `pay_type` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "order_no")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `order_no` varchar(255) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "order_type")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `order_type` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `status` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `updated_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_bill", "from_uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_bill")." ADD `from_uid` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "id")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `id` int(11) NOT NULL AUTO_INCREMENT;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "acid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `acid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "uniacid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `uniacid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "uid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `uid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "price")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `price` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "image")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `image` longtext;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "status")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `status` int(11) DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "eid")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `eid` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "deleted")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `deleted` int(11) NOT NULL DEFAULT '0';");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "deleted_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `deleted_at` int(11);");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "created_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `created_at` int(11) NOT NULL;");
}
if(!pdo_fieldexists("niuniu_mang_user_tx", "updated_at")) {
 pdo_query("ALTER TABLE ".tablename("niuniu_mang_user_tx")." ADD `updated_at` int(11) NOT NULL;");
}
