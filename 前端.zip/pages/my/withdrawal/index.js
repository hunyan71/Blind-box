(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 62 ], {
    230: function(e, a, t) {},
    279: function(e, a, t) {
        "use strict";
        t.r(a);
        var c = t(7), n = t(3), i = t(2), s = t(4), r = t.n(s), l = t(1), o = (t(230), t(5)), b = t(14), j = t(0), u = function() {
            var e = Object(i["useState"])({}), a = Object(n["a"])(e, 2), t = a[0], c = a[1];
            Object(i["useEffect"])(function() {
                Object(o["f"])(c), O();
            }, []);
            var u = Object(i["useState"])({}), d = Object(n["a"])(u, 2), x = d[0], p = d[1];
            Object(s["useDidShow"])(function() {
                O();
            });
            var O = function() {
                Object(o["d"])({
                    url: "entry/wxapp/MemberInfo",
                    success: function(e) {
                        p(e);
                    }
                });
            };
            return Object(j["jsxs"])(l["View"], {
                className: "withdrawal-page",
                children: [ Object(j["jsxs"])(l["View"], {
                    className: "price-v",
                    children: [ Object(j["jsxs"])(l["View"], {
                        className: "",
                        children: [ Object(j["jsx"])(l["Text"], {
                            children: "￥"
                        }), Object(j["jsx"])(l["Text"], {
                            className: "price",
                            children: Object(o["i"])(x.user_bal)
                        }) ]
                    }), Object(j["jsx"])(l["View"], {}), Object(j["jsx"])(l["View"], {
                        className: "more",
                        onClick: function() {
                            r.a.navigateTo({
                                url: "/pages/my/bill/index?tab=2"
                            });
                        },
                        children: "查看余额明细"
                    }) ]
                }), 2 == t.ktx ? Object(j["jsxs"])(j["Fragment"], {
                    children: [ Object(j["jsx"])(b["a"], {
                        type: "primary",
                        size: "default",
                        onClick: function() {
                            r.a.navigateTo({
                                url: "/pages/my/withdrawa-do/index"
                            });
                        },
                        className: "du_btn nocss-button",
                        children: "提现"
                    }), Object(j["jsx"])(l["View"], {
                        className: "more",
                        onClick: function() {
                            r.a.navigateTo({
                                url: "/pages/my/bill/index?tab=2"
                            });
                        },
                        children: "提现记录"
                    }) ]
                }) : null ]
            });
        }, d = u, x = {
            navigationBarTitleText: "余额",
            navigationBarBackgroundColor: "#FEFFFF",
            enableShareAppMessage: !0
        };
        d.enableShareAppMessage = !0;
        Page(Object(c["createPageConfig"])(d, "pages/my/withdrawal/index", {
            root: {
                cn: []
            }
        }, x || {}));
    }
}, [ [ 279, 0, 2, 1, 3 ] ] ]);