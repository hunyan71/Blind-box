module.exports = {
    name: "@@@@",
    uniacid: "2",
    acid: "2034",
    multiid: "0",
    version: "1.3.1",
    siteroot: "https://mhces.yiio.club/app/index.php"
};
//微信公众号:世纪云工作室-更多福利等着你
//小程序教程视频，微信搜索:你知我智
