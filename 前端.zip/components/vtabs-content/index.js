(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 7 ], {
    262: function(e, t, n) {
        var r = n(21);
        e.exports = function(e) {
            var t = {};
            function n(r) {
                if (t[r]) return t[r].exports;
                var o = t[r] = {
                    i: r,
                    l: !1,
                    exports: {}
                };
                return e[r].call(o.exports, o, o.exports, n), o.l = !0, o.exports;
            }
            return n.m = e, n.c = t, n.d = function(e, t, r) {
                n.o(e, t) || Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: r
                });
            }, n.r = function(e) {
                "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(e, "__esModule", {
                    value: !0
                });
            }, n.t = function(e, t) {
                if (1 & t && (e = n(e)), 8 & t) return e;
                if (4 & t && "object" === r(e) && e && e.__esModule) return e;
                var o = Object.create(null);
                if (n.r(o), Object.defineProperty(o, "default", {
                    enumerable: !0,
                    value: e
                }), 2 & t && "string" != typeof e) for (var u in e) n.d(o, u, function(t) {
                    return e[t];
                }.bind(null, u));
                return o;
            }, n.n = function(e) {
                var t = e && e.__esModule ? function() {
                    return e["default"];
                } : function() {
                    return e;
                };
                return n.d(t, "a", t), t;
            }, n.o = function(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t);
            }, n.p = "", n(n.s = 7);
        }({
            7: function(e, t, n) {
                "use strict";
                Component({
                    options: {
                        addGlobalClass: !0,
                        multipleSlots: !0
                    },
                    properties: {
                        tabIndex: {
                            type: Number,
                            value: 0
                        }
                    },
                    relations: {
                        "../vtabs/index": {
                            type: "parent"
                        }
                    },
                    lifetimes: {
                        attached: function() {}
                    },
                    methods: {
                        calcHeight: function(e) {
                            var t = this.createSelectorQuery();
                            t.select(".weui-vtabs-content__item").boundingClientRect(function(t) {
                                e && e(t);
                            }).exec();
                        }
                    }
                });
            }
        });
    }
}, [ [ 262, 0, 1 ] ] ]);