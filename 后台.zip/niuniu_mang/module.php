<?php
 defined('IN_IA') or exit('Access Denied'); class Niuniu_mangModule extends WeModule { } ?>