(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 38 ], {
    239: function(e, c, n) {},
    287: function(e, c, n) {
        "use strict";
        n.r(c);
        var a = n(7), s = n(3), t = n(2), i = n(4), o = n.n(i), r = n(1), j = n(5), l = (n(239), 
        n(0)), b = function() {
            var e = Object(t["useState"])({}), c = Object(s["a"])(e, 2), n = (c[0], c[1]);
            Object(t["useEffect"])(function() {
                Object(j["f"])(n);
            }, []);
            var a = function() {
                o.a.scanCode({
                    success: function(e) {
                        console.log(e);
                    }
                });
            };
            return Object(l["jsxs"])(r["View"], {
                className: "merchant-page",
                children: [ Object(l["jsxs"])(r["View"], {
                    className: "header",
                    children: [ Object(l["jsxs"])(r["View"], {
                        className: "col",
                        onClick: a,
                        children: [ Object(l["jsx"])(r["Text"], {
                            className: "iconfont icon-ziyuan"
                        }), Object(l["jsx"])(r["View"], {
                            children: "扫码核销"
                        }) ]
                    }), Object(l["jsxs"])(r["View"], {
                        className: "col",
                        children: [ Object(l["jsx"])(r["Text"], {
                            className: "iconfont icon-xiangqing"
                        }), Object(l["jsx"])(r["View"], {
                            children: "核销记录"
                        }) ]
                    }) ]
                }), Object(l["jsx"])(r["View"], {
                    children: Object(l["jsx"])(r["View"], {
                        className: "he-row"
                    })
                }) ]
            });
        }, x = b, f = {
            navigationBarTitleText: "商户面板",
            navigationBarBackgroundColor: "#f6f6f6",
            enableShareAppMessage: !0
        };
        x.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(x, "pages/merchant/index", {
            root: {
                cn: []
            }
        }, f || {}));
    }
}, [ [ 287, 0, 2, 1, 3 ] ] ]);