(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 70 ], {
    291: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n(7), r = (n(2), n(4)), c = n(1), o = n(0), i = function() {
            var e = Object(r["useRouter"])(), t = e.params;
            return Object(o["jsx"])(c["WebView"], {
                src: decodeURIComponent(t.url)
            });
        }, s = i, p = {
            navigationBarTitleText: ""
        };
        Page(Object(a["createPageConfig"])(s, "pages/webview/index", {
            root: {
                cn: []
            }
        }, p || {}));
    }
}, [ [ 291, 0, 2, 1 ] ] ]);