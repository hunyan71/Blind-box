(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 36 ], {
    246: function(e, t, s) {},
    247: function(e, t, s) {},
    248: function(e, t, s) {},
    249: function(e, t, s) {},
    250: function(e, t, s) {},
    251: function(e, t, s) {},
    252: function(e, t, s) {},
    253: function(e, t, s) {},
    254: function(e, t, s) {},
    255: function(e, t, s) {},
    256: function(e, t, s) {},
    257: function(e, t, s) {},
    258: function(e, t, s) {},
    265: function(e, t, s) {
        "use strict";
        s.r(t);
        var i, c, n = s(7), l = s(3), a = s(2), o = s.n(a), r = s(4), j = s.n(r), _ = s(1), d = s(64), x = s(5), b = s(15), m = (s(246), 
        s(30)), h = (s(247), s(0)), u = function(e) {
            var t = e.title, s = e.children, i = e.titleRight, c = e.titleRightOnClick;
            return Object(h["jsxs"])(_["View"], {
                className: "com-normal-container",
                children: [ Object(h["jsxs"])(_["View"], {
                    className: "com-normal-title",
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "com-normal-title_left",
                        children: t
                    }), Object(h["jsx"])(_["View"], {
                        className: "com-normal-title_right",
                        onClick: function() {
                            c && c();
                        },
                        children: i
                    }) ]
                }), Object(h["jsx"])(_["View"], {
                    className: "com-normal_content",
                    children: s
                }) ]
            });
        }, p = o.a.memo(u), O = (s(248), function(e) {
            var t = e.items, s = void 0 === t ? [ 1, 2, 3, 4 ] : t, i = e.title, c = e.titleRight, n = e.moreText, o = e.titleRightOnClick, r = e.config, j = Object(a["useState"])(!1), d = Object(l["a"])(j, 2), b = d[0], m = d[1], u = function(e, t) {
                return Object(h["jsxs"])(_["View"], {
                    className: "_prize_list_row",
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "_prize_list_row_image",
                        children: Object(h["jsx"])(_["Image"], {
                            className: "_prize_list_row_image",
                            mode: "widthFix",
                            src: "".concat(r.attachurl).concat(e.image)
                        })
                    }), Object(h["jsxs"])(_["View"], {
                        className: "_prize_list_row_info",
                        children: [ Object(h["jsxs"])(_["View"], {
                            className: "_prize_list_row_info_title",
                            children: [ Object(h["jsx"])(_["View"], {
                                className: "prize_level",
                                children: 1 == e.special ? "隐藏款" : "普通款"
                            }), Object(h["jsx"])(_["View"], {
                                children: e.name
                            }) ]
                        }), Object(h["jsx"])(_["View"], {
                            className: "_prize_list_row_info_tags _prize_list_row_info_desc",
                            children: Object(h["jsx"])(_["Text"], {
                                children: e.desc
                            })
                        }), Object(h["jsx"])(_["View"], {
                            className: "_prize_list_row_info_tags _prize_list_row_info_desc",
                            children: Object(h["jsxs"])(_["Text"], {
                                className: "jz",
                                children: [ "价值￥", Object(h["jsx"])(_["Text"], {
                                    className: "jz_p",
                                    children: Object(x["i"])(e.price)
                                }) ]
                            })
                        }) ]
                    }), Object(h["jsx"])(_["View"], {
                        className: "_prize_list_row_active"
                    }) ]
                }, t);
            };
            return Object(h["jsx"])(_["View"], {
                className: "com-commodity-prize",
                children: Object(h["jsxs"])(p, {
                    title: i,
                    titleRight: c,
                    titleRightOnClick: o,
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "_prize_list",
                        style: b ? {
                            maxHeight: "2000px"
                        } : {},
                        children: s.map(u)
                    }), s.length > 3 ? Object(h["jsxs"])(_["View"], {
                        className: "___more",
                        onClick: function() {
                            return m(!b);
                        },
                        children: [ n || "查看所有", " ", Object(h["jsx"])(_["Text"], {
                            className: " iconfont icon-ziyuan115 ".concat(b ? "___more_180" : "___more_0")
                        }) ]
                    }) : null ]
                })
            });
        }), w = o.a.memo(O), g = (s(249), !1), f = function(e) {
            var t = e.list, s = void 0 === t ? [] : t, n = e.title, o = e.row, r = void 0 !== o && o, j = e.titleRightOnClick, d = void 0 === j ? function() {
                console.log("titleRightClick");
            } : j, b = Object(a["useState"])(0), m = Object(l["a"])(b, 2), u = m[0], O = m[1], w = function() {
                g = !0, clearTimeout(c), c = setTimeout(function() {
                    g = !1;
                }, 1e4);
            }, f = function() {
                var e = 0, t = "BOTTOM", c = s.length;
                c <= 4 || (i = setInterval(function() {
                    if (!g) {
                        switch (0 == e ? t = "BOTTOM" : e + 1 >= c - 3 && (t = "TOP"), t) {
                          case "BOTTOM":
                            ++e;
                            break;

                          case "TOP":
                            --e;
                            break;
                        }
                        O(e);
                    }
                }, 3e3));
            };
            Object(a["useEffect"])(function() {
                s.length > 0 && (clearInterval(i), f());
            }, [ s ]);
            var v = function(e, t) {
                return Object(h["jsx"])(_["View"], {
                    className: "record-row",
                    id: "recprd_id_".concat(t),
                    children: r ? r(e) : Object(h["jsxs"])(h["Fragment"], {
                        children: [ Object(h["jsx"])(_["View"], {
                            className: "record-row_no"
                        }), Object(h["jsx"])(_["View"], {
                            className: "record-row_avatar",
                            children: Object(h["jsx"])(_["Image"], {
                                src: e.user_avatar,
                                className: "record-row_avatar"
                            })
                        }), Object(h["jsxs"])(_["View"], {
                            className: "record-row_info",
                            children: [ Object(h["jsxs"])(_["View"], {
                                className: "record-row_info_nickname",
                                children: [ Object(h["jsxs"])(_["View"], {
                                    className: "nickname",
                                    children: [ e.user_nickname, " 购买盒子", e.num, "连开" ]
                                }), Object(h["jsx"])(_["View"], {
                                    className: "time",
                                    children: Object(x["h"])(e.time)
                                }) ]
                            }), Object(h["jsxs"])(_["View"], {
                                className: "record-row_info_desc",
                                children: [ "开出了", e.name ]
                            }) ]
                        }), Object(h["jsx"])(_["View"], {
                            className: "record-row_right"
                        }) ]
                    })
                }, t);
            };
            return Object(h["jsx"])(_["View"], {
                className: "com-commodity-record",
                children: Object(h["jsx"])(p, {
                    title: n,
                    titleRight: "查看全部",
                    titleRightOnClick: d,
                    children: Object(h["jsx"])(_["ScrollView"], {
                        className: "scroll-v",
                        onScroll: w,
                        scrollWithAnimation: !0,
                        scrollIntoView: "recprd_id_".concat(u),
                        scrollY: !0,
                        children: s.map(v)
                    })
                })
            });
        }, v = o.a.memo(f), y = (s(250), function(e) {
            var t = e.title, s = e.children;
            return Object(h["jsxs"])(_["View"], {
                className: "com-welfare-container",
                children: [ Object(h["jsx"])(_["View"], {
                    className: "com-welfare--head",
                    children: t
                }), Object(h["jsx"])(_["View"], {
                    className: "com-welfare--content",
                    children: s
                }) ]
            });
        }), k = o.a.memo(y), V = (s(251), s(35)), N = s(34), z = (s(252), function(e) {
            var t = e.mchSotre, s = t.locations, i = void 0 === s ? [] : s, c = t.list, n = void 0 === c ? [] : c;
            Object(r["useReady"])(function() {
                i.length > 0 && setTimeout(function() {
                    var e = j.a.createMapContext("location_map");
                    e && e.includePoints({
                        points: i,
                        padding: [ 20, 20, 20, 20 ]
                    });
                }, 800);
            });
            var l = function(e) {
                var t = e.telphone;
                j.a.makePhoneCall({
                    phoneNumber: t
                });
            }, a = function(e) {
                var t = e.location, s = e.name, i = e.address, c = t.latitude, n = t.longitude;
                j.a.openLocation({
                    latitude: c,
                    longitude: n,
                    name: s,
                    address: i
                });
            }, o = function(e, t) {
                return Object(h["jsxs"])(_["View"], {
                    className: "store-row",
                    children: [ Object(h["jsxs"])(_["View"], {
                        className: "store-row_info",
                        children: [ Object(h["jsx"])(_["View"], {
                            className: "bus-name",
                            children: e.name
                        }), Object(h["jsxs"])(_["View"], {
                            className: "bus-tags",
                            children: [ Object(h["jsxs"])(_["View"], {
                                className: "bus-time-tag",
                                children: [ "营业时间:", e.open_time ]
                            }), Object(h["jsxs"])(_["View"], {
                                className: "bus-time-tag",
                                children: [ "电话:", e.telphone ]
                            }) ]
                        }), Object(h["jsx"])(_["View"], {
                            className: "bus-address",
                            children: e.address
                        }) ]
                    }), Object(h["jsxs"])(_["View"], {
                        className: "store-row_btn",
                        children: [ Object(h["jsx"])(_["Button"], {
                            size: "mini",
                            className: "nocss-button b",
                            onClick: function() {
                                return l(e);
                            },
                            children: "拨打电话"
                        }), Object(h["jsx"])(_["Button"], {
                            size: "mini",
                            className: "nocss-button b",
                            onClick: function() {
                                return a(e);
                            },
                            children: "一键导航"
                        }) ]
                    }) ]
                }, t);
            };
            return Object(h["jsx"])(_["View"], {
                className: "com-merchant-location",
                children: Object(h["jsx"])(p, {
                    title: "适用门店",
                    children: Object(h["jsxs"])(_["View"], {
                        className: "store-list",
                        children: [ i.length > 0 ? Object(h["jsx"])(_["Map"], {
                            className: "map",
                            longitude: i[0] ? i[0].longitude : 0,
                            latitude: i[0] ? i[0].latitude : 0,
                            scale: 10,
                            id: "location_map",
                            enableZoom: !1,
                            enableRotat: !1,
                            enableScroll: !1,
                            setting: {
                                enable3D: !0,
                                enableTraffic: !0
                            },
                            markers: i
                        }) : null, n.map(o), n.length > 3 ? Object(h["jsxs"])(_["View"], {
                            className: "store-more",
                            children: [ "点击查看更多门店 ", Object(h["jsx"])(_["Text"], {
                                className: "iconfont icon-weimingmingwenjianjia_jiantou"
                            }) ]
                        }) : null ]
                    })
                })
            });
        }), T = o.a.memo(z), S = (s(253), function(e) {
            var t = e.children, s = e.title, i = void 0 === s ? "标题" : s;
            return Object(h["jsx"])(_["View"], {
                className: "com-merchant-rich-text",
                children: Object(h["jsx"])(p, {
                    title: i,
                    children: Object(h["jsx"])(_["View"], {
                        className: "com-merchant-rich-text_rich-text",
                        children: t
                    })
                })
            });
        }), C = o.a.memo(S), F = s(62), R = s(16), I = function(e) {
            var t = e.boxId, s = e.config, i = Object(a["useState"])([]), c = Object(l["a"])(i, 2), n = c[0], o = c[1], r = Object(a["useState"])([]), j = Object(l["a"])(r, 2), d = j[0], b = j[1], m = Object(a["useState"])(!1), u = Object(l["a"])(m, 2), p = u[0], O = u[1];
            Object(a["useEffect"])(function() {
                w();
            }, []);
            var w = function() {
                Object(x["d"])({
                    url: "entry/wxapp/BoxLogList",
                    data: {
                        bid: t,
                        pageSize: 20,
                        page: 1
                    },
                    success: function(e) {
                        var t = e.list, s = e.total;
                        o(t), b(s);
                    }
                });
            };
            return Object(h["jsxs"])(_["View"], {
                children: [ Object(h["jsx"])(v, {
                    list: n,
                    titleRightOnClick: function() {
                        return O(!0);
                    },
                    title: Object(h["jsxs"])(_["View"], {
                        children: [ Object(h["jsx"])(_["Text"], {
                            children: "购买记录"
                        }), Object(h["jsxs"])(_["Text"], {
                            children: [ "(", d, ")" ]
                        }) ]
                    })
                }), p ? Object(h["jsx"])(R["a"], {
                    title: "全部购买记录",
                    onClose: function() {
                        return O(!1);
                    },
                    children: Object(h["jsx"])(_["View"], {
                        style: {
                            height: 600
                        },
                        children: Object(h["jsx"])(F["a"], {
                            boxId: t,
                            config: s
                        })
                    })
                }) : null ]
            });
        }, M = o.a.memo(I), B = (s(254), function(e) {
            var t = e.data, s = void 0 === t ? [] : t, i = e.moreTitle, c = e.title, n = e.moreClick, l = void 0 === n ? function() {} : n, a = function(e) {
                var t = e.icon, s = e.title;
                return Object(h["jsxs"])(_["View"], {
                    className: "process_item",
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "process_item_icon",
                        children: Object(h["jsx"])(_["Image"], {
                            src: t,
                            className: "process_item_image"
                        })
                    }), Object(h["jsx"])(_["View"], {
                        className: "process_item_title",
                        children: s
                    }), Object(h["jsx"])(_["View"], {
                        className: "process_item_right_line"
                    }), Object(h["jsx"])(_["View"], {
                        className: "process_item_left_line"
                    }) ]
                });
            };
            return Object(h["jsx"])(_["View"], {
                className: "com-commodity-process",
                children: Object(h["jsxs"])(p, {
                    title: c,
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "process_items",
                        children: s.map(a)
                    }), i ? Object(h["jsxs"])(_["View"], {
                        className: "process_more",
                        onClick: l,
                        children: [ i, " ", Object(h["jsx"])(_["Text"], {
                            className: "iconfont icon-ziyuan115"
                        }) ]
                    }) : null ]
                })
            });
        }), q = o.a.memo(B), A = s(65), L = s.n(A), P = s(66), E = s.n(P), Z = s(67), D = s.n(Z), H = s(81), J = s.n(H), U = s(68), W = s.n(U), Y = (s(255), 
        function(e) {
            var t = e.title, s = void 0 === t ? "幸运大盒子" : t, i = e.data, c = e.config, n = function() {
                return Object(h["jsxs"])(_["View"], {
                    className: "_prize_list_row",
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "_prize_list_row_image",
                        children: Object(h["jsx"])(_["Image"], {
                            className: "_prize_list_row_image",
                            mode: "widthFix",
                            src: "".concat(c.attachurl).concat(i.image)
                        })
                    }), Object(h["jsxs"])(_["View"], {
                        className: "_prize_list_row_info",
                        children: [ Object(h["jsxs"])(_["View"], {
                            className: "_prize_list_row_info_title",
                            children: [ Object(h["jsx"])(_["View"], {
                                className: "prize_level",
                                children: "幸运大奖"
                            }), Object(h["jsx"])(_["View"], {
                                children: i.name
                            }) ]
                        }), Object(h["jsx"])(_["View"], {
                            className: "_prize_list_row_info_tags _prize_list_row_info_desc",
                            children: Object(h["jsx"])(_["Text"], {
                                children: i.desc
                            })
                        }), Object(h["jsx"])(_["View"], {
                            className: "_prize_list_row_info_tags _prize_list_row_info_desc",
                            children: Object(h["jsxs"])(_["Text"], {
                                className: "jz",
                                children: [ "价值￥", Object(h["jsx"])(_["Text"], {
                                    className: "jz_p",
                                    children: Object(x["i"])(i.price)
                                }) ]
                            })
                        }) ]
                    }), Object(h["jsx"])(_["View"], {
                        className: "_prize_list_row_active"
                    }) ]
                });
            };
            return Object(h["jsx"])(_["View"], {
                className: "com-commodity-task",
                children: Object(h["jsx"])(k, {
                    title: s,
                    children: Object(h["jsx"])(_["View"], {
                        className: "task-list",
                        children: n()
                    })
                })
            });
        }), G = o.a.memo(Y), K = (s(256), function(e) {
            var t = e.items, s = void 0 === t ? [ 1, 2, 3, 4 ] : t, i = e.title, c = e.titleRight, n = e.moreText, o = e.titleRightOnClick, r = e.config, j = Object(a["useState"])(!1), d = Object(l["a"])(j, 2), x = d[0], b = d[1], m = function(e, t) {
                return Object(h["jsxs"])(_["View"], {
                    className: "card_row",
                    children: [ Object(h["jsx"])(_["Image"], {
                        className: "card_image",
                        mode: "widthFix",
                        src: "".concat(r.attachurl).concat(e.image)
                    }), Object(h["jsx"])(_["View"], {
                        children: e.name
                    }) ]
                }, t);
            };
            return Object(h["jsx"])(_["View"], {
                className: "com-commodity-prize",
                children: Object(h["jsxs"])(p, {
                    title: i,
                    titleRight: c,
                    titleRightOnClick: o,
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "cards",
                        style: x ? {
                            maxHeight: "2000px"
                        } : {},
                        children: s.map(m)
                    }), s.length > 8 ? Object(h["jsxs"])(_["View"], {
                        className: "___more",
                        onClick: function() {
                            return b(!x);
                        },
                        children: [ n || "查看所有", " ", Object(h["jsx"])(_["Text"], {
                            className: " iconfont icon-ziyuan115 ".concat(x ? "___more_180" : "___more_0")
                        }) ]
                    }) : null ]
                })
            });
        }), Q = o.a.memo(K), X = (s(257), function(e) {
            var t = e.config, s = e.orderNo, i = e.onClose, c = Object(a["useState"])([]), n = Object(l["a"])(c, 2), o = n[0], r = n[1], d = Object(a["useState"])([]), b = Object(l["a"])(d, 2), m = b[0], u = b[1], p = Object(a["useState"])(!1), O = Object(l["a"])(p, 2), w = O[0], g = O[1], f = function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                Object(x["d"])({
                    url: "entry/wxapp/orderStatus",
                    data: {
                        order_no: s
                    },
                    success: function(e) {
                        var t = e.item;
                        e.num, e.type;
                        j.a.hideLoading(), u(t), y(), setTimeout(function() {
                            setTimeout(function() {
                                g(!0);
                            }, 400);
                        }, 2e3);
                    },
                    fail: function() {
                        console.log(s, "fail", t), t < 30 && setTimeout(function() {
                            e(s, t + 1);
                        }, 1e3);
                    }
                });
            }, v = function() {
                j.a.switchTab({
                    url: "/pages/box/index"
                });
            };
            Object(a["useEffect"])(function() {
                j.a.showLoading(), f();
            }, []);
            var y = function() {
                for (var e = 12, t = 360 / e, s = [], i = 0; i < e; i++) s.push({
                    transform: "translate(0, -50%) rotateZ(".concat(i * t, "deg)")
                });
                r(s);
            }, k = function(e) {
                return Object(h["jsxs"])(h["Fragment"], {
                    children: [ Object(h["jsxs"])(_["View"], {
                        class: "dialog-tit",
                        children: [ Object(h["jsx"])(_["View"], {
                            class: "dialog-tit_main",
                            children: e.name
                        }), Object(h["jsx"])(_["View"], {
                            class: "dialog-tit_desc",
                            children: e.desc
                        }) ]
                    }), Object(h["jsx"])(_["View"], {
                        class: "dialog-main ",
                        children: Object(h["jsx"])(_["View"], {
                            class: "dialog-main-other",
                            children: Object(h["jsx"])(_["Image"], {
                                class: "dialog-main-img",
                                mode: "scaleToFill",
                                src: "".concat(t.attachurl).concat(e.image)
                            })
                        })
                    }), m.length > 1 ? Object(h["jsx"])(_["View"], {
                        class: "dialog-note ",
                        children: Object(h["jsx"])(_["View"], {
                            children: "左右滑动查看全部卡片"
                        })
                    }) : null ]
                });
            }, V = function() {
                return Object(h["jsxs"])(_["View"], {
                    class: "luck-dialog",
                    children: [ Object(h["jsx"])(_["View"], {
                        class: "dialog-bg bag",
                        children: Object(h["jsx"])(_["Image"], {
                            class: "dialog-bg-img",
                            mode: "aspectFill",
                            src: "https://static.taishan.qq.com/editor/users-upload/5e612c6235203610aba230bc/49064f10e824f8dd489b6ae88e105828.png"
                        })
                    }), Object(h["jsx"])(_["Swiper"], {
                        className: "sw",
                        previousMargin: 20,
                        nextMargin: 20,
                        children: m.map(function(e, t) {
                            return Object(h["jsx"])(_["SwiperItem"], {
                                className: "sw",
                                children: k(e)
                            }, t);
                        })
                    }), Object(h["jsx"])(_["View"], {
                        class: " bag",
                        style: {
                            marginTop: 20
                        },
                        children: Object(h["jsx"])(_["Button"], {
                            onClick: v,
                            className: "nocss-button du_btn",
                            children: "查看盒柜"
                        })
                    }) ]
                });
            };
            return Object(h["jsxs"])(_["View"], {
                class: "luck-draw ",
                children: [ Object(h["jsx"])(_["View"], {
                    class: "anima-2 anima",
                    children: Object(h["jsx"])(_["View"], {
                        class: "anima-2-opacity ",
                        children: Object(h["jsx"])(_["View"], {
                            class: "anima-2-rotate ",
                            children: o.map(function(e, t) {
                                return Object(h["jsx"])(_["View"], {
                                    class: "card-wrap",
                                    style: "transform:".concat(e.transform),
                                    children: Object(h["jsx"])(_["View"], {
                                        class: "card",
                                        children: Object(h["jsx"])(_["Image"], {
                                            class: "card-img ".concat(3 === t ? "anima-bag-scale" : ""),
                                            mode: "aspectFill",
                                            src: "//static.taishan.qq.com/editor/users-upload/5e612c6235203610aba230bc/82d83960879dd5a58219e7e59b46353b.png"
                                        })
                                    })
                                });
                            })
                        })
                    })
                }), w ? Object(h["jsx"])(_["View"], {
                    class: "anima-dialog-opacity",
                    children: Object(h["jsxs"])(_["View"], {
                        class: "anima-dialog-scale",
                        children: [ V(), Object(h["jsx"])(_["View"], {
                            onClick: i,
                            class: "dialog-close "
                        }) ]
                    })
                }) : null ]
            });
        }), $ = o.a.memo(X), ee = (s(258), function() {
            return Object(h["jsx"])("view", {
                class: "sk-container",
                children: Object(h["jsxs"])("view", {
                    class: "mch-v-page",
                    i_d: "_n_3667",
                    style: "true",
                    children: [ Object(h["jsx"])("view", {
                        class: "header",
                        i_d: "_n_3593",
                        style: "padding-top: 44px;",
                        children: Object(h["jsxs"])("view", {
                            class: "header-com",
                            i_d: "_n_3592",
                            style: "height: 40px;line-height: 40px;",
                            children: [ Object(h["jsx"])("view", {
                                class: "header-left",
                                i_d: "_n_3589",
                                style: "width: 87px;",
                                children: Object(h["jsx"])("view", {
                                    class: "back",
                                    "hover-class": "none",
                                    "hover-start-time": "50",
                                    "hover-stay-time": "400",
                                    i_d: "_n_3588",
                                    style: "height: 32px; width: 32px; border-radius: 32px; border: none;",
                                    children: Object(h["jsx"])("text", {
                                        class: "iconfont icon-biaoqing sk-pseudo sk-pseudo-circle",
                                        i_d: "_n_3587",
                                        space: "true",
                                        style: "true"
                                    })
                                })
                            }), Object(h["jsx"])("view", {
                                class: "title",
                                i_d: "_n_3590",
                                style: "true"
                            }), Object(h["jsx"])("view", {
                                i_d: "_n_3591",
                                style: "width: 79px;"
                            }) ]
                        })
                    }), Object(h["jsx"])("view", {
                        class: "mdbox sk-image",
                        i_d: "_n_3608",
                        style: "padding-top: 144px;",
                        children: Object(h["jsxs"])("view", {
                            class: "mbox-swiper-v",
                            i_d: "_n_3607",
                            style: "true",
                            children: [ Object(h["jsx"])("image", {
                                class: "open-tip sk-image",
                                i_d: "_n_3594",
                                mode: "heightFix",
                                style: "width: 79.2px;"
                            }), Object(h["jsx"])("text", {
                                class: "iconfont icon-jiantou left-a sk-pseudo sk-pseudo-circle",
                                i_d: "_n_3595",
                                space: "true",
                                style: "true"
                            }), Object(h["jsx"])("text", {
                                class: "iconfont icon-jiantou left-r sk-pseudo sk-pseudo-circle",
                                i_d: "_n_3596",
                                space: "true",
                                style: "true"
                            }), Object(h["jsxs"])("swiper", {
                                circular: "true",
                                class: "mbox-swiper",
                                current: "0",
                                "display-multiple-items": "1",
                                duration: "500",
                                "easing-function": "default",
                                i_d: "_n_4104",
                                "indicator-active-color": "#000000",
                                "indicator-color": "rgba(0, 0, 0, .3)",
                                interval: "5000",
                                "next-margin": "0px",
                                "previous-margin": "0px",
                                style: "true",
                                autoplay: "false",
                                children: [ Object(h["jsx"])("swiper-item", {
                                    class: "mbox-swiper",
                                    i_d: "_n_4012",
                                    "item-i_d": "true",
                                    style: "position: absolute; width: 100%; height: 100%; transform: translate(0%, 0px) translateZ(0px);",
                                    children: Object(h["jsxs"])("view", {
                                        class: "mbox",
                                        i_d: "_n_4011",
                                        style: "true",
                                        children: [ Object(h["jsx"])("image", {
                                            class: "d sk-image",
                                            i_d: "_n_4006",
                                            mode: "scaleToFill",
                                            style: "true"
                                        }), Object(h["jsx"])("image", {
                                            class: "q sk-image",
                                            i_d: "_n_4007",
                                            mode: "scaleToFill",
                                            style: "true"
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4010",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4008",
                                                mode: "scaleToFill",
                                                style: "bottom: 32px;left: 118px;z-index: 4;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4009",
                                                style: "bottom: 32px;left: 118px;z-index: 1004;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4220",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4218",
                                                mode: "scaleToFill",
                                                style: "bottom: 53px;left: 195px;z-index: 3;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4219",
                                                style: "bottom: 53px;left: 195px;z-index: 1003;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4223",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                class: "select-box-active-animation sk-image",
                                                i_d: "_n_4221",
                                                mode: "scaleToFill",
                                                style: "bottom: 81px;left: 79px;z-index: 2;width: 48px;height: 65px;position: absolute;"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4222",
                                                style: "bottom: 81px;left: 79px;z-index: 1002;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4226",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4224",
                                                mode: "scaleToFill",
                                                style: "bottom: 76px;left: 224px;z-index: 2;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4225",
                                                style: "bottom: 76px;left: 224px;z-index: 1002;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }) ]
                                    })
                                }), Object(h["jsx"])("swiper-item", {
                                    class: "mbox-swiper",
                                    i_d: "_n_4081",
                                    "item-i_d": "true",
                                    style: "position: absolute; width: 100%; height: 100%; transform: translate(-200%, 0px) translateZ(0px);",
                                    children: Object(h["jsxs"])("view", {
                                        class: "mbox",
                                        i_d: "_n_4080",
                                        style: "true",
                                        children: [ Object(h["jsx"])("image", {
                                            class: "d sk-image",
                                            i_d: "_n_4069",
                                            mode: "scaleToFill",
                                            style: "true"
                                        }), Object(h["jsx"])("image", {
                                            class: "q sk-image",
                                            i_d: "_n_4070",
                                            mode: "scaleToFill",
                                            style: "true"
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4238",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4236",
                                                mode: "scaleToFill",
                                                style: "bottom: 31px;left: 167px;z-index: 4;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4237",
                                                style: "bottom: 31px;left: 167px;z-index: 1004;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4241",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4239",
                                                mode: "scaleToFill",
                                                style: "bottom: 58px;left: 50px;z-index: 3;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4240",
                                                style: "bottom: 58px;left: 50px;z-index: 1003;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4244",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                class: "select-box-active-animation sk-image",
                                                i_d: "_n_4242",
                                                mode: "scaleToFill",
                                                style: "bottom: 56px;left: 99px;z-index: 3;width: 48px;height: 65px;position: absolute;"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4243",
                                                style: "bottom: 56px;left: 99px;z-index: 1003;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4247",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4245",
                                                mode: "scaleToFill",
                                                style: "bottom: 55px;left: 147px;z-index: 3;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4246",
                                                style: "bottom: 55px;left: 147px;z-index: 1003;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4079",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4077",
                                                mode: "scaleToFill",
                                                style: "bottom: 53px;left: 195px;z-index: 3;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4078",
                                                style: "bottom: 53px;left: 195px;z-index: 1003;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4250",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4248",
                                                mode: "scaleToFill",
                                                style: "bottom: 81px;left: 79px;z-index: 2;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4249",
                                                style: "bottom: 81px;left: 79px;z-index: 1002;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4253",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4251",
                                                mode: "scaleToFill",
                                                style: "bottom: 79px;left: 127px;z-index: 2;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4252",
                                                style: "bottom: 79px;left: 127px;z-index: 1002;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4256",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4254",
                                                mode: "scaleToFill",
                                                style: "bottom: 78px;left: 176px;z-index: 2;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4255",
                                                style: "bottom: 78px;left: 176px;z-index: 1002;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }) ]
                                    })
                                }), Object(h["jsx"])("swiper-item", {
                                    class: "mbox-swiper",
                                    i_d: "_n_4103",
                                    "item-i_d": "true",
                                    style: "position: absolute; width: 100%; height: 100%; transform: translate(-100%, 0px) translateZ(0px);",
                                    children: Object(h["jsxs"])("view", {
                                        class: "mbox",
                                        i_d: "_n_4102",
                                        style: "true",
                                        children: [ Object(h["jsx"])("image", {
                                            class: "d sk-image",
                                            i_d: "_n_4082",
                                            mode: "scaleToFill",
                                            style: "true"
                                        }), Object(h["jsx"])("image", {
                                            class: "q sk-image",
                                            i_d: "_n_4083",
                                            mode: "scaleToFill",
                                            style: "true"
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4098",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4096",
                                                mode: "scaleToFill",
                                                style: "bottom: 55px;left: 147px;z-index: 3;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4097",
                                                style: "bottom: 55px;left: 147px;z-index: 1003;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            i_d: "_n_4101",
                                            style: "true",
                                            children: [ Object(h["jsx"])("image", {
                                                i_d: "_n_4099",
                                                mode: "scaleToFill",
                                                style: "bottom: 53px;left: 195px;z-index: 3;width: 48px;height: 65px;position: absolute;",
                                                class: "sk-image"
                                            }), Object(h["jsx"])("view", {
                                                "hover-class": "none",
                                                "hover-start-time": "50",
                                                "hover-stay-time": "400",
                                                i_d: "_n_4100",
                                                style: "bottom: 53px;left: 195px;z-index: 1003;width: 48px;height: 65px;position: absolute;"
                                            }) ]
                                        }) ]
                                    })
                                }) ]
                            }), Object(h["jsxs"])("view", {
                                class: "text-c",
                                i_d: "_n_3606",
                                style: "true",
                                children: [ Object(h["jsx"])("text", {
                                    class: "iconfont icon-biaoqing gray sk-pseudo sk-pseudo-circle",
                                    i_d: "_n_3600",
                                    space: "true",
                                    style: "true"
                                }), Object(h["jsx"])("text", {
                                    class: "iconfont icon-biaoqing sk-pseudo sk-pseudo-circle",
                                    i_d: "_n_3601",
                                    space: "true",
                                    style: "true"
                                }), Object(h["jsx"])("text", {
                                    i_d: "_n_3603",
                                    space: "true",
                                    style: "background-position-x: 50%;",
                                    class: "sk-transparent sk-text-14-2857-90 sk-text",
                                    children: "左右滑动可换盒"
                                }), Object(h["jsx"])("text", {
                                    class: "iconfont icon-weimingmingwenjianjia_jiantou sk-pseudo sk-pseudo-circle",
                                    i_d: "_n_3604",
                                    space: "true",
                                    style: "true"
                                }), Object(h["jsx"])("text", {
                                    class: "iconfont icon-weimingmingwenjianjia_jiantou gray sk-pseudo sk-pseudo-circle",
                                    i_d: "_n_3605",
                                    space: "true",
                                    style: "true"
                                }) ]
                            }) ]
                        })
                    }), Object(h["jsx"])("view", {
                        class: "title_bar",
                        i_d: "_n_3610",
                        style: "true",
                        children: Object(h["jsx"])("view", {
                            class: "title sk-transparent sk-text-14-2857-1000 sk-text",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            i_d: "_n_3609",
                            style: "true",
                            children: "万的小熊仔手办"
                        })
                    }), Object(h["jsx"])("view", {
                        class: "box",
                        i_d: "_n_3888",
                        style: "true",
                        children: Object(h["jsx"])("view", {
                            class: "com-commodity-process",
                            i_d: "_n_3887",
                            style: "true",
                            children: Object(h["jsxs"])("view", {
                                class: "com-normal-container",
                                i_d: "_n_3886",
                                style: "true",
                                children: [ Object(h["jsxs"])("view", {
                                    class: "com-normal-title",
                                    i_d: "_n_3844",
                                    style: "border: none;",
                                    children: [ Object(h["jsx"])("view", {
                                        class: "com-normal-title_left sk-transparent sk-text-14-2857-753 sk-text",
                                        i_d: "_n_3842",
                                        style: "true",
                                        children: "集卡玩法流程"
                                    }), Object(h["jsx"])("view", {
                                        class: "com-normal-title_right",
                                        "hover-class": "none",
                                        "hover-start-time": "50",
                                        "hover-stay-time": "400",
                                        i_d: "_n_3843",
                                        style: "true"
                                    }) ]
                                }), Object(h["jsxs"])("view", {
                                    class: "com-normal_content",
                                    i_d: "_n_3885",
                                    style: "true",
                                    children: [ Object(h["jsxs"])("view", {
                                        class: "process_items",
                                        i_d: "_n_3880",
                                        style: "true",
                                        children: [ Object(h["jsxs"])("view", {
                                            class: "process_item",
                                            i_d: "_n_3851",
                                            style: "true",
                                            children: [ Object(h["jsx"])("view", {
                                                class: "process_item_icon",
                                                i_d: "_n_3846",
                                                style: "true",
                                                children: Object(h["jsx"])("image", {
                                                    class: "process_item_image sk-image",
                                                    i_d: "_n_3845",
                                                    mode: "scaleToFill",
                                                    style: "true"
                                                })
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_title sk-transparent sk-text-14-2857-221 sk-text",
                                                i_d: "_n_3848",
                                                style: "true",
                                                children: "购买"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_right_line",
                                                i_d: "_n_3849",
                                                style: "border: none;"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_left_line",
                                                i_d: "_n_3850",
                                                style: "true"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            class: "process_item",
                                            i_d: "_n_3858",
                                            style: "true",
                                            children: [ Object(h["jsx"])("view", {
                                                class: "process_item_icon",
                                                i_d: "_n_3853",
                                                style: "true",
                                                children: Object(h["jsx"])("image", {
                                                    class: "process_item_image sk-image",
                                                    i_d: "_n_3852",
                                                    mode: "scaleToFill",
                                                    style: "true"
                                                })
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_title sk-transparent sk-text-14-2857-553 sk-text",
                                                i_d: "_n_3855",
                                                style: "true",
                                                children: "获得卡片"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_right_line",
                                                i_d: "_n_3856",
                                                style: "border: none;"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_left_line",
                                                i_d: "_n_3857",
                                                style: "border: none;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            class: "process_item",
                                            i_d: "_n_3865",
                                            style: "true",
                                            children: [ Object(h["jsx"])("view", {
                                                class: "process_item_icon",
                                                i_d: "_n_3860",
                                                style: "true",
                                                children: Object(h["jsx"])("image", {
                                                    class: "process_item_image sk-image",
                                                    i_d: "_n_3859",
                                                    mode: "scaleToFill",
                                                    style: "true"
                                                })
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_title sk-transparent sk-text-14-2857-417 sk-text",
                                                i_d: "_n_3862",
                                                style: "true",
                                                children: "集齐卡片"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_right_line",
                                                i_d: "_n_3863",
                                                style: "border: none;"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_left_line",
                                                i_d: "_n_3864",
                                                style: "border: none;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            class: "process_item",
                                            i_d: "_n_3872",
                                            style: "true",
                                            children: [ Object(h["jsx"])("view", {
                                                class: "process_item_icon",
                                                i_d: "_n_3867",
                                                style: "true",
                                                children: Object(h["jsx"])("image", {
                                                    class: "process_item_image sk-image",
                                                    i_d: "_n_3866",
                                                    mode: "scaleToFill",
                                                    style: "true"
                                                })
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_title sk-transparent sk-text-14-2857-492 sk-text",
                                                i_d: "_n_3869",
                                                style: "true",
                                                children: "兑换奖品"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_right_line",
                                                i_d: "_n_3870",
                                                style: "border: none;"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_left_line",
                                                i_d: "_n_3871",
                                                style: "border: none;"
                                            }) ]
                                        }), Object(h["jsxs"])("view", {
                                            class: "process_item",
                                            i_d: "_n_3879",
                                            style: "true",
                                            children: [ Object(h["jsx"])("view", {
                                                class: "process_item_icon",
                                                i_d: "_n_3874",
                                                style: "true",
                                                children: Object(h["jsx"])("image", {
                                                    class: "process_item_image sk-image",
                                                    i_d: "_n_3873",
                                                    mode: "scaleToFill",
                                                    style: "true"
                                                })
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_title sk-transparent sk-text-14-2857-438 sk-text",
                                                i_d: "_n_3876",
                                                style: "true",
                                                children: "核销/发货"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_right_line",
                                                i_d: "_n_3877",
                                                style: "true"
                                            }), Object(h["jsx"])("view", {
                                                class: "process_item_left_line",
                                                i_d: "_n_3878",
                                                style: "border: none;"
                                            }) ]
                                        }) ]
                                    }), Object(h["jsxs"])("view", {
                                        class: "process_more sk-transparent",
                                        "hover-class": "none",
                                        "hover-start-time": "50",
                                        "hover-stay-time": "400",
                                        i_d: "_n_3884",
                                        style: "border: none;",
                                        children: [ "查看详细规则", Object(h["jsx"])("text", {
                                            class: "iconfont icon-ziyuan115 sk-pseudo sk-pseudo-circle",
                                            i_d: "_n_3883",
                                            space: "true",
                                            style: "true"
                                        }) ]
                                    }) ]
                                }) ]
                            })
                        })
                    }), Object(h["jsx"])("view", {
                        class: "box",
                        i_d: "_n_3911",
                        style: "true",
                        children: Object(h["jsx"])("view", {
                            class: "com-commodity-task",
                            i_d: "_n_3910",
                            style: "true",
                            children: Object(h["jsxs"])("view", {
                                class: "com-welfare-container",
                                i_d: "_n_3909",
                                style: "true",
                                children: [ Object(h["jsx"])("view", {
                                    class: "com-welfare--head sk-transparent sk-text-23-3333-50 sk-text",
                                    i_d: "_n_3890",
                                    style: "background-position-x: 50%;",
                                    children: "集卡即可兑换"
                                }), Object(h["jsx"])("view", {
                                    class: "com-welfare--content",
                                    i_d: "_n_3908",
                                    style: "true",
                                    children: Object(h["jsx"])("view", {
                                        class: "task-list",
                                        i_d: "_n_3907",
                                        style: "true",
                                        children: Object(h["jsxs"])("view", {
                                            class: "_prize_list_row",
                                            i_d: "_n_3906",
                                            style: "true",
                                            children: [ Object(h["jsx"])("view", {
                                                class: "_prize_list_row_image",
                                                i_d: "_n_3892",
                                                style: "true",
                                                children: Object(h["jsx"])("image", {
                                                    class: "_prize_list_row_image sk-image",
                                                    i_d: "_n_3891",
                                                    mode: "widthFix",
                                                    style: "height: 68.8696px;"
                                                })
                                            }), Object(h["jsxs"])("view", {
                                                class: "_prize_list_row_info",
                                                i_d: "_n_3904",
                                                style: "true",
                                                children: [ Object(h["jsxs"])("view", {
                                                    class: "_prize_list_row_info_title",
                                                    i_d: "_n_3896",
                                                    style: "true",
                                                    children: [ Object(h["jsx"])("view", {
                                                        class: "prize_level sk-transparent sk-text-14-2857-683 sk-text",
                                                        i_d: "_n_3894",
                                                        style: "true",
                                                        children: "幸运大奖"
                                                    }), Object(h["jsx"])("view", {
                                                        i_d: "_n_3895",
                                                        style: "true",
                                                        class: "sk-transparent sk-text-14-2857-533 sk-text",
                                                        children: "测试商品"
                                                    }) ]
                                                }), Object(h["jsx"])("view", {
                                                    class: "_prize_list_row_info_tags _prize_list_row_info_desc",
                                                    i_d: "_n_3898",
                                                    style: "true",
                                                    children: Object(h["jsx"])("text", {
                                                        i_d: "_n_3897",
                                                        space: "true",
                                                        style: "true",
                                                        class: "sk-transparent sk-text-14-2857-291 sk-text",
                                                        children: "测试商品测试商品"
                                                    })
                                                }) ]
                                            }), Object(h["jsx"])("view", {
                                                class: "_prize_list_row_active",
                                                i_d: "_n_3905",
                                                style: "true"
                                            }) ]
                                        })
                                    })
                                }) ]
                            })
                        })
                    }), Object(h["jsx"])("view", {
                        class: "footer-bb",
                        i_d: "_n_3932",
                        style: "padding-bottom: 34px;",
                        children: Object(h["jsx"])("view", {
                            i_d: "_n_3931",
                            style: "true",
                            children: Object(h["jsx"])("view", {
                                class: "undefined footer-render",
                                i_d: "_n_3930",
                                style: "true",
                                children: Object(h["jsxs"])("view", {
                                    class: "buybar",
                                    i_d: "_n_3929",
                                    style: "true",
                                    children: [ Object(h["jsxs"])("view", {
                                        class: "price",
                                        i_d: "_n_3925",
                                        style: "true",
                                        children: [ Object(h["jsx"])("view", {
                                            class: "text sk-transparent sk-text-14-2857-933 sk-text",
                                            i_d: "_n_3922",
                                            style: "true",
                                            children: "￥0.01"
                                        }), Object(h["jsx"])("view", {
                                            class: "desc sk-transparent sk-text-14-2857-513 sk-text",
                                            i_d: "_n_3924",
                                            style: "true",
                                            children: "连抽抽到不同款的概率更高喔"
                                        }) ]
                                    }), Object(h["jsx"])("view", {
                                        class: "f-btns",
                                        i_d: "_n_3928",
                                        style: "true",
                                        children: Object(h["jsx"])("view", {
                                            class: "bb ",
                                            "hover-class": "none",
                                            "hover-start-time": "50",
                                            "hover-stay-time": "400",
                                            i_d: "_n_3927",
                                            style: "true",
                                            children: "购买"
                                        })
                                    }) ]
                                })
                            })
                        })
                    }) ]
                })
            });
        }), te = ee, se = function() {
            var e = Object(r["useRouter"])(), t = Object(a["useState"])({}), s = Object(l["a"])(t, 2), i = s[0], c = s[1], n = Object(a["useState"])({}), o = Object(l["a"])(n, 2), u = o[0], p = o[1], O = Object(a["useState"])(!0), g = Object(l["a"])(O, 2), f = g[0], v = g[1], y = Object(a["useState"])(!1), k = Object(l["a"])(y, 2), z = (k[0], 
            k[1]), S = Object(a["useState"])(9), F = Object(l["a"])(S, 2), R = F[0], I = F[1], B = Object(a["useState"])(3), A = Object(l["a"])(B, 2), P = A[0], Z = A[1], H = Object(a["useState"])(!1), U = Object(l["a"])(H, 2), Y = U[0], K = U[1], X = Object(a["useState"])([ [] ]), ee = Object(l["a"])(X, 2), se = ee[0], ie = ee[1], ce = Object(a["useState"])(!1), ne = Object(l["a"])(ce, 2), le = ne[0], ae = ne[1], oe = Object(a["useState"])(!1), re = Object(l["a"])(oe, 2), je = re[0], _e = re[1], de = Object(a["useState"])({}), xe = Object(l["a"])(de, 2), be = xe[0], me = xe[1], he = Object(a["useState"])({}), ue = Object(l["a"])(he, 2), pe = ue[0], Oe = ue[1], we = Object(a["useState"])({}), ge = Object(l["a"])(we, 2), fe = ge[0], ve = ge[1], ye = Object(a["useState"])({}), ke = Object(l["a"])(ye, 2), Ve = ke[0], Ne = ke[1], ze = Object(a["useState"])({}), Te = Object(l["a"])(ze, 2), Se = Te[0], Ce = Te[1], Fe = Object(a["useState"])({}), Re = Object(l["a"])(Fe, 2), Ie = Re[0], Me = Re[1], Be = Object(a["useState"])({}), qe = Object(l["a"])(Be, 2), Ae = qe[0], Le = qe[1], Pe = Object(a["useState"])(!1), Ee = Object(l["a"])(Pe, 2), Ze = Ee[0], De = (Ee[1], 
            Object(a["useState"])(!1)), He = Object(l["a"])(De, 2), Je = He[0], Ue = He[1], We = Object(a["useState"])([]), Ye = Object(l["a"])(We, 2), Ge = Ye[0], Ke = Ye[1], Qe = Object(a["useState"])({
                list: []
            }), Xe = Object(l["a"])(Qe, 2), $e = Xe[0], et = Xe[1], tt = Object(a["useState"])(!1), st = Object(l["a"])(tt, 2), it = st[0], ct = st[1], nt = Object(a["useState"])(""), lt = Object(l["a"])(nt, 2), at = lt[0], ot = lt[1], rt = function(e) {
                ot(e), ct(!0);
            }, jt = Object(a["useState"])(""), _t = Object(l["a"])(jt, 2), dt = _t[0], xt = _t[1], bt = Object(a["useState"])(""), mt = Object(l["a"])(bt, 2), ht = mt[0], ut = mt[1];
            Object(a["useEffect"])(function() {
                Ve.text_content && (Ve.text_content && xt(Object(b["c"])(Ve.text_content)), Ve.text_rule && ut(Object(b["c"])(Ve.text_rule)));
            }, [ Ve ]), Object(a["useEffect"])(function() {
                Object(x["f"])(function(e) {
                    pt(e), p(e);
                }), c(Object(b["a"])());
            }, []);
            var pt = function(e) {
                Object(x["d"])({
                    url: "entry/wxapp/details",
                    data: {
                        id: Ot()
                    },
                    success: function(e) {
                        e.id;
                        var t = e.base, s = e.page, i = e.batch, c = e.share, n = e.details, l = e.setting, a = e.items, o = e.mch_sotre, r = e.prize;
                        me(s), Me(i), Oe(t), ve(c), Ne(n), Ce(l), Ke(a), et(o), Le(r), 1 == s["page_box_row_num"] ? (I(9), 
                        Z(3)) : (I(12), Z(4)), setTimeout(function() {
                            v(!1), wt(t.status);
                        }, 200);
                    }
                });
            };
            Object(r["useShareAppMessage"])(function() {
                var e = j.a.getStorageSync("userInfo");
                e.uid;
                return {
                    title: fe.share_title ? fe.share_title : u.share_title,
                    path: "/pages/index/index",
                    imageUrl: "".concat(u.attachurl).concat(fe.share_image ? fe.share_image : u.share_image)
                };
            });
            var Ot = function() {
                return e.params.id;
            }, wt = function(e) {
                if (1 != e) return K(!0), !1;
                var t = .8, s = 137, i = 185, c = .8;
                3 == P && (c = 1.1);
                for (var n = function(e) {
                    for (var t = e.length, s = 0; s < t; s++) {
                        var i = Math.floor(Math.random() * (t - s)), c = e[i];
                        e[i] = e[s], e[s] = c;
                    }
                    return e;
                }, l = function(e, i) {
                    return (3 == P ? 75 * t : 50 * t) + s * c * t * e + (3 == P ? 70 * i * t : 65 * i * t);
                }, a = function(e, s, i) {
                    return (3 == P ? 50 : 80) * t + s * (3 == P ? 90 : 80) * t - 7 * e * t + 3 * i;
                }, o = function() {
                    var e = Math.floor(10 * Math.random());
                    0 == e && (e = 1);
                    for (var o = new Array(R), r = Math.ceil(Math.random() * e), j = 0; j < e; j++) o[j] = r == j ? {
                        an: !0
                    } : {};
                    var _ = n(o);
                    for (var d in _) if (_.hasOwnProperty.call(_, d)) {
                        var x = _[d];
                        if (!x) continue;
                        var b = Math.floor(d / P), m = d % P;
                        _[d].style = {
                            bottom: "".concat(a(d, b, m), "rpx"),
                            left: "".concat(l(m, b), "rpx"),
                            zIndex: P - b,
                            width: "".concat(s * t * c, "rpx"),
                            height: "".concat(i * t * c, "rpx"),
                            position: "absolute"
                        };
                    }
                    return _;
                }, r = [], j = 0; j < 5; j++) r.push(o());
                ie(r), K(!0);
            }, gt = function() {
                j.a.pageScrollTo({
                    selector: "#rule_id"
                });
            };
            return Object(h["jsx"])(h["Fragment"], {
                children: f ? Object(h["jsx"])(te, {}) : Object(h["jsxs"])(_["View"], {
                    className: "mch-v-page",
                    children: [ Object(h["jsx"])(_["View"], {
                        className: "header",
                        style: {
                            paddingTop: "".concat(i.paddingTop, "px")
                        },
                        children: Object(h["jsx"])(m["a"], {
                            safeArea: i,
                            pageConfig: {}
                        })
                    }), Object(h["jsx"])(_["View"], {
                        className: "mdbox",
                        style: {
                            backgroundImage: "url(".concat(u.attachurl).concat(be.page_bg_image, ")"),
                            paddingTop: "".concat(i.paddingTop + 100, "px")
                        },
                        children: Object(h["jsx"])(d["a"], {
                            onOneClick: function() {
                                Ue(!0);
                            },
                            boxId: Ot(),
                            baseConfig: pe,
                            show: Y,
                            list: se,
                            imageConfig: be,
                            userAuth: Ze
                        })
                    }), Object(h["jsxs"])(_["View"], {
                        className: "title_bar",
                        children: [ Object(h["jsx"])(_["View"], {
                            className: "title",
                            onClick: function() {
                                return z(!0);
                            },
                            children: pe.title
                        }), 2 == pe.type ? Object(h["jsxs"])(_["View"], {
                            className: "info",
                            children: [ Object(h["jsxs"])(_["View"], {
                                children: [ Object(h["jsx"])(_["Text"], {
                                    children: "当前进行:"
                                }), Object(h["jsxs"])(_["Text"], {
                                    className: "z",
                                    children: [ "第", Ie.batch_no, "期" ]
                                }) ]
                            }), Object(h["jsxs"])(_["View"], {
                                children: [ "本期剩余:", Object(h["jsxs"])(_["Text"], {
                                    className: "z",
                                    children: [ Ie.stock - Ie.sold_num, "盒" ]
                                }) ]
                            }) ]
                        }) : null ]
                    }), 1 == pe.type ? Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(q, {
                            title: "盒子玩法流程",
                            moreTitle: "查看详细规则",
                            moreClick: gt,
                            data: [ {
                                title: "购买盒子",
                                icon: L.a
                            }, {
                                title: "拆开盒子",
                                icon: E.a
                            }, {
                                title: "获得物品",
                                icon: D.a
                            }, {
                                title: "核销/发货",
                                icon: W.a
                            } ]
                        })
                    }) : null, 2 == pe.type ? Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(q, {
                            title: "幸运盒子玩法流程",
                            moreTitle: "查看详细规则",
                            moreClick: gt,
                            data: [ {
                                title: "购买盒子",
                                icon: L.a
                            }, {
                                title: "拆开盒子",
                                icon: E.a
                            }, {
                                title: "获得物品",
                                icon: D.a
                            }, {
                                title: "赠送抽奖码",
                                icon: J.a
                            }, {
                                title: "核销/发货",
                                icon: W.a
                            } ]
                        })
                    }) : null, 3 == pe.type ? Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(q, {
                            title: "集卡盒子玩法流程",
                            moreTitle: "查看详细规则",
                            moreClick: gt,
                            data: [ {
                                title: "购买盒子",
                                icon: L.a
                            }, {
                                title: "获得卡片",
                                icon: E.a
                            }, {
                                title: "集齐卡片",
                                icon: D.a
                            }, {
                                title: "兑换奖品",
                                icon: J.a
                            }, {
                                title: "核销/发货",
                                icon: W.a
                            } ]
                        })
                    }) : null, 2 == pe.type ? Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(G, {
                            title: "幸运大奖",
                            data: Ae,
                            config: u
                        })
                    }) : null, 3 == pe.type ? Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(G, {
                            title: "集卡即可兑换",
                            data: Ae,
                            config: u
                        })
                    }) : null, 3 == pe.type ? Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(Q, {
                            items: Ge,
                            title: "盒子卡片",
                            config: u,
                            titleRight: "所有卡片"
                        })
                    }) : Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(w, {
                            items: Ge,
                            title: "盒子物品",
                            config: u,
                            titleRight: "可以获得的物品"
                        })
                    }), Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(T, {
                            mchSotre: $e,
                            config: u
                        })
                    }), Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(C, {
                            title: "活动详情",
                            children: Object(h["jsx"])(_["RichText"], {
                                nodes: dt
                            })
                        })
                    }), Object(h["jsx"])(_["View"], {
                        className: "box",
                        id: "rule_id",
                        children: Object(h["jsx"])(C, {
                            title: "活动规则",
                            children: Object(h["jsx"])(_["RichText"], {
                                nodes: ht
                            })
                        })
                    }), Object(h["jsx"])(_["View"], {
                        className: "box",
                        children: Object(h["jsx"])(M, {
                            boxId: Ot(),
                            config: u
                        })
                    }), Object(h["jsx"])(_["View"], {
                        style: {
                            height: 100
                        }
                    }), pe.price ? Object(h["jsx"])(_["View"], {
                        className: "footer-bb",
                        style: {
                            paddingBottom: "".concat(i.paddingBottom, "px")
                        },
                        children: Object(h["jsx"])(V["a"], {
                            boxId: Ot(),
                            showMenus: !1,
                            userAuth: Ze,
                            requestBoxDetails: pt,
                            showOpenBox: rt,
                            showRule: je,
                            hideOneBtn: !0,
                            showOneBuy: Je,
                            onShowOneClose: function() {
                                return Ue(!1);
                            },
                            oneBtnText: "购买盒子",
                            detailsConfig: Ve,
                            settingConfig: Se,
                            batchConfig: Ie,
                            baseConfig: pe,
                            onRuleClose: function() {
                                return _e(!1);
                            },
                            onLogClose: function() {
                                return ae(!1);
                            },
                            showLog: le
                        })
                    }) : null, 3 == pe.type ? Object(h["jsx"])(h["Fragment"], {
                        children: it ? Object(h["jsx"])($, {
                            orderNo: at,
                            onClose: function() {
                                return ct(!1);
                            },
                            config: u
                        }) : null
                    }) : Object(h["jsx"])(h["Fragment"], {
                        children: it ? Object(h["jsx"])(N["a"], {
                            orderNo: at,
                            onClose: function() {
                                return ct(!1);
                            }
                        }) : null
                    }) ]
                })
            });
        }, ie = se, ce = {
            navigationBarTitleText: "详情",
            enableShareAppMessage: !0,
            navigationStyle: "custom"
        };
        ie.enableShareAppMessage = !0;
        Page(Object(n["createPageConfig"])(ie, "pages/mch/details/index", {
            root: {
                cn: []
            }
        }, ce || {}));
    },
    65: function(e, t, s) {
        e.exports = s.p + "assets/icons/buy.png";
    },
    66: function(e, t, s) {
        e.exports = s.p + "assets/icons/dropbox.png";
    },
    67: function(e, t, s) {
        e.exports = s.p + "assets/icons/emotion-happy.png";
    },
    68: function(e, t, s) {
        e.exports = s.p + "assets/icons/scan-code.png";
    },
    81: function(e, t, s) {
        e.exports = s.p + "assets/icons/eight-key.png";
    }
}, [ [ 265, 0, 2, 1, 3 ] ] ]);