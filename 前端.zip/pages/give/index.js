(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 32 ], {
    235: function(e, t, s) {},
    284: function(e, t, s) {
        "use strict";
        s.r(t);
        var n = s(7), a = s(3), i = s(14), c = s(5), r = s(1), l = s(4), o = s.n(l), u = s(2), j = s.n(u), d = (s(235), 
        s(0)), b = j.a.memo(function() {
            var e = Object(u["useState"])(!0), t = Object(a["a"])(e, 2), s = t[0], n = t[1], j = Object(u["useState"])({}), b = Object(a["a"])(j, 2), m = b[0], _ = b[1], x = Object(u["useState"])({
                item_info: {},
                share_info: {},
                user_info: {}
            }), p = Object(a["a"])(x, 2), h = p[0], O = p[1], f = Object(l["useRouter"])(), g = f.params;
            Object(u["useEffect"])(function() {
                Object(c["f"])(_), w();
            }, []), Object(l["useDidShow"])(function() {
                w();
            });
            var w = function() {
                Object(c["d"])({
                    url: "entry/wxapp/GetGiveToFriendsInfo",
                    data: {
                        token: g.st
                    },
                    success: function(e) {
                        n(!1), O(e);
                    }
                });
            }, v = function() {
                Object(c["d"])({
                    url: "entry/wxapp/GetGiveItem",
                    data: {
                        token: g.st
                    },
                    success: function() {
                        o.a.showModal({
                            title: "领取成功",
                            content: "点击确定查看我的盒柜",
                            showCancel: !1,
                            complete: function() {
                                o.a.switchTab({
                                    url: "/pages/box/index"
                                });
                            }
                        });
                    }
                });
            }, k = function() {
                return Object(d["jsx"])("view", {
                    class: "sk-container",
                    children: Object(d["jsxs"])("view", {
                        class: "give-page",
                        id_nn: "_n_18",
                        style: "true",
                        children: [ Object(d["jsxs"])("view", {
                            class: "user-info",
                            id_nn: "_n_9",
                            style: "true",
                            children: [ Object(d["jsx"])("image", {
                                class: "avatar sk-image",
                                id_nn: "_n_6",
                                mode: "scaleToFill",
                                style: "true"
                            }), Object(d["jsx"])("view", {
                                class: "title sk-transparent sk-text-14-2857-601 sk-text",
                                id_nn: "_n_8",
                                style: "true",
                                children: "送你物品，快点击领取吧"
                            }) ]
                        }), Object(d["jsxs"])("view", {
                            class: "item",
                            id_nn: "_n_13",
                            style: "true",
                            children: [ Object(d["jsx"])("image", {
                                class: "item_image sk-image",
                                id_nn: "_n_10",
                                mode: "widthFix",
                                style: "height: 437.95px;"
                            }), Object(d["jsx"])("view", {
                                class: "title sk-transparent sk-text-14-2857-51 sk-text",
                                id_nn: "_n_11",
                                style: "true",
                                children: "这个是卡片盒子"
                            }), Object(d["jsx"])("view", {
                                class: "desc sk-transparent sk-text-14-2857-134 sk-text",
                                id_nn: "_n_12",
                                style: "true",
                                children: "卡片盒子"
                            }) ]
                        }), Object(d["jsx"])("view", {
                            id_nn: "_n_17",
                            style: "margin-top: 20px;",
                            children: Object(d["jsx"])("view", {
                                id_nn: "_n_16",
                                style: "true",
                                children: Object(d["jsx"])("button", {
                                    "app-parameter": "true",
                                    class: "nocss-button du_btn sk-transparent sk-button sk-pseudo sk-pseudo-circle",
                                    "form-type": "true",
                                    "hover-class": "button-hover",
                                    "hover-start-time": "20",
                                    "hover-stay-time": "70",
                                    id_nn: "_n_15",
                                    lang: "true",
                                    "open-type": "true",
                                    "send-message-img": "true",
                                    "send-message-path": "true",
                                    "send-message-title": "true",
                                    "session-from": "true",
                                    size: "default",
                                    style: "true",
                                    type: "primary",
                                    children: "收下卡片"
                                })
                            })
                        }) ]
                    })
                });
            };
            return Object(d["jsx"])(d["Fragment"], {
                children: s ? k() : Object(d["jsxs"])(r["View"], {
                    className: "give-page",
                    children: [ Object(d["jsxs"])(r["View"], {
                        className: "user-info",
                        children: [ Object(d["jsx"])(r["Image"], {
                            className: "avatar",
                            src: h.user_info.avatar
                        }), Object(d["jsx"])(r["View"], {
                            className: "title",
                            children: "送你物品，快点击领取吧"
                        }) ]
                    }), Object(d["jsxs"])(r["View"], {
                        className: "item",
                        children: [ Object(d["jsx"])(r["Image"], {
                            className: "item_image",
                            src: "".concat(m.attachurl).concat(h.item_info.image),
                            mode: "widthFix"
                        }), Object(d["jsx"])(r["View"], {
                            className: "title",
                            children: h.item_info.name
                        }), Object(d["jsx"])(r["View"], {
                            className: "desc",
                            children: h.item_info.desc
                        }) ]
                    }), Object(d["jsx"])(r["View"], {
                        style: {
                            marginTop: 20
                        },
                        children: Object(d["jsx"])(i["a"], {
                            className: "nocss-button du_btn",
                            disabled: !h.share_info.can,
                            onClick: v,
                            type: "primary",
                            size: "default",
                            children: h.share_info.can ? "收下卡片" : "来慢了,已被领取"
                        })
                    }) ]
                })
            });
        }), m = b, _ = {
            navigationBarTitleText: "领取卡片",
            enableShareAppMessage: !0
        };
        m.enableShareAppMessage = !0;
        Page(Object(n["createPageConfig"])(m, "pages/give/index", {
            root: {
                cn: []
            }
        }, _ || {}));
    }
}, [ [ 284, 0, 2, 1, 3 ] ] ]);