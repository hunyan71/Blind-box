(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 66 ], {
    238: function(e, t, c) {},
    286: function(e, t, c) {
        "use strict";
        c.r(t);
        var a = c(7), s = c(3), n = c(2), i = c(4), r = c.n(i), o = c(1), u = c(33), j = c(5), l = (c(238), 
        c(10)), b = c(60), O = c.n(b), f = c(0), x = function() {
            var e = Object(n["useState"])(""), t = Object(s["a"])(e, 2), c = t[0], a = t[1], b = Object(n["useState"])(!0), x = Object(s["a"])(b, 2), p = x[0], g = x[1], h = Object(i["useRouter"])(), m = h.params, d = Object(n["useState"])(0), w = Object(s["a"])(d, 2), v = w[0], N = w[1], k = [ "综合", "销量", "价格", "新品" ];
            Object(n["useEffect"])(function() {
                r.a.setNavigationBarTitle({
                    title: "".concat(m.s_key, "的搜索结果")
                }), a(m.s_key), L(m.s_key);
            }, []);
            var _ = Object(n["useState"])([]), V = Object(s["a"])(_, 2), B = V[0], S = V[1], y = Object(n["useState"])(1), C = Object(s["a"])(y, 2), T = C[0], E = C[1], J = Object(n["useState"])(0), P = Object(s["a"])(J, 2), R = P[0], I = P[1];
            Object(n["useEffect"])(function() {
                L("", 1);
            }, [ v ]);
            var L = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                if (!t && R >= T) return !1;
                (e || c) && Object(j["d"])({
                    url: "entry/wxapp/BoxList",
                    data: {
                        key: e || c,
                        page: t || R + 1,
                        sort: v + 1
                    },
                    success: function(e) {
                        var t = e.current_page, c = e.total_page, a = e.list;
                        p && g(!1), S(1 == t ? a : B.concat(a)), E(c), I(t);
                    }
                });
            };
            return Object(i["useReachBottom"])(function() {
                L();
            }), Object(f["jsxs"])(o["View"], {
                className: "search-result-page",
                children: [ Object(f["jsxs"])(o["View"], {
                    className: "nav_search",
                    children: [ Object(f["jsxs"])(o["View"], {
                        className: "input",
                        children: [ Object(f["jsx"])(o["Text"], {
                            className: "iconfont icon-sousuo"
                        }), Object(f["jsx"])(o["View"], {
                            className: "input_value",
                            onClick: function() {
                                return r.a.navigateBack();
                            },
                            children: c
                        }) ]
                    }), Object(f["jsx"])(o["View"], {
                        className: "notice",
                        onClick: function() {
                            return r.a.navigateBack();
                        },
                        children: "取消"
                    }) ]
                }), Object(f["jsx"])(o["View"], {
                    className: "sort",
                    children: k.map(function(e, t) {
                        return Object(f["jsxs"])(o["View"], {
                            onClick: function() {
                                return N(t);
                            },
                            className: "sort_row ".concat(t == v ? "sort_row_active" : ""),
                            children: [ e, " ", 2 == t ? Object(f["jsx"])(o["Image"], {
                                src: O.a,
                                className: "sortpng"
                            }) : null ]
                        }, t);
                    })
                }), 0 == B.length ? Object(f["jsx"])(l["a"], {
                    title: p ? "正在搜着中..." : "没有找到与“".concat(c, "”的结果")
                }) : Object(f["jsxs"])(o["View"], {
                    className: "data-list",
                    children: [ B.map(function(e, t) {
                        return Object(f["jsx"])(u["a"], {
                            item: e
                        }, t);
                    }), R >= T ? Object(f["jsx"])(o["View"], {
                        className: "footer-desc",
                        children: "已经到底拉~"
                    }) : null ]
                }) ]
            });
        }, p = x, g = {
            navigationBarTitleText: "搜索结果"
        };
        Page(Object(a["createPageConfig"])(p, "pages/search/result/index", {
            root: {
                cn: []
            }
        }, g || {}));
    }
}, [ [ 286, 0, 2, 1, 3 ] ] ]);