(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 48 ], {
    224: function(e, t, a) {},
    277: function(e, t, a) {
        "use strict";
        a.r(t);
        var i = a(7), c = a(3), n = a(2), s = a(4), r = a.n(s), l = a(1), o = (a(224), a(5)), u = a(0), f = function() {
            var e = Object(s["useRouter"])(), t = Object(n["useState"])({}), a = Object(c["a"])(t, 2), i = a[0], f = a[1];
            Object(n["useEffect"])(function() {
                j();
            }, []);
            var j = function() {
                Object(o["d"])({
                    url: "entry/wxapp/HelpDetails",
                    data: {
                        id: e.params.id
                    },
                    success: function(e) {
                        f(e), r.a.setNavigationBarTitle({
                            title: e.title
                        });
                    }
                });
            };
            return Object(u["jsxs"])(l["View"], {
                className: "details-page",
                children: [ Object(u["jsx"])(l["View"], {
                    className: "title",
                    children: i.title
                }), Object(u["jsx"])(l["View"], {
                    className: "text",
                    children: i.text
                }) ]
            });
        }, j = f, p = {
            navigationBarTitleText: "",
            navigationBarBackgroundColor: "#f6f6f6"
        };
        Page(Object(i["createPageConfig"])(j, "pages/my/help/details/index", {
            root: {
                cn: []
            }
        }, p || {}));
    }
}, [ [ 277, 0, 2, 1, 3 ] ] ]);