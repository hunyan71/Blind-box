(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 3 ], {
    10: function(e, t, s) {
        "use strict";
        s(2);
        var c = s(1), n = s(0), i = function(e) {
            var t = e.title, s = e.style;
            return Object(n["jsx"])(c["View"], {
                className: "data-empty",
                style: s,
                children: Object(n["jsx"])(c["Text"], {
                    className: "iconfont icon-empty",
                    children: Object(n["jsx"])(c["Text"], {
                        className: "text",
                        children: t || "暂无数据"
                    })
                })
            });
        };
        t["a"] = i;
    },
    101: function(e, t, s) {},
    102: function(e, t, s) {},
    103: function(e, t, s) {
        e.exports = s.p + "assets/images/my/message.png";
    },
    124: function(e, t, s) {
        e.exports = s.p + "assets/images/music.png";
    },
    125: function(e, t, s) {
        e.exports = s.p + "assets/images/music_no.png";
    },
    126: function(e, t, s) {
        e.exports = s.p + "assets/images/open-box-tip.gif";
    },
    127: function(e, t, s) {
        e.exports = s.p + "assets/images/open-loading.gif";
    },
    14: function(e, t, s) {
        "use strict";
        var c = s(13), n = s(3), i = s(2), a = s(4), l = s.n(a), r = s(1), o = (s(15), s(0)), d = function(e) {
            var t = Object(i["useState"])(!1), s = Object(n["a"])(t, 2), a = s[0], d = s[1];
            Object(i["useEffect"])(function() {
                var e = wx.getStorageSync("getUserProfile");
                d(1 == e);
            }, []);
            var j = function(t) {
                l.a.showLoading({
                    title: "授权中..."
                }), getApp().$app.util.getUserProfile(function(s) {
                    console.log(s), e.onClick && e.onClick(t, s), l.a.hideLoading();
                });
            };
            return Object(o["jsx"])(r["View"], {
                children: a ? Object(o["jsx"])(r["Button"], Object(c["a"])(Object(c["a"])({}, e), {}, {
                    children: e.children
                })) : Object(o["jsx"])(r["Button"], Object(c["a"])(Object(c["a"])({}, e), {}, {
                    onClick: j,
                    children: e.children
                }))
            });
        };
        t["a"] = d;
    },
    15: function(e, t, s) {
        "use strict";
        s.d(t, "a", function() {
            return o;
        }), s.d(t, "c", function() {
            return d;
        }), s.d(t, "d", function() {
            return j;
        }), s.d(t, "b", function() {
            return u;
        });
        var c = s(41), n = s.n(c), i = s(54), a = s(13), l = s(4), r = s.n(l), o = function() {
            var e = Object(l["getSystemInfoSync"])(), t = e.safeArea, s = e.screenHeight, c = e.model, n = s - t.bottom;
            return Object(a["a"])(Object(a["a"])({}, t), {}, {
                paddingBottom: n,
                isIphoneX: 0 == c.indexOf("iPhone X"),
                paddingTop: t.top
            });
        }, d = function(e) {
            var t = wx.getSystemInfoSync().windowWidth;
            return e.replace(/\<img/gi, '<img style="width:' + t + 'px;vertical-align: middle;"');
        }, j = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], s = getApp().$app;
            s.util.getUserInfo(function() {
                e && e();
            }, t);
        }, u = function() {
            var e = Object(i["a"])(n.a.mark(function e(t, s) {
                var c;
                return n.a.wrap(function(e) {
                    while (1) switch (e.prev = e.next) {
                      case 0:
                        return t || s && s(!1), e.next = 3, r.a.getSetting();

                      case 3:
                        c = e.sent, s && s(!!c["authSetting"][t]);

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t, s) {
                return e.apply(this, arguments);
            };
        }();
    },
    16: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(2), i = (s(4), s(1)), a = s(15), l = s(0), r = function(e) {
            var t = e.children, s = e.title, r = e.onClose, o = e.show, d = e.contentClass, j = e.headClass, u = e.footerClass, b = Object(n["useState"])({}), x = Object(c["a"])(b, 2), m = x[0], h = x[1], O = Object(n["useState"])(!1), _ = Object(c["a"])(O, 2), p = _[0], w = _[1];
            Object(n["useEffect"])(function() {
                h(Object(a["a"])());
            }, []), Object(n["useEffect"])(function() {
                !1 === o && f();
            }, [ o ]);
            var f = function() {
                w(!0), setTimeout(function() {
                    r && r(), w(!1);
                }, 280);
            };
            return Object(l["jsx"])(i["View"], {
                className: "dialog",
                children: Object(l["jsxs"])(i["View"], {
                    className: "content ".concat(p ? "fadeOutIn" : "fadelogIn"),
                    style: {
                        paddingBottom: "".concat(m.paddingBottom, "px")
                    },
                    children: [ Object(l["jsxs"])(i["View"], {
                        className: "".concat(j, " head"),
                        children: [ Object(l["jsx"])(i["View"], {
                            className: "title",
                            children: s
                        }), Object(l["jsx"])(i["Text"], {
                            onClick: f,
                            className: "iconfont icon-baseline-close-px"
                        }) ]
                    }), Object(l["jsx"])(i["View"], {
                        className: d,
                        children: t
                    }), Object(l["jsx"])(i["View"], {
                        className: "".concat(u, " footer")
                    }) ]
                })
            });
        };
        t["a"] = r;
    },
    205: function(e, t, s) {},
    207: function(e, t, s) {},
    209: function(e, t, s) {},
    212: function(e, t, s) {},
    213: function(e, t, s) {
        e.exports = s.p + "assets/images/box-dot.png";
    },
    242: function(e, t, s) {},
    30: function(e, t, s) {
        "use strict";
        s(2);
        var c = s(4), n = s.n(c), i = s(1), a = s(124), l = s.n(a), r = s(125), o = s.n(r), d = s(0), j = function(e) {
            var t = e.safeArea, s = (e.title, e.one), c = e.pauseMp3, a = e.bgMp3Pased, r = e.pageConfig, j = n.a.getMenuButtonBoundingClientRect(), u = n.a.getSystemInfoSync(), b = j.top - t.top, x = j.height + 2 * b, m = u.windowWidth - j.left - 15, h = {
                height: "".concat(x, "px"),
                lineHeight: "".concat(x, "px")
            }, O = {
                height: "".concat(j.height, "px"),
                width: "".concat(j.height, "px"),
                borderRadius: "".concat(j.height, "px")
            }, _ = {
                width: "".concat(j.width, "px")
            }, p = function() {
                var e = getCurrentPages().length;
                1 == e ? n.a.switchTab({
                    url: "/pages/index/index",
                    fail: function() {
                        n.a.redirectTo({
                            url: "/pages/index/index"
                        });
                    }
                }) : n.a.navigateBack();
            };
            return Object(d["jsxs"])(i["View"], {
                className: "header-com",
                style: h,
                children: [ Object(d["jsx"])(i["View"], {
                    className: "header-left",
                    style: _,
                    children: Object(d["jsx"])(i["View"], {
                        className: "back",
                        style: O,
                        onClick: p,
                        children: Object(d["jsx"])(i["Text"], {
                            className: "iconfont icon-biaoqing"
                        })
                    })
                }), Object(d["jsx"])(i["View"], {
                    className: "title"
                }), !s && r.page_bg_music ? Object(d["jsx"])(i["View"], {
                    className: "music",
                    onClick: c,
                    children: a ? Object(d["jsx"])(i["Image"], {
                        src: o.a,
                        className: "iconmusic "
                    }) : Object(d["jsx"])(i["Image"], {
                        src: l.a,
                        className: "iconmusic z"
                    })
                }) : null, Object(d["jsx"])(i["View"], {
                    style: {
                        width: "".concat(m, "px")
                    }
                }) ]
            });
        };
        t["a"] = j;
    },
    33: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(2), i = s.n(n), a = s(4), l = s.n(a), r = s(1), o = (s(205), 
        s(5)), d = s(0), j = function(e) {
            var t = e.size, s = e.item, i = e.recommend, a = Object(n["useState"])({}), j = Object(c["a"])(a, 2), u = j[0], b = j[1];
            Object(n["useEffect"])(function() {
                Object(o["f"])(b);
            }, []);
            var x = function() {
                var e = s.style_type;
                2 == e ? l.a.navigateTo({
                    url: "/pages/mch/details/index?id=".concat(s.id)
                }) : l.a.navigateTo({
                    url: "/pages/detail/index?id=".concat(s.id)
                });
            }, m = function() {
                return parseInt(s.batch.sold_num / s.batch.stock * 100);
            };
            return Object(d["jsxs"])(r["View"], {
                className: "item-com ".concat("mini" == t ? "item-mini" : ""),
                onClick: x,
                children: [ 2 == s.type && s.batch ? Object(d["jsxs"])(r["View"], {
                    className: "btach_no b-shadow",
                    children: [ "第", s.batch.batch_no, "期" ]
                }) : null, Object(d["jsx"])(r["Image"], {
                    mode: "widthFix",
                    className: "image",
                    src: "".concat(u.attachurl).concat(1 == i && s.recommend_image ? s.recommend_image : s.item_image)
                }), Object(d["jsxs"])(r["View"], {
                    className: "info",
                    children: [ 2 == s.type ? Object(d["jsxs"])(r["View"], {
                        className: "pross",
                        children: [ Object(d["jsxs"])(r["View"], {
                            className: "text",
                            children: [ "开奖进度", m(), "%" ]
                        }), Object(d["jsx"])(r["View"], {
                            className: "bg",
                            style: {
                                width: "".concat(m(), "%")
                            }
                        }) ]
                    }) : null, Object(d["jsx"])(r["View"], {
                        className: "title",
                        children: s.title
                    }), Object(d["jsxs"])(r["View"], {
                        className: "price-info",
                        children: [ Object(d["jsxs"])(r["View"], {
                            className: "price",
                            children: [ Object(d["jsx"])(r["Text"], {
                                className: "yuan",
                                children: "¥"
                            }), Object(o["i"])(s.price) ]
                        }), Object(d["jsxs"])(r["View"], {
                            className: "buy_num",
                            children: [ "已售", s.sold, "盒" ]
                        }) ]
                    }) ]
                }) ]
            });
        };
        t["a"] = i.a.memo(j);
    },
    34: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(2), i = s.n(n), a = s(4), l = s.n(a), r = s(1), o = s(127), d = s.n(o), j = s(5), u = (s(77), 
        s(242), s(0)), b = function(e) {
            var t = e.orderNo, s = e.onClose, i = Object(n["useState"])(!1), a = Object(c["a"])(i, 2), o = a[0], b = a[1], x = Object(n["useState"])([]), m = Object(c["a"])(x, 2), h = m[0], O = m[1], _ = Object(n["useState"])([]), p = Object(c["a"])(_, 2), w = p[0], f = p[1], g = Object(n["useState"])(-2), v = Object(c["a"])(g, 2), y = v[0], N = v[1], k = Object(n["useState"])({}), V = Object(c["a"])(k, 2), S = V[0], C = V[1], T = Object(n["useState"])(!1), I = Object(c["a"])(T, 2), B = I[0], F = I[1], D = Object(n["useState"])(-1), L = Object(c["a"])(D, 2), M = L[0], E = L[1], z = function(e) {
                E(e), b(!1), setTimeout(function() {
                    b(!0), e + 1 == y && F(!0);
                }, 3e3);
            }, H = function() {
                F(!0), b(!1), setTimeout(function() {
                    b(!0);
                }, 3e3);
            }, P = function() {
                l.a.switchTab({
                    url: "/pages/box/index"
                });
            };
            Object(n["useEffect"])(function() {
                Object(j["f"])(C), q();
            }, []);
            var q = function e() {
                var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                Object(j["d"])({
                    url: "entry/wxapp/orderStatus",
                    data: {
                        order_no: t
                    },
                    success: function(e) {
                        var t = e.item, s = e.num, c = e.type;
                        f(c), O(t), N(s), z(0);
                    },
                    fail: function() {
                        console.log(t, "fail", s), s < 30 && setTimeout(function() {
                            e(t, s + 1);
                        }, 1e3);
                    }
                });
            }, R = function() {
                return Object(u["jsxs"])(r["View"], {
                    className: "box popIn",
                    children: [ Object(u["jsx"])(r["Image"], {
                        src: d.a,
                        className: "open-gif",
                        mode: "widthFix"
                    }), Object(u["jsxs"])(r["View"], {
                        className: "desc",
                        children: [ y > 1 ? Object(u["jsxs"])(r["View"], {
                            style: {
                                margin: "10px 0"
                            },
                            children: [ "正在打开", B ? "所有" : "第".concat(M + 1, "个"), "盒子,共", y, "个" ]
                        }) : null, Object(u["jsxs"])(r["View"], {
                            className: "b-f",
                            children: [ Object(u["jsx"])(r["View"], {
                                children: "您抽奖的物品已经存入盒柜中"
                            }), Object(u["jsx"])(r["View"], {
                                children: "可进入 [盒柜] 查看"
                            }) ]
                        }) ]
                    }) ]
                });
            }, K = function(e) {
                E(e ? 0 == M ? y - 1 : M - 1 : M == y - 1 ? 0 : M + 1);
            }, A = function() {
                return Object(u["jsxs"])(r["View"], {
                    className: "box-r popIn",
                    children: [ Object(u["jsxs"])(r["View"], {
                        className: "desc",
                        children: [ y > 1 ? Object(u["jsxs"])(r["View"], {
                            children: [ "第", M + 1, "个盒子,共", y, "个" ]
                        }) : null, Object(u["jsx"])(r["View"], {
                            children: "您抽奖物品已经存入盒柜中"
                        }), Object(u["jsx"])(r["View"], {
                            children: "可进入 [盒柜] 查看"
                        }) ]
                    }), Object(u["jsxs"])(r["View"], {
                        className: "result",
                        children: [ B ? Object(u["jsxs"])(r["View"], {
                            className: "sw-items",
                            children: [ Object(u["jsx"])(r["Text"], {
                                className: "iconfont icon-jiantou left-a",
                                onClick: function() {
                                    return K(0);
                                }
                            }), Object(u["jsx"])(r["Text"], {
                                className: "iconfont icon-jiantou left-r",
                                onClick: function() {
                                    return K(1);
                                }
                            }), Object(u["jsx"])(r["Swiper"], {
                                className: "bb",
                                current: M,
                                onChange: function(e) {
                                    return E(e.detail.current);
                                },
                                children: h.map(function(e, t) {
                                    return Object(u["jsx"])(r["SwiperItem"], {
                                        className: "bb",
                                        children: Object(u["jsx"])(r["Image"], {
                                            className: "bb",
                                            mode: "heightFix",
                                            src: "".concat(S.attachurl).concat(e.image)
                                        })
                                    }, t);
                                })
                            }) ]
                        }) : Object(u["jsx"])(r["Image"], {
                            className: "bb",
                            mode: "heightFix",
                            src: "".concat(S.attachurl).concat(h[M].image)
                        }), 2 == w ? Object(u["jsxs"])(r["View"], {
                            className: "batch_no",
                            children: [ "第", h[M].batch_no, "期" ]
                        }) : null ]
                    }), Object(u["jsx"])(r["View"], {
                        className: "footer-t"
                    }), Object(u["jsxs"])(r["View"], {
                        className: "footer",
                        children: [ Object(u["jsx"])(r["View"], {
                            children: h[M].name
                        }), 2 == w ? Object(u["jsx"])(r["View"], {
                            children: h[M].code
                        }) : null ]
                    }), Object(u["jsx"])(r["View"], {
                        className: "footer-z"
                    }) ]
                });
            };
            return Object(u["jsxs"])(r["View"], {
                className: "open-box",
                children: [ o ? (2 == h[0].type && h.length, A()) : R(), 1 == y ? Object(u["jsxs"])(r["View"], {
                    className: "btns",
                    children: [ o ? Object(u["jsx"])(r["Button"], {
                        className: "nocss-button aa",
                        onClick: P,
                        children: "我的盒柜"
                    }) : null, o ? Object(u["jsx"])(r["Button"], {
                        className: "nocss-button bb",
                        onClick: function() {
                            return s && s();
                        },
                        children: "再开一盒"
                    }) : null ]
                }) : M + 1 == y || B ? Object(u["jsxs"])(r["View"], {
                    className: "btns",
                    children: [ o ? Object(u["jsx"])(r["Button"], {
                        className: "nocss-button aa",
                        onClick: P,
                        children: "我的盒柜"
                    }) : null, o ? Object(u["jsx"])(r["Button"], {
                        className: "nocss-button bb",
                        onClick: function() {
                            return s && s();
                        },
                        children: "再买几盒"
                    }) : null ]
                }) : Object(u["jsxs"])(r["View"], {
                    className: "btns",
                    children: [ o ? Object(u["jsx"])(r["Button"], {
                        className: "nocss-button aa",
                        onClick: H,
                        children: "全部开完"
                    }) : null, o ? Object(u["jsx"])(r["Button"], {
                        className: "nocss-button bb",
                        onClick: function() {
                            return z(M + 1);
                        },
                        children: "开下一盒"
                    }) : null ]
                }) ]
            });
        };
        t["a"] = i.a.memo(b);
    },
    35: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(2), i = s.n(n), a = s(4), l = s.n(a), r = s(1), o = s(13), d = s(40), j = s.n(d), u = s(16), b = s(5), x = s(9), m = s(10), h = s(14), O = s(0), _ = function(e) {
            var t = e.boxId, s = (e.show, e.showOpenBox), i = e.batchConfig, a = e.setShow, d = e.one, _ = e.requestBoxDetails, p = e.hideDiy, w = (e.onClose, 
            Object(n["useState"])(!0)), f = Object(c["a"])(w, 2), g = f[0], v = f[1], y = Object(n["useState"])([]), N = Object(c["a"])(y, 2), k = N[0], V = N[1], S = Object(n["useState"])(0), C = Object(c["a"])(S, 2), T = C[0], I = C[1], B = Object(n["useState"])(0), F = Object(c["a"])(B, 2), D = F[0], L = F[1], M = Object(n["useState"])(0), E = Object(c["a"])(M, 2), z = E[0], H = E[1], P = Object(n["useState"])(0), q = Object(c["a"])(P, 2), R = q[0], K = q[1], A = Object(n["useState"])(!1), U = Object(c["a"])(A, 2), Y = U[0], Z = U[1], $ = Object(n["useState"])(0), W = Object(c["a"])($, 2), X = W[0], J = W[1], G = Object(n["useState"])(0), Q = Object(c["a"])(G, 2), ee = Q[0], te = Q[1], se = Object(n["useState"])(0), ce = Object(c["a"])(se, 2), ne = ce[0], ie = ce[1], ae = Object(n["useState"])(!1), le = Object(c["a"])(ae, 2), re = le[0], oe = le[1], de = Object(n["useState"])(0), je = Object(c["a"])(de, 2), ue = je[0], be = je[1], xe = Object(n["useState"])(!1), me = Object(c["a"])(xe, 2), he = me[0], Oe = me[1], _e = Object(n["useState"])([]), pe = Object(c["a"])(_e, 2), we = pe[0], fe = pe[1], ge = Object(n["useState"])(!1), ve = Object(c["a"])(ge, 2), ye = ve[0], Ne = ve[1], ke = Object(n["useState"])({}), Ve = Object(c["a"])(ke, 2), Se = Ve[0], Ce = Ve[1];
            Object(n["useEffect"])(function() {
                Object(b["f"])(Ce);
                var e = -1 == ee || ee > 1e3 ? 1e3 : ee;
                ue > e && be(e), ue < 1 && be(1);
            }, [ ue ]);
            var Te = function(e) {
                s && s(e);
            }, Ie = function() {
                a(!1), l.a.showLoading({
                    title: "请求支付中..."
                }), Object(b["d"])({
                    url: "entry/wxapp/payConfig",
                    data: {
                        bid: t,
                        num: ue,
                        coupon_id: ye ? ye.id : 0
                    },
                    success: function(e) {
                        var t = e.order_no, s = [];
                        Se.submsg_open && i && s.push(Se.submsg_open), s.push(Se.submsg_2), Object(b["g"])(s, function() {
                            e.need_pay ? l.a.requestPayment(Object(o["a"])({}, e.pay_config)).then(function(e) {
                                _ && _(), Te(t);
                            }).catch(function(e) {
                                var t = e.errMsg;
                                "requestPayment:fail cancel" == t ? l.a.showToast({
                                    title: "取消支付",
                                    icon: "none"
                                }) : l.a.showToast({
                                    title: "支付失败",
                                    icon: "none"
                                });
                            }) : (_ && _(), Te(t));
                        });
                    }
                });
            }, Be = function() {
                v(!0), Object(b["d"])({
                    url: "entry/wxapp/PayInfo",
                    data: {
                        bid: t,
                        one: d ? 1 : 0
                    },
                    success: function(e) {
                        V(e.num_list), fe(e.user_coupons), I(e.balance), L(e.unit_price), te(e.can_buy_num), 
                        i && Z(i.stock - i.sold_num), be(e.num_list[0]), setTimeout(function() {
                            v(!1);
                        }, 500);
                    }
                });
            }, Fe = function() {
                var e = 0;
                if (-2 != z ? (e = k[z], be(e)) : e = ue, ye && 0 != ye.limit && D * e < ye.limit) Ne(!1); else {
                    var t = ye ? ye.price : 0, s = D * e, c = s < t ? 0 : s - t;
                    K(s), J(T >= c ? 0 : c - T), ie(T >= c ? c : T);
                }
            };
            Object(n["useEffect"])(Fe, [ z, D, k, ue, ye ]), Object(n["useEffect"])(function() {
                v(!1), Be();
            }, []);
            var De = function(e) {
                H(-2), be(e);
            }, Le = function() {
                return Object(O["jsx"])(u["a"], {
                    title: "请设置购买数量",
                    onClose: function() {
                        return oe(!1);
                    },
                    children: Object(O["jsxs"])(r["View"], {
                        className: "buy-content",
                        children: [ !1 !== Y ? Object(O["jsxs"])(r["View"], {
                            className: "stock",
                            children: [ "本期剩余 ", Object(O["jsx"])(r["Text"], {
                                className: "r",
                                children: Y
                            }), " 件" ]
                        }) : null, Object(O["jsxs"])(r["View"], {
                            className: "input-num",
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "a-btn a-btn-r",
                                onClick: function() {
                                    return De(ue > 1 ? ue - 1 : ue);
                                },
                                children: "-"
                            }), Object(O["jsx"])(r["View"], {
                                className: "input",
                                children: Object(O["jsx"])(r["Input"], {
                                    className: "in",
                                    type: "number",
                                    value: ue,
                                    onInput: function(e) {
                                        return De(e.detail.value);
                                    }
                                })
                            }), Object(O["jsx"])(r["View"], {
                                className: "a-btn ",
                                onClick: function() {
                                    return De(ue + 1);
                                },
                                children: "+"
                            }) ]
                        }), !1 !== Y ? Object(O["jsxs"])(r["View"], {
                            className: "select-btns",
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(20);
                                },
                                children: "20"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(50);
                                },
                                children: "50"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(100);
                                },
                                children: "100"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(Y);
                                },
                                children: "扫尾"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(Math.ceil(.1 * Y));
                                },
                                children: "10%"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(Math.ceil(.2 * Y));
                                },
                                children: "20%"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(Math.ceil(.3 * Y));
                                },
                                children: "30%"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(Math.ceil(.5 * Y));
                                },
                                children: "50%"
                            }) ]
                        }) : Object(O["jsxs"])(r["View"], {
                            className: "select-btns",
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(20);
                                },
                                children: "20"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(50);
                                },
                                children: "50"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(100);
                                },
                                children: "100"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(200);
                                },
                                children: "200"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(400);
                                },
                                children: "400"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(600);
                                },
                                children: "600"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(800);
                                },
                                children: "800"
                            }), Object(O["jsx"])(r["View"], {
                                className: "select",
                                onClick: function() {
                                    return De(1e3);
                                },
                                children: "1000"
                            }) ]
                        }), Object(O["jsxs"])(r["View"], {
                            className: "i-desc",
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "title",
                                children: "购买说明"
                            }), Object(O["jsx"])(r["View"], {
                                children: "1、购买越多，抽中的概率越高"
                            }), Object(O["jsx"])(r["View"], {
                                children: "2、单次最多购买1000盒。"
                            }), !1 !== Y ? Object(O["jsx"])(r["View"], {
                                children: "3、购买数量超过本期剩余数量时，系统将自动购买下一期"
                            }) : null ]
                        }), Object(O["jsx"])(r["View"], {
                            children: Object(O["jsx"])(r["Button"], {
                                type: "primary",
                                size: "default",
                                onClick: function() {
                                    return oe(!1);
                                },
                                children: "确定"
                            })
                        }) ]
                    })
                });
            }, Me = function(e, t) {
                return 0 != e.limit && e.limit > R ? null : Object(O["jsxs"])(r["View"], {
                    className: "coupon",
                    onClick: function() {
                        Ne(e), Oe(!1);
                    },
                    children: [ Object(O["jsxs"])(r["View"], {
                        className: "c-left",
                        children: [ Object(O["jsx"])(r["View"], {
                            className: "desc",
                            children: 0 == e.limit ? "无门槛" : "满".concat(Object(b["i"])(e.limit), "元可用")
                        }), Object(O["jsxs"])(r["View"], {
                            className: "ppr",
                            children: [ Object(O["jsx"])(r["Text"], {
                                className: "yuan",
                                children: "¥"
                            }), Object(b["i"])(e.price) ]
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        className: "c-right",
                        children: [ Object(O["jsx"])(r["View"], {
                            className: "title",
                            children: e.name
                        }), 0 == e.status ? Object(O["jsxs"])(r["View"], {
                            className: "desc",
                            children: [ "有效期至 ", -1 == e.expr ? "永不过期" : e.expr ]
                        }) : null, 2 == e.status ? Object(O["jsx"])(r["View"], {
                            className: "desc",
                            children: "已使用"
                        }) : null, 3 == e.status ? Object(O["jsx"])(r["View"], {
                            className: "desc",
                            children: "已过期"
                        }) : null ]
                    }) ]
                }, t);
            }, Ee = function() {
                return Object(O["jsx"])(u["a"], {
                    title: "选择优惠券",
                    onClose: function() {
                        return Oe(!1);
                    },
                    children: Object(O["jsxs"])(r["View"], {
                        className: "buy-content",
                        style: {
                            minHeight: "500px"
                        },
                        children: [ 0 == we.length ? Object(O["jsx"])(m["a"], {}) : null, we.map(Me) ]
                    })
                });
            };
            return Object(O["jsxs"])(u["a"], {
                title: "购买",
                onClose: function() {
                    return a(!1);
                },
                children: [ g ? Object(O["jsx"])(x["a"], {
                    style: {
                        height: "350px"
                    },
                    iconStyle: {
                        color: "rgba(0,0,0,0.4)"
                    }
                }) : Object(O["jsxs"])(r["View"], {
                    className: "buy-content",
                    children: [ Object(O["jsxs"])(r["View"], {
                        className: "buy-row",
                        children: [ Object(O["jsx"])(r["View"], {
                            className: "label",
                            children: "购买数量"
                        }), Object(O["jsxs"])(r["View"], {
                            className: "value",
                            children: [ k.map(function(e, t) {
                                return Object(O["jsxs"])(r["View"], {
                                    onClick: function() {
                                        return H(t);
                                    },
                                    className: "sku ".concat(t == z ? "sku-a" : ""),
                                    children: [ "开", e, "盒" ]
                                }, t);
                            }), p ? null : Object(O["jsx"])(r["View"], {
                                onClick: function() {
                                    return oe(!0);
                                },
                                className: "sku ".concat(-2 == z ? "sku-a" : ""),
                                children: -2 == z ? "开".concat(ue, "盒") : "自定义"
                            }) ]
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        className: "buy-row",
                        children: [ Object(O["jsx"])(r["View"], {
                            className: "label",
                            children: "单价"
                        }), Object(O["jsxs"])(r["View"], {
                            className: "value price",
                            children: [ "￥", Object(b["i"])(D) ]
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        className: "buy-row",
                        children: [ Object(O["jsx"])(r["View"], {
                            className: "label",
                            children: "订单金额"
                        }), Object(O["jsxs"])(r["View"], {
                            className: "value price",
                            children: [ "￥", Object(b["i"])(R) ]
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        className: "buy-row",
                        onClick: function() {
                            return Oe(!0);
                        },
                        children: [ Object(O["jsx"])(r["View"], {
                            className: "label",
                            children: "优惠券"
                        }), ye ? Object(O["jsxs"])(r["View"], {
                            className: "value price",
                            children: [ ye.name, "(-", Object(b["i"])(ye.price), "元)" ]
                        }) : Object(O["jsx"])(r["View"], {
                            className: "value noq",
                            children: "点击选择"
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        className: "ban",
                        children: [ Object(O["jsxs"])(r["View"], {
                            className: "text",
                            children: [ Object(O["jsx"])(r["Text"], {
                                className: "iconfont icon-yuebao"
                            }), Object(O["jsxs"])(r["Text"], {
                                children: [ "余额支付￥", Object(b["i"])(ne) ]
                            }) ]
                        }), Object(O["jsxs"])(r["View"], {
                            className: "desc",
                            children: [ "当前余额￥", Object(b["i"])(T) ]
                        }), Object(O["jsx"])(r["Image"], {
                            className: "ej",
                            src: j.a
                        }) ]
                    }), Object(O["jsxs"])(r["View"], {
                        className: "need-pay",
                        children: [ "您还需要支付￥", Object(O["jsx"])(r["Text"], {
                            className: "yuan",
                            children: Object(b["i"])(X)
                        }) ]
                    }), Object(O["jsx"])(r["View"], {
                        children: Object(O["jsxs"])(h["a"], {
                            className: "nocss-botton pay-btn",
                            type: "primary",
                            size: "default",
                            onClick: Ie,
                            children: [ X > 0 ? "微信" : "余额", "支付" ]
                        })
                    }) ]
                }), re ? Le() : null, he ? Ee() : null ]
            });
        }, p = _, w = s(15), f = s(62), g = function(e) {
            var t = e.boxId, s = (e.config, Object(n["useState"])([])), i = Object(c["a"])(s, 2), a = i[0], l = i[1], o = Object(n["useState"])(0), d = Object(c["a"])(o, 2), j = d[0], u = d[1], h = Object(n["useState"])(!0), _ = Object(c["a"])(h, 2), p = _[0], w = _[1], f = Object(n["useState"])(1), g = Object(c["a"])(f, 2), v = g[0], y = g[1], N = Object(n["useState"])(!1), k = Object(c["a"])(N, 2), V = k[0], S = k[1];
            Object(n["useEffect"])(function() {
                C();
            }, []);
            var C = function() {
                j >= v || (S(!0), Object(b["d"])({
                    url: "entry/wxapp/BoxBarrageList",
                    data: {
                        bid: t,
                        page: parseInt(j) + 1
                    },
                    success: function(e) {
                        var t = e.list, s = e.current_page, c = e.total_page;
                        l(a.concat(t)), y(c), u(s), setTimeout(function() {
                            w(!1), S(!1);
                        }, 300);
                    }
                }));
            }, T = function(e, t) {
                return Object(O["jsxs"])(r["View"], {
                    className: "b-r",
                    children: [ Object(O["jsxs"])(r["View"], {
                        className: "b-head",
                        children: [ Object(O["jsx"])(r["Image"], {
                            className: "avatar",
                            src: e.user_avatar
                        }), Object(O["jsxs"])(r["View"], {
                            className: "nickname",
                            children: [ Object(O["jsx"])(r["View"], {
                                children: e.user_nickname
                            }), Object(O["jsx"])(r["View"], {
                                className: "time",
                                children: e.time
                            }) ]
                        }), Object(O["jsx"])(r["View"], {
                            className: "time"
                        }) ]
                    }), Object(O["jsx"])(r["View"], {
                        className: "b-head b-top",
                        children: Object(O["jsx"])(r["View"], {
                            className: "item-name",
                            children: Object(O["jsx"])(r["View"], {
                                children: e.message
                            })
                        })
                    }) ]
                }, t);
            };
            return Object(O["jsxs"])(r["ScrollView"], {
                className: "barrage-log-list",
                scrollY: !0,
                onScrollToLower: C,
                children: [ p ? Object(O["jsx"])(x["a"], {
                    style: {
                        height: "200px"
                    },
                    iconStyle: {
                        color: "rgba(0,0,0,0.5)"
                    }
                }) : a.map(T), a.length > 0 && !p && j >= v ? Object(O["jsx"])(r["View"], {
                    className: "footer-desc",
                    children: "已经到底拉~"
                }) : null, 0 != a.length || p ? null : Object(O["jsx"])(m["a"], {
                    title: "暂无弹幕"
                }), !p && V ? Object(O["jsx"])(x["a"], {
                    style: {
                        height: "40px"
                    },
                    iconStyle: {
                        color: "rgba(0,0,0,0.5)"
                    }
                }) : null ]
            });
        }, v = g, y = function(e) {
            var t = e.boxId, s = e.config, i = Object(n["useState"])([]), a = Object(c["a"])(i, 2), o = a[0], d = a[1], j = Object(n["useState"])(0), u = Object(c["a"])(j, 2), h = u[0], _ = u[1], p = Object(n["useState"])(!0), w = Object(c["a"])(p, 2), f = w[0], g = w[1], v = Object(n["useState"])(1), y = Object(c["a"])(v, 2), N = y[0], k = y[1], V = Object(n["useState"])(!1), S = Object(c["a"])(V, 2), C = S[0], T = S[1];
            Object(n["useEffect"])(function() {
                I();
            }, []);
            var I = function() {
                h >= N || (T(!0), Object(b["d"])({
                    url: "entry/wxapp/PrizeLogList",
                    data: {
                        bid: t,
                        page: parseInt(h) + 1
                    },
                    success: function(e) {
                        var t = e.list, s = e.current_page, c = e.total_page;
                        d(o.concat(t)), k(c), _(s), setTimeout(function() {
                            g(!1), T(!1);
                        }, 300);
                    }
                }));
            }, B = function(e, t) {
                return Object(O["jsx"])(r["View"], {
                    className: "b-r",
                    onClick: function() {
                        l.a.navigateTo({
                            url: "/pages/detail/results/index?box_id=".concat(e.box_id, "&batch_no=").concat(e.batch_no)
                        });
                    },
                    children: Object(O["jsxs"])(r["View"], {
                        className: "b-head b-head-no-border",
                        children: [ Object(O["jsx"])(r["Image"], {
                            className: "item-image",
                            src: "".concat(s.attachurl).concat(e.prize_image)
                        }), Object(O["jsxs"])(r["View"], {
                            className: "item-name",
                            children: [ Object(O["jsxs"])(r["View"], {
                                className: "r-t",
                                children: [ Object(O["jsxs"])(r["Text"], {
                                    className: "batch_no",
                                    children: [ "第", e.batch_no, "期" ]
                                }), e.prize_name ]
                            }), Object(O["jsxs"])(r["View"], {
                                className: "r-r",
                                children: [ "中奖号码：", e.code ]
                            }), Object(O["jsxs"])(r["View"], {
                                className: "r-r",
                                children: [ "开奖时间：", e.time ]
                            }), Object(O["jsxs"])(r["View"], {
                                className: "r-r",
                                children: [ "本期获奖：", Object(O["jsx"])(r["Image"], {
                                    src: e.user_avatar,
                                    style: {
                                        height: "30px",
                                        width: "30px",
                                        borderRadius: "30px"
                                    }
                                }), e.user_nickname ]
                            }) ]
                        }) ]
                    })
                }, t);
            };
            return Object(O["jsxs"])(r["ScrollView"], {
                className: "prize-log-list",
                scrollY: !0,
                onScrollToLower: I,
                children: [ f ? Object(O["jsx"])(x["a"], {
                    style: {
                        height: "200px"
                    },
                    iconStyle: {
                        color: "rgba(0,0,0,0.5)"
                    }
                }) : o.map(B, []), o.length > 0 && !f && h >= N ? Object(O["jsx"])(r["View"], {
                    className: "footer-desc",
                    children: "已经到底拉~"
                }) : null, 0 != o.length || f ? null : Object(O["jsx"])(m["a"], {
                    title: "暂无人开盒"
                }), !f && C ? Object(O["jsx"])(x["a"], {
                    style: {
                        height: "40px"
                    },
                    iconStyle: {
                        color: "rgba(0,0,0,0.5)"
                    }
                }) : null ]
            });
        }, N = y, k = function(e) {
            var t = e.showMenus, s = void 0 === t || t, i = e.boxId, a = e.detailsConfig, o = e.oneBtnText, d = e.showOpenBox, j = e.requestBoxDetails, m = e.onShowOneClose, _ = e.showOneBuy, g = e.batchConfig, y = e.baseConfig, k = e.settingConfig, V = e.className, S = e.style, C = e.showRule, T = e.showLog, I = e.onRuleClose, B = e.onLogClose, F = e.hideOneBtn, D = Object(n["useState"])(!1), L = Object(c["a"])(D, 2), M = L[0], E = L[1], z = Object(n["useState"])(!1), H = Object(c["a"])(z, 2), P = H[0], q = H[1], R = Object(n["useState"])(0), K = Object(c["a"])(R, 2), A = K[0], U = K[1], Y = Object(n["useState"])(!1), Z = Object(c["a"])(Y, 2), $ = Z[0], W = Z[1], X = Object(n["useState"])(!1), J = Object(c["a"])(X, 2), G = J[0], Q = J[1], ee = Object(n["useState"])(!1), te = Object(c["a"])(ee, 2), se = te[0], ce = te[1], ne = Object(n["useState"])(""), ie = Object(c["a"])(ne, 2), ae = ie[0], le = ie[1], re = Object(n["useState"])({}), oe = Object(c["a"])(re, 2), de = oe[0], je = oe[1];
            Object(n["useEffect"])(function() {
                T && Q(!0);
            }, [ T ]), Object(n["useEffect"])(function() {
                C && he(1 == y.type ? 0 : 1);
            }, [ C ]), Object(n["useEffect"])(function() {
                _ && _e(!0);
            }, [ _ ]), Object(n["useEffect"])(function() {
                Object(b["f"])(je);
            }, []);
            var ue = Object(n["useState"])(""), be = Object(c["a"])(ue, 2), xe = be[0], me = be[1];
            Object(n["useEffect"])(function() {
                a.text_content && me(Object(w["c"])(a.text_content)), a.text_rule && le(Object(w["c"])(a.text_rule));
            }, [ a ]);
            var he = function(e) {
                U(e), E(!0);
            }, Oe = function() {
                E(!1), I && I(!1);
            }, _e = function(e) {
                W(!0), e && ce(!0);
            }, pe = function() {
                Q(!1), B && B();
            }, we = function() {
                return Object(O["jsx"])(r["View"], {
                    className: "rich-text",
                    children: Object(O["jsx"])(r["RichText"], {
                        nodes: xe
                    })
                });
            }, fe = function() {
                return Object(O["jsx"])(r["View"], {
                    className: "rich-text",
                    children: Object(O["jsx"])(r["RichText"], {
                        nodes: ae
                    })
                });
            }, ge = function() {
                if (!M) return null;
                var e = [ "详情", "规则", "开盒记录", "中奖记录", "弹幕" ], t = Object(O["jsx"])(r["View"], {
                    className: "title-muen",
                    children: e.map(function(e, t) {
                        return 1 == y.type && 3 == t || 1 == y.type && 1 == t ? null : Object(O["jsx"])(r["View"], {
                            onClick: function() {
                                return U(t);
                            },
                            className: "m ".concat(A == t ? "m-active" : ""),
                            children: e
                        }, t);
                    })
                });
                return Object(O["jsx"])(u["a"], {
                    title: t,
                    onClose: Oe,
                    headClass: "title-head",
                    contentClass: "title-context",
                    children: Object(O["jsxs"])(r["View"], {
                        className: "d-content",
                        children: [ 0 == A ? we() : null, 1 == A ? fe() : null, 2 == A ? Object(O["jsx"])(f["a"], {
                            boxId: i,
                            config: de
                        }) : null, 4 == A ? Object(O["jsx"])(v, {
                            boxId: i,
                            config: de
                        }) : null, 3 == A ? Object(O["jsx"])(N, {
                            boxId: i,
                            config: de
                        }) : null ]
                    })
                });
            }, ve = Object(n["useState"])(!1), ye = Object(c["a"])(ve, 2), Ne = ye[0], ke = ye[1], Ve = Object(n["useState"])(""), Se = Object(c["a"])(Ve, 2), Ce = Se[0], Te = Se[1], Ie = function() {
                if (!Ce) return l.a.showToast({
                    title: "请输入弹幕内容",
                    icon: "none"
                });
                ke(!0), Object(b["d"])({
                    url: "entry/wxapp/Barrage",
                    data: {
                        bid: i,
                        message: Ce
                    },
                    success: function(e) {
                        0 == e.result && setTimeout(function() {
                            ke(!1), q(!1), l.a.showToast({
                                title: "弹幕发送成功",
                                icon: "none"
                            });
                        }, 200);
                    }
                });
            }, Be = function() {
                return P ? Object(O["jsx"])(u["a"], {
                    title: "发送弹幕",
                    onClose: function() {
                        return q(!1);
                    },
                    children: Object(O["jsx"])(r["View"], {
                        className: "buy-content",
                        children: 1 == k.dan_open ? Object(O["jsxs"])(r["View"], {
                            children: [ Object(O["jsxs"])(r["View"], {
                                className: "ban dan_input",
                                style: {
                                    marginBottom: 20
                                },
                                children: [ Object(O["jsx"])(r["Textarea"], {
                                    style: {
                                        height: "100px"
                                    },
                                    onInput: function(e) {
                                        return Te(e.detail.value);
                                    },
                                    placeholder: "请输入弹幕内容",
                                    disabled: Ne
                                }), Ne ? Object(O["jsx"])(x["a"], {
                                    style: {
                                        minHeight: "100px",
                                        position: "absolute",
                                        backgroundColor: "rgba(0,0,0,0.6)",
                                        left: 0,
                                        top: 0
                                    },
                                    iconStyle: {
                                        color: "rgba(255,255,255,0.6)"
                                    }
                                }) : null ]
                            }), Object(O["jsx"])(r["View"], {
                                children: Object(O["jsx"])(h["a"], {
                                    type: "primary",
                                    disabled: Ne,
                                    size: "default",
                                    onClick: Ie,
                                    children: "发送弹幕"
                                })
                            }) ]
                        }) : Object(O["jsx"])(r["View"], {
                            className: "dan_close",
                            style: {
                                height: "300px"
                            },
                            children: Object(O["jsx"])(r["Text"], {
                                children: "此活动弹幕已被关闭"
                            })
                        })
                    })
                }) : null;
            }, Fe = function() {
                return G ? Object(O["jsx"])(u["a"], {
                    title: "往期揭晓",
                    onClose: pe,
                    children: Object(O["jsx"])(r["View"], {
                        className: "log-content",
                        style: {
                            height: "900rpx"
                        },
                        children: Object(O["jsx"])(N, {
                            boxId: i,
                            config: de
                        })
                    })
                }) : null;
            };
            return Object(O["jsxs"])(r["View"], {
                children: [ Object(O["jsxs"])(r["View"], {
                    className: "".concat(V, " footer-render"),
                    style: S,
                    children: [ s ? Object(O["jsxs"])(r["View"], {
                        className: "muens",
                        children: [ Object(O["jsx"])(r["View"], {
                            className: "muen",
                            onClick: function() {
                                return he(0);
                            },
                            children: "详情"
                        }), Object(O["jsx"])(r["View"], {
                            className: "muen",
                            onClick: function() {
                                return he(2);
                            },
                            children: "开盒记录"
                        }), Object(O["jsx"])(r["View"], {
                            className: "muen",
                            onClick: function() {
                                return he(4);
                            },
                            children: "弹幕记录"
                        }), Object(O["jsx"])(r["View"], {
                            className: " input",
                            children: Object(O["jsxs"])(r["View"], {
                                className: "inputa",
                                onClick: function() {
                                    return q(!0);
                                },
                                children: [ Object(O["jsx"])(r["Text"], {
                                    children: "发射弹幕"
                                }), Object(O["jsx"])(r["Text"], {
                                    className: "iconfont icon-MessageFilled"
                                }) ]
                            })
                        }) ]
                    }) : null, Object(O["jsxs"])(r["View"], {
                        className: "buybar",
                        children: [ Object(O["jsxs"])(r["View"], {
                            className: "price",
                            children: [ Object(O["jsx"])(r["View"], {
                                className: "text",
                                children: y.price ? "￥".concat(Object(b["i"])(y.price)) : ""
                            }), Object(O["jsx"])(r["View"], {
                                className: "desc",
                                children: "连抽抽到不同款的概率更高喔"
                            }) ]
                        }), 1 == y.status ? Object(O["jsxs"])(r["View"], {
                            className: "f-btns",
                            children: [ F ? null : Object(O["jsx"])(r["View"], {
                                className: "aa",
                                onClick: function() {
                                    return Object(b["c"])(i);
                                },
                                children: "买单盒"
                            }), Object(O["jsx"])(r["View"], {
                                className: "bb",
                                onClick: function() {
                                    return _e();
                                },
                                children: o || "连开"
                            }) ]
                        }) : null, 2 == y.status ? Object(O["jsx"])(r["View"], {
                            className: "f-btns",
                            children: Object(O["jsx"])(r["View"], {
                                className: "bb",
                                style: {
                                    paddingLeft: "30px",
                                    paddingRight: "30px",
                                    backgroundColor: "gray"
                                },
                                children: "正在上货"
                            })
                        }) : null, 3 == y.status ? Object(O["jsx"])(r["View"], {
                            className: "f-btns",
                            children: Object(O["jsx"])(r["View"], {
                                className: "bb",
                                style: {
                                    paddingLeft: "30px",
                                    paddingRight: "30px",
                                    backgroundColor: "gray"
                                },
                                children: "已售罄"
                            })
                        }) : null ]
                    }) ]
                }), ge(), Be(), 2 == y.type ? Fe() : null, $ ? Object(O["jsx"])(p, {
                    requestBoxDetails: j,
                    batchConfig: g,
                    hideDiy: F,
                    boxId: i,
                    showOpenBox: d,
                    one: se,
                    show: $,
                    setShow: function(e) {
                        ce && ce(!1), m && m(!1), W(e);
                    }
                }) : null ]
            });
        };
        t["a"] = i.a.memo(k);
    },
    40: function(e, t, s) {
        e.exports = s.p + "assets/images/online_pay_bg.png";
    },
    44: function(e, t, s) {
        "use strict";
        s(2);
        var c = s(4), n = s.n(c), i = s(1), a = (s(212), s(213), s(0)), l = function(e) {
            var t = e.config, s = e.item, c = e.onItemClick, l = function() {
                c ? c() : n.a.navigateTo({
                    url: "/pages/box/details/index?id=".concat(s.box_id)
                });
            };
            return Object(a["jsxs"])(i["View"], {
                className: "box-list",
                onClick: l,
                children: [ Object(a["jsx"])(i["View"], {
                    className: "badge-image-v",
                    children: Object(a["jsxs"])(i["View"], {
                        className: "inf",
                        children: [ Object(a["jsx"])(i["View"], {
                            children: "当前拥有"
                        }), Object(a["jsx"])(i["View"], {
                            className: "nnnnn",
                            children: s.have_num
                        }) ]
                    })
                }), Object(a["jsx"])(i["Image"], {
                    mode: "widthFix",
                    className: "box-image",
                    src: "".concat(t.attachurl).concat(s.cabinet_image)
                }), Object(a["jsxs"])(i["View"], {
                    className: "info",
                    children: [ Object(a["jsx"])(i["View"], {
                        className: "t t-s",
                        children: s.box_title
                    }), s.item_has_count >= s.item_count ? Object(a["jsx"])(i["View"], {
                        className: "p",
                        style: {
                            width: "auto"
                        },
                        children: Object(a["jsxs"])(i["View"], {
                            className: "_num",
                            style: {
                                paddingTop: 0
                            },
                            children: [ "已收集完成，共", Object(a["jsx"])(i["Text"], {
                                className: "t-r",
                                children: s.item_count
                            }), "款" ]
                        })
                    }) : Object(a["jsx"])(i["View"], {
                        className: "p",
                        children: Object(a["jsxs"])(i["View"], {
                            className: "_num",
                            children: [ "已收集", Object(a["jsx"])(i["Text"], {
                                className: "t-r",
                                children: s.item_has_count
                            }), "款 共", s.item_count, "款" ]
                        })
                    }) ]
                }) ]
            });
        };
        t["a"] = l;
    },
    5: function(e, t, s) {
        "use strict";
        s.d(t, "c", function() {
            return l;
        }), s.d(t, "f", function() {
            return r;
        }), s.d(t, "i", function() {
            return o;
        }), s.d(t, "e", function() {
            return d;
        }), s.d(t, "b", function() {
            return j;
        }), s.d(t, "d", function() {
            return u;
        }), s.d(t, "g", function() {
            return x;
        }), s.d(t, "a", function() {
            return m;
        }), s.d(t, "h", function() {
            return h;
        });
        var c = s(13), n = s(4), i = s.n(n), a = "niuniu_mang", l = function(e) {
            i.a.navigateTo({
                url: "/pages/detail/one/index?id=".concat(e)
            });
        }, r = function(e) {
            var t = getApp().$app;
            t.config ? e && e(t.config) : u({
                url: "entry/wxapp/config",
                success: function(s) {
                    t.config = s, e && e(s);
                }
            });
        }, o = function(e) {
            return void 0 == e ? "-" : (e / 100).toFixed(2);
        }, d = function(e) {
            u({
                url: "entry/wxapp/category",
                success: function(t) {
                    e && e(t);
                }
            });
        }, j = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 10;
            return Math.ceil(Math.random() * e);
        }, u = function(e) {
            var t = getApp().$app;
            t.util.request(Object(c["a"])(Object(c["a"])({
                m: a
            }, e), {}, {
                showLoading: !1,
                success: function(t) {
                    var s = t.data;
                    0 == s.errno && e.success && e.success(s.data);
                }
            }));
        }, b = function(e) {
            u({
                url: "entry/wxapp/SaveSubscribeMessage",
                data: {
                    params: e
                },
                success: function(e) {}
            });
        }, x = function(e, t) {
            0 != e.length ? i.a.requestSubscribeMessage({
                tmplIds: e,
                success: function(e) {
                    b(e), t && t();
                },
                fail: function() {
                    t && t();
                }
            }) : t && t();
        }, m = function(e, t) {
            var s = e.jump_path, c = e.jump_type, n = e.jump_appid;
            switch (c) {
              case "0":
                return void console.log("不跳转", c);

              case "1":
                return console.log("url跳转", c, s), void i.a.navigateTo({
                    url: "/pages/webview/index?url=".concat(encodeURIComponent(s))
                });

              case "2":
                return console.log("跳转小程序", c, s, n), void (n ? i.a.navigateToMiniProgram({
                    appId: n,
                    path: s,
                    fail: function(e) {
                        var t = e.errMsg;
                        i.a.showToast({
                            title: "跳转失败:" + t,
                            icon: "none"
                        });
                    }
                }) : i.a.navigateTo({
                    url: s
                }));

              default:
                console.log("没有中规则 回调"), t && t(e);
            }
            console.log(e);
        }, h = function(e) {
            var t = new Date(e).getTime(), s = 6e4, c = 60 * s, n = 24 * c, i = 7 * n, a = 30 * n, l = new Date().getTime(), r = l - t;
            if (!(r < 0)) {
                var o, d = r / s, j = r / c, u = r / n, b = r / i, x = r / a;
                if (x >= 1 && x <= 3) o = " " + parseInt(x) + "月前"; else if (b >= 1 && b <= 3) o = " " + parseInt(b) + "周前"; else if (u >= 1 && u <= 6) o = " " + parseInt(u) + "天前"; else if (j >= 1 && j <= 23) o = " " + parseInt(j) + "小时前"; else if (d >= 1 && d <= 59) o = " " + parseInt(d) + "分钟前"; else if (r >= 0 && r <= s) o = "刚刚"; else {
                    var m = new Date();
                    m.setTime(t);
                    var h = m.getFullYear(), O = m.getMonth() + 1 < 10 ? "0" + (m.getMonth() + 1) : m.getMonth() + 1, _ = m.getDate() < 10 ? "0" + m.getDate() : m.getDate();
                    m.getHours() < 10 ? m.getHours() : m.getHours(), m.getMinutes() < 10 ? m.getMinutes() : m.getMinutes(), 
                    m.getSeconds() < 10 ? m.getSeconds() : m.getSeconds();
                    o = h + "-" + O + "-" + _;
                }
                return o;
            }
        };
    },
    60: function(e, t, s) {
        e.exports = s.p + "assets/sort.png";
    },
    61: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(4), i = s.n(n), a = s(5), l = s(1), r = s(2), o = s.n(r), d = (s(209), 
        s(0)), j = o.a.memo(function(e) {
            var t = e.showDoomm, s = e.doommData, c = function() {
                return .5 - Math.random();
            }, n = function(e, t) {
                var s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
                return Object(d["jsxs"])(l["View"], {
                    class: "aon",
                    style: {
                        animation: "first ".concat(t % 10 + (Object(a["b"])(7) - 1), "s linear forwards"),
                        top: "".concat(t % 10 * 5 + 20, "%"),
                        left: "".concat(100 + t % 10 * 5, "%")
                    },
                    children: [ Object(d["jsx"])(l["Image"], {
                        class: "avatar",
                        src: e.avatar
                    }), Object(d["jsxs"])(l["Text"], {
                        children: [ "恭喜", e.nickname, e.message ]
                    }) ]
                }, "".concat(s, "_").concat(t));
            };
            return Object(d["jsx"])(l["View"], {
                children: t && s.sort(c).map(function(e, t) {
                    return n(e, t);
                })
            });
        }), u = function() {
            var e = Object(r["useState"])([]), t = Object(c["a"])(e, 2), s = t[0], n = t[1], o = Object(r["useState"])([]), u = Object(c["a"])(o, 2), b = u[0], x = u[1], m = Object(r["useState"])(!0), h = Object(c["a"])(m, 2), O = h[0], _ = h[1], p = Object(r["useState"])(!0), w = Object(c["a"])(p, 2), f = w[0], g = w[1], v = function() {
                Object(a["d"])({
                    url: "entry/wxapp/LuckInfo",
                    success: function(e) {
                        e.length > 0 && y(e);
                    }
                });
            };
            Object(r["useEffect"])(function() {
                i.a.getStorageSync("autoCloseDan") || v();
            }, []);
            var y = function(e) {
                for (var t = 0, s = [], c = 0; c < e.length; c += 6) s.push(e.slice(c, c + 6));
                n(s[0]), setInterval(function() {
                    t++, t > s.length - 1 && (t = 0), t % 2 == 0 ? (_(!1), _(!0), n(s[t])) : (g(!1), 
                    g(!0), x(s[t]));
                }, 7e3);
            };
            return Object(d["jsxs"])(l["View"], {
                children: [ Object(d["jsx"])(j, {
                    showDoomm: O,
                    doommData: s
                }), Object(d["jsx"])(j, {
                    showDoomm: f,
                    doommData: b
                }) ]
            });
        };
        t["a"] = u;
    },
    62: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(2), i = (s(4), s(1)), a = s(9), l = s(5), r = s(10), o = s(0), d = function(e) {
            var t = e.boxId, s = e.config, d = Object(n["useState"])([]), j = Object(c["a"])(d, 2), u = j[0], b = j[1], x = Object(n["useState"])(0), m = Object(c["a"])(x, 2), h = m[0], O = m[1], _ = Object(n["useState"])(!0), p = Object(c["a"])(_, 2), w = p[0], f = p[1], g = Object(n["useState"])(1), v = Object(c["a"])(g, 2), y = v[0], N = v[1], k = Object(n["useState"])(!1), V = Object(c["a"])(k, 2), S = V[0], C = V[1];
            Object(n["useEffect"])(function() {
                T();
            }, []);
            var T = function() {
                h >= y || (C(!0), Object(l["d"])({
                    url: "entry/wxapp/BoxLogList",
                    data: {
                        bid: t,
                        page: parseInt(h) + 1
                    },
                    success: function(e) {
                        var t = e.list, s = e.current_page, c = e.total_page;
                        b(u.concat(t)), N(c), O(s), setTimeout(function() {
                            f(!1), C(!1);
                        }, 300);
                    }
                }));
            }, I = function(e, t) {
                return Object(o["jsxs"])(i["View"], {
                    className: "b-r",
                    children: [ Object(o["jsxs"])(i["View"], {
                        className: "b-head",
                        children: [ Object(o["jsx"])(i["Image"], {
                            className: "avatar",
                            src: e.user_avatar
                        }), Object(o["jsx"])(i["View"], {
                            className: "nickname",
                            children: e.user_nickname
                        }), Object(o["jsxs"])(i["View"], {
                            className: "time",
                            children: [ e.batch_no ? Object(o["jsxs"])(i["Text"], {
                                className: "batch_no",
                                children: [ "第", e.batch_no, "期" ]
                            }) : null, Object(o["jsx"])(i["Text"], {
                                children: e.time
                            }) ]
                        }) ]
                    }), Object(o["jsxs"])(i["View"], {
                        className: "b-head b-head-no-border",
                        children: [ Object(o["jsx"])(i["Image"], {
                            className: "item-image",
                            src: "".concat(s.attachurl).concat(e.image)
                        }), Object(o["jsx"])(i["View"], {
                            className: "item-name",
                            children: Object(o["jsxs"])(i["View"], {
                                children: [ e.name, e.code ? "+抽奖码:".concat(e.code) : "" ]
                            })
                        }), Object(o["jsxs"])(i["View"], {
                            className: "lk",
                            children: [ e.num, "连开" ]
                        }) ]
                    }) ]
                }, t);
            };
            return Object(o["jsxs"])(i["ScrollView"], {
                className: "box-log-list",
                scrollY: !0,
                onScrollToLower: T,
                children: [ w ? Object(o["jsx"])(a["a"], {
                    style: {
                        height: "200px"
                    },
                    iconStyle: {
                        color: "rgba(0,0,0,0.5)"
                    }
                }) : u.map(I, []), u.length > 0 && !w && h >= y ? Object(o["jsx"])(i["View"], {
                    className: "footer-desc",
                    children: "已经到底拉~"
                }) : null, 0 != u.length || w ? null : Object(o["jsx"])(r["a"], {
                    title: "暂无人开盒"
                }), !w && S ? Object(o["jsx"])(a["a"], {
                    style: {
                        height: "40px"
                    },
                    iconStyle: {
                        color: "rgba(0,0,0,0.5)"
                    }
                }) : null ]
            });
        };
        t["a"] = d;
    },
    63: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(2), i = s.n(n), a = s(4), l = s.n(a), r = s(1), o = s(33), d = s(5), j = (s(101), 
        s(0)), u = function(e) {
            var t = e.items, s = e.config, c = function(e) {
                l.a.navigateTo({
                    url: "/pages/category/details/index?cid=".concat(e.id)
                });
            };
            return Object(j["jsx"])(r["View"], {
                className: "category-com-z",
                children: Object(j["jsx"])(r["View"], {
                    className: "cateicons",
                    children: t.map(function(e, t) {
                        return Object(j["jsxs"])(r["View"], {
                            className: "icon-cate",
                            onClick: function() {
                                return Object(d["a"])(e, c);
                            },
                            children: [ Object(j["jsx"])(r["View"], {
                                className: "image-v",
                                children: Object(j["jsx"])(r["Image"], {
                                    className: "image",
                                    mode: "widthFix",
                                    src: "".concat(s.attachurl).concat(e.image)
                                })
                            }), Object(j["jsx"])(r["View"], {
                                className: "title-v",
                                children: e.name
                            }) ]
                        }, t);
                    })
                })
            });
        }, b = u, x = (s(207), s(60)), m = s.n(x), h = (s(76), s(102), function() {
            return Object(j["jsxs"])("view", {
                class: "sk-container",
                style: {
                    position: "relative"
                },
                children: [ Object(j["jsx"])("view", {
                    class: "swiper-v",
                    id_dd: "_n_79",
                    style: "true",
                    children: Object(j["jsx"])("swiper", {
                        autoplay: "false",
                        circular: "true",
                        class: "swiper",
                        current: "0",
                        "display-multiple-items": "1",
                        duration: "500",
                        "easing-function": "default",
                        id_dd: "_n_78",
                        "indicator-active-color": "#000000",
                        "indicator-color": "rgba(0, 0, 0, .3)",
                        "indicator-dots_dd_dd": "true",
                        interval: "5000",
                        "next-margin": "0px",
                        "previous-margin": "0px",
                        style: "true",
                        children: Object(j["jsx"])("swiper-item", {
                            class: "swiper",
                            id_dd: "_n_71",
                            "item-id_dd": "true",
                            style: "position: absolute; width: 100%; height: 100%; transform: translate(0%, 0px) translateZ(0px);",
                            children: Object(j["jsx"])("image", {
                                class: "swiper-image sk-image",
                                id_dd: "_n_70",
                                mode: "scaleToFill",
                                style: "true"
                            })
                        })
                    })
                }), Object(j["jsx"])("view", {
                    class: "category-com-z",
                    id_dd: "_n_110",
                    style: "true",
                    children: Object(j["jsxs"])("view", {
                        class: "cateicons",
                        id_dd: "_n_109",
                        style: "true",
                        children: [ Object(j["jsxs"])("view", {
                            class: "icon-cate",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            id_dd: "_n_88",
                            style: "true",
                            children: [ Object(j["jsx"])("view", {
                                class: "image-v",
                                id_dd: "_n_85",
                                style: "true",
                                children: Object(j["jsx"])("image", {
                                    class: "image sk-image",
                                    id_dd: "_n_84",
                                    mode: "widthFix",
                                    style: "height: 34.4348px;"
                                })
                            }), Object(j["jsx"])("view", {
                                class: "title-v sk-transparent sk-text-14-2857-50 sk-text",
                                id_dd: "_n_87",
                                style: "true",
                                children: "测试"
                            }) ]
                        }), Object(j["jsxs"])("view", {
                            class: "icon-cate",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            id_dd: "_n_93",
                            style: "true",
                            children: [ Object(j["jsx"])("view", {
                                class: "image-v",
                                id_dd: "_n_90",
                                style: "true",
                                children: Object(j["jsx"])("image", {
                                    class: "image sk-image",
                                    id_dd: "_n_89",
                                    mode: "widthFix",
                                    style: "height: 34.4348px;"
                                })
                            }), Object(j["jsx"])("view", {
                                class: "title-v sk-transparent sk-text-14-2857-498 sk-text",
                                id_dd: "_n_92",
                                style: "true",
                                children: "推荐2号"
                            }) ]
                        }), Object(j["jsxs"])("view", {
                            class: "icon-cate",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            id_dd: "_n_98",
                            style: "true",
                            children: [ Object(j["jsx"])("view", {
                                class: "image-v",
                                id_dd: "_n_95",
                                style: "true",
                                children: Object(j["jsx"])("image", {
                                    class: "image sk-image",
                                    id_dd: "_n_94",
                                    mode: "widthFix",
                                    style: "height: 34.4348px;"
                                })
                            }), Object(j["jsx"])("view", {
                                class: "title-v sk-transparent sk-text-14-2857-606 sk-text",
                                id_dd: "_n_97",
                                style: "true",
                                children: "推荐3号"
                            }) ]
                        }), Object(j["jsxs"])("view", {
                            class: "icon-cate",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            id_dd: "_n_103",
                            style: "true",
                            children: [ Object(j["jsx"])("view", {
                                class: "image-v",
                                id_dd: "_n_100",
                                style: "true",
                                children: Object(j["jsx"])("image", {
                                    class: "image sk-image",
                                    id_dd: "_n_99",
                                    mode: "widthFix",
                                    style: "height: 34.4348px;"
                                })
                            }), Object(j["jsx"])("view", {
                                class: "title-v sk-transparent sk-text-14-2857-26 sk-text",
                                id_dd: "_n_102",
                                style: "true",
                                children: "推荐4号"
                            }) ]
                        }), Object(j["jsxs"])("view", {
                            class: "icon-cate",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            id_dd: "_n_108",
                            style: "true",
                            children: [ Object(j["jsx"])("view", {
                                class: "image-v",
                                id_dd: "_n_105",
                                style: "true",
                                children: Object(j["jsx"])("image", {
                                    class: "image sk-image",
                                    id_dd: "_n_104",
                                    mode: "widthFix",
                                    style: "height: 34.4348px;"
                                })
                            }), Object(j["jsx"])("view", {
                                class: "title-v sk-transparent sk-text-14-2857-883 sk-text",
                                id_dd: "_n_107",
                                style: "true",
                                children: "推荐5号"
                            }) ]
                        }) ]
                    })
                }), Object(j["jsx"])("view", {
                    class: "swiper-v",
                    id_dd: "_n_83",
                    style: "true",
                    children: Object(j["jsx"])("swiper", {
                        autoplay: "false",
                        circular: "true",
                        class: "swiper",
                        current: "0",
                        "display-multiple-items": "1",
                        duration: "500",
                        "easing-function": "default",
                        id_dd: "_n_82",
                        "indicator-active-color": "#000000",
                        "indicator-color": "rgba(0, 0, 0, .3)",
                        "indicator-dots_dd_dd": "true",
                        interval: "5000",
                        "next-margin": "0px",
                        "previous-margin": "0px",
                        style: "true",
                        children: Object(j["jsx"])("swiper-item", {
                            class: "swiper",
                            id_dd: "_n_81",
                            "item-id_dd": "true",
                            style: "position: absolute; width: 100%; height: 100%; transform: translate(0%, 0px) translateZ(0px);",
                            children: Object(j["jsx"])("image", {
                                class: "swiper-image sk-image",
                                id_dd: "_n_80",
                                mode: "scaleToFill",
                                style: "true"
                            })
                        })
                    })
                }), Object(j["jsxs"])("view", {
                    class: "data-list",
                    id_dd: "_n_59",
                    style: "border: none;",
                    children: [ Object(j["jsxs"])("view", {
                        class: "item-com",
                        "hover-class": "none",
                        "hover-start-time": "50",
                        "hover-stay-time": "400",
                        id_dd: "_n_124",
                        style: "border: none;",
                        children: [ Object(j["jsx"])("image", {
                            class: "image sk-image",
                            id_dd: "_n_111",
                            mode: "widthFix",
                            style: "height: 190px;"
                        }), Object(j["jsxs"])("view", {
                            class: "info",
                            id_dd: "_n_123",
                            style: "true",
                            children: [ Object(j["jsx"])("view", {
                                class: "title sk-transparent sk-text-14-2857-58 sk-text",
                                id_dd: "_n_113",
                                style: "true",
                                children: "普通盒子·普通模式"
                            }), Object(j["jsxs"])("view", {
                                class: "price-info",
                                id_dd: "_n_122",
                                style: "true",
                                children: [ Object(j["jsxs"])("view", {
                                    class: "price sk-transparent",
                                    id_dd: "_n_117",
                                    style: "true",
                                    children: [ Object(j["jsx"])("text", {
                                        class: "yuan sk-transparent sk-opacity",
                                        id_dd: "_n_115",
                                        space: "true",
                                        style: "true",
                                        children: "¥"
                                    }), "0.01" ]
                                }), Object(j["jsx"])("view", {
                                    class: "buy_num sk-transparent sk-text-14-2857-650 sk-text",
                                    id_dd: "_n_121",
                                    style: "background-position-x: 100%;",
                                    children: "已售1179盒"
                                }) ]
                            }) ]
                        }) ]
                    }), Object(j["jsxs"])("view", {
                        class: "item-com",
                        "hover-class": "none",
                        "hover-start-time": "50",
                        "hover-stay-time": "400",
                        id_dd: "_n_138",
                        style: "border: none;",
                        children: [ Object(j["jsx"])("image", {
                            class: "image sk-image",
                            id_dd: "_n_125",
                            mode: "widthFix",
                            style: "height: 191px;"
                        }), Object(j["jsxs"])("view", {
                            class: "info",
                            id_dd: "_n_137",
                            style: "true",
                            children: [ Object(j["jsx"])("view", {
                                class: "title sk-transparent sk-text-14-2857-601 sk-text",
                                id_dd: "_n_127",
                                style: "true",
                                children: "这个是幸运盒子"
                            }), Object(j["jsxs"])("view", {
                                class: "price-info",
                                id_dd: "_n_136",
                                style: "true",
                                children: [ Object(j["jsxs"])("view", {
                                    class: "price sk-transparent",
                                    id_dd: "_n_131",
                                    style: "true",
                                    children: [ Object(j["jsx"])("text", {
                                        class: "yuan sk-transparent sk-opacity",
                                        id_dd: "_n_129",
                                        space: "true",
                                        style: "true",
                                        children: "¥"
                                    }), "0.01" ]
                                }), Object(j["jsx"])("view", {
                                    class: "buy_num sk-transparent sk-text-14-2857-249 sk-text",
                                    id_dd: "_n_135",
                                    style: "background-position-x: 100%;",
                                    children: "已售451盒"
                                }) ]
                            }) ]
                        }) ]
                    }), Object(j["jsx"])("view", {
                        class: "item-com",
                        "hover-class": "none",
                        "hover-start-time": "50",
                        "hover-stay-time": "400",
                        id_dd: "_n_152",
                        style: "border: none;"
                    }) ]
                }) ]
            });
        }), O = h, _ = function(e) {
            var t = e.categoryId, s = e.show, i = e.config, u = e.showSort, x = void 0 !== u && u, h = Object(n["useState"])([]), _ = Object(c["a"])(h, 2), p = _[0], w = _[1], f = Object(n["useState"])({
                top: [],
                bottom: []
            }), g = Object(c["a"])(f, 2), v = g[0], y = g[1], N = Object(n["useState"])([]), k = Object(c["a"])(N, 2), V = k[0], S = k[1], C = Object(n["useState"])([]), T = Object(c["a"])(C, 2), I = T[0], B = T[1], F = Object(n["useState"])(1), D = Object(c["a"])(F, 2), L = D[0], M = D[1], E = Object(n["useState"])(0), z = Object(c["a"])(E, 2), H = z[0], P = z[1], q = Object(n["useState"])(!0), R = Object(c["a"])(q, 2), K = R[0], A = R[1];
            Object(n["useEffect"])(function() {
                console.log("RenderPage:", t), U();
            }, []);
            var U = function() {
                Object(d["d"])({
                    url: "entry/wxapp/categoryData",
                    data: {
                        category_id: t
                    },
                    success: function(e) {
                        var s = e.slide, c = e.icons, n = e.title;
                        l.a.setNavigationBarTitle({
                            title: n
                        }), -1 == t ? y(s) : w(s), S(c), Y();
                    }
                });
            };
            Object(a["useReachBottom"])(function() {
                s && (console.log("useReachBottom:", t), Y());
            });
            var Y = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                if (!e && H >= L) return !1;
                Object(d["d"])({
                    url: "entry/wxapp/BoxList",
                    data: {
                        cid: t,
                        page: e || parseInt(H) + 1,
                        sort: G + 1
                    },
                    success: function(e) {
                        var t = e.current_page, s = e.total_page, c = e.list;
                        K && A(!1), B(1 == t ? c : I.concat(c)), M(s), P(t);
                    }
                });
            }, Z = function() {
                return 0 == p.length ? null : Object(j["jsx"])(r["View"], {
                    className: "swiper-v",
                    children: Object(j["jsx"])(r["Swiper"], {
                        className: "swiper",
                        indicatorDots: !0,
                        autoplay: !0,
                        circular: !0,
                        children: p.map(function(e, t) {
                            return Object(j["jsx"])(r["SwiperItem"], {
                                className: "swiper",
                                children: Object(j["jsx"])(r["Image"], {
                                    className: "swiper-image",
                                    onClick: function() {
                                        return Object(d["a"])(e);
                                    },
                                    src: "".concat(i.attachurl).concat(e.image)
                                })
                            }, t);
                        })
                    })
                });
            }, $ = function() {
                return 0 == v.top.length ? null : Object(j["jsx"])(r["View"], {
                    className: "swiper-v",
                    children: Object(j["jsx"])(r["Swiper"], {
                        className: "swiper",
                        indicatorDots: !0,
                        autoplay: !0,
                        circular: !0,
                        children: v.top.map(function(e, t) {
                            return Object(j["jsx"])(r["SwiperItem"], {
                                className: "swiper",
                                children: Object(j["jsx"])(r["Image"], {
                                    className: "swiper-image",
                                    onClick: function() {
                                        return Object(d["a"])(e);
                                    },
                                    src: "".concat(i.attachurl).concat(e.image)
                                })
                            }, t);
                        })
                    })
                });
            }, W = function() {
                return 0 == v.bottom.length ? null : Object(j["jsx"])(r["View"], {
                    className: "swiper-v",
                    children: Object(j["jsx"])(r["Swiper"], {
                        className: "swiper",
                        indicatorDots: !0,
                        autoplay: !0,
                        circular: !0,
                        children: v.bottom.map(function(e, t) {
                            return Object(j["jsx"])(r["SwiperItem"], {
                                className: "swiper",
                                children: Object(j["jsx"])(r["Image"], {
                                    className: "swiper-image",
                                    onClick: function() {
                                        return Object(d["a"])(e);
                                    },
                                    src: "".concat(i.attachurl).concat(e.image)
                                })
                            }, t);
                        })
                    })
                });
            }, X = Object(n["useState"])(0), J = Object(c["a"])(X, 2), G = J[0], Q = J[1], ee = [ "综合", "销量", "价格", "新品" ];
            return Object(n["useEffect"])(function() {
                Y(1);
            }, [ G ]), Object(j["jsx"])(j["Fragment"], {
                children: K ? Object(j["jsx"])(O, {}) : Object(j["jsxs"])(r["View"], {
                    children: [ -1 == t ? $() : Z(), V.length > 0 ? Object(j["jsx"])(b, {
                        items: V,
                        config: i
                    }) : null, -1 == t ? W() : null, x ? Object(j["jsx"])(r["View"], {
                        className: "sort",
                        children: ee.map(function(e, t) {
                            return Object(j["jsxs"])(r["View"], {
                                onClick: function() {
                                    return Q(t);
                                },
                                className: "sort_row ".concat(t == G ? "sort_row_active" : ""),
                                children: [ e, " ", 2 == t ? Object(j["jsx"])(r["Image"], {
                                    src: m.a,
                                    className: "sortpng"
                                }) : null ]
                            }, t);
                        })
                    }) : null, Object(j["jsxs"])(r["View"], {
                        className: "data-list",
                        children: [ I.map(function(e, t) {
                            return Object(j["jsx"])(o["a"], {
                                item: e
                            }, t);
                        }), H >= L ? Object(j["jsx"])(r["View"], {
                            className: "footer-desc",
                            children: "已经到底拉~"
                        }) : null ]
                    }) ]
                })
            });
        };
        t["a"] = i.a.memo(_);
    },
    64: function(e, t, s) {
        "use strict";
        var c = s(3), n = s(2), i = s.n(n), a = (s(4), s(1)), l = s(13), r = s(5), o = s(0), d = function(e) {
            var t = e.boxList, s = e.selectBox, i = e.setSelectBox, d = e.imageConfig, j = Object(n["useState"])({}), u = Object(c["a"])(j, 2), b = u[0], x = u[1];
            return Object(n["useEffect"])(function() {
                Object(r["f"])(x);
            }, []), Object(o["jsxs"])(a["View"], {
                className: "mbox",
                children: [ Object(o["jsx"])(a["Image"], {
                    className: "d",
                    src: "".concat(b.attachurl).concat(d.page_box_base_image)
                }), Object(o["jsx"])(a["Image"], {
                    className: "q",
                    src: "".concat(b.attachurl).concat(d.page_box_panel_image)
                }), t.map(function(e, t) {
                    return e ? Object(o["jsxs"])(a["View"], {
                        children: [ Object(o["jsx"])(a["Image"], {
                            style: e.style,
                            src: "".concat(b.attachurl).concat(d.page_box_image),
                            className: "".concat(e.an && s != t ? "select-box-active-animation" : "", " ").concat(s == t ? "select-box-active" : "")
                        }, t), Object(o["jsx"])("view", {
                            style: Object(l["a"])(Object(l["a"])({}, e.style), {}, {
                                zIndex: e.style.zIndex + 1e3
                            }),
                            className: "".concat(s == t ? "select-box-active" : ""),
                            onClick: function() {
                                return i(t);
                            }
                        }, t) ]
                    }, t) : null;
                }) ]
            });
        }, j = d, u = s(9), b = s(126), x = s.n(b), m = 0, h = function(e) {
            var t = e.boxId, s = void 0 === t ? 0 : t, i = e.show, l = e.list, d = void 0 === l ? [] : l, b = e.imageConfig, h = void 0 === b ? {} : b, O = e.onOneClick, _ = Object(n["useState"])(-1), p = Object(c["a"])(_, 2), w = p[0], f = p[1], g = Object(n["useState"])(0), v = Object(c["a"])(g, 2), y = v[0], N = v[1];
            Object(n["useEffect"])(function() {
                f(-1);
            }, [ y ]);
            var k = function(e) {
                N(e ? 0 == y ? 4 : y - 1 : 4 == y ? 0 : y + 1);
            }, V = function(e) {
                var t = new Date().valueOf();
                e == w && t - m < 1e3 ? O ? O(s) : Object(r["c"])(s) : f(e == w ? -1 : e), m = t;
            };
            return Object(o["jsxs"])(a["View"], {
                className: "mbox-swiper-v",
                children: [ Object(o["jsx"])(a["Image"], {
                    src: x.a,
                    className: "open-tip",
                    mode: "heightFix"
                }), Object(o["jsx"])(a["Text"], {
                    className: "iconfont icon-jiantou left-a",
                    onClick: function() {
                        return k(0);
                    }
                }), Object(o["jsx"])(a["Text"], {
                    className: "iconfont icon-jiantou left-r",
                    onClick: function() {
                        return k(1);
                    }
                }), i ? Object(o["jsx"])(a["Swiper"], {
                    className: "mbox-swiper",
                    current: y,
                    circular: !0,
                    onChange: function(e) {
                        return N(e.detail.current);
                    },
                    children: d && d.map(function(e, t) {
                        return Object(o["jsx"])(a["SwiperItem"], {
                            className: "mbox-swiper",
                            children: Object(o["jsx"])(j, {
                                boxId: s,
                                imageConfig: h,
                                boxList: e,
                                selectBox: w,
                                setSelectBox: V
                            })
                        }, t);
                    })
                }) : Object(o["jsx"])(a["View"], {
                    className: "mbox-swiper",
                    children: Object(o["jsx"])(u["a"], {})
                }), Object(o["jsxs"])(a["View"], {
                    className: "text-c",
                    children: [ Object(o["jsx"])(a["Text"], {
                        className: "iconfont icon-biaoqing gray"
                    }), Object(o["jsx"])(a["Text"], {
                        className: "iconfont icon-biaoqing"
                    }), Object(o["jsx"])(a["Text"], {
                        children: "左右滑动可换盒"
                    }), Object(o["jsx"])(a["Text"], {
                        className: "iconfont icon-weimingmingwenjianjia_jiantou "
                    }), Object(o["jsx"])(a["Text"], {
                        className: "iconfont icon-weimingmingwenjianjia_jiantou gray"
                    }) ]
                }) ]
            });
        };
        t["a"] = i.a.memo(h);
    },
    76: function(e, t, s) {
        "use strict";
        var c = s(12), n = (s(2), s(102), s(0)), i = function() {
            var e, t;
            return Object(n["jsx"])("view", {
                class: "sk-container",
                children: Object(n["jsxs"])("view", {
                    class: "index-page",
                    id_dd: "_n_31",
                    style: "true",
                    children: [ Object(n["jsxs"])("view", {
                        id_dd: "_n_20",
                        style: "true",
                        children: [ Object(n["jsx"])("view", {
                            class: "header-white header",
                            id_dd: "_n_18",
                            style: "height: 40px;line-height: 40px;padding-top: 44px;",
                            children: Object(n["jsx"])("image", {
                                class: "mini-logo sk-image",
                                id_dd: "_n_17",
                                mode: "heightFix",
                                style: "width: 153.5px;"
                            })
                        }), Object(n["jsx"])("view", {
                            id_dd: "_n_19",
                            style: "height: 40px;line-height: 40px;padding-top: 44px;"
                        }) ]
                    }), Object(n["jsxs"])("view", {
                        class: "nav_search",
                        id_dd: "_n_26",
                        style: "true",
                        children: [ Object(n["jsxs"])("view", {
                            class: "input",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            id_dd: "_n_24",
                            style: "true",
                            children: [ Object(n["jsx"])("text", {
                                class: "iconfont icon-sousuo sk-pseudo sk-pseudo-circle",
                                id_dd: "_n_21",
                                space: "true",
                                style: "true"
                            }), Object(n["jsx"])("view", {
                                class: "input_value sk-transparent sk-text-14-2857-119 sk-text",
                                id_dd: "_n_23",
                                style: "true",
                                children: "搜索一下您想要的"
                            }) ]
                        }), Object(n["jsx"])("text", {
                            class: "notice iconfont icon-renwuzhongxin-kaiqixiaoxitongzhi sk-pseudo sk-pseudo-circle",
                            id_dd: "_n_25",
                            space: "true",
                            style: "true"
                        }) ]
                    }), Object(n["jsxs"])("view", {
                        class: "at-tabs at-tabs--scroll at-tabs--horizontal at-tabs--WEAPP",
                        id_dd: "_n_30",
                        style: "true",
                        children: [ Object(n["jsxs"])("scroll-view", {
                            binddragend: "eh",
                            binddragging: "eh",
                            binddragstart: "eh",
                            bounces: "true",
                            class: "at-tabs__header",
                            id_dd: "BNHKBDFL",
                            "lower-threshold": "50",
                            "refresher-background": "#FFF",
                            "refresher-default-style": "black",
                            "refresher-threshold": "45",
                            "scroll-into-view": "tabBNHKBDFL0",
                            "scroll-left": "0",
                            "scroll-top": "0",
                            "scroll-with-animation": "true",
                            "scroll-x": "true",
                            "show-scrollbar": "true",
                            style: "true",
                            "upper-threshold": "50",
                            children: [ Object(n["jsxs"])("view", {
                                class: "at-tabs__item  sk-transparent sk-text-14-2857-119 sk-text",
                                "hover-class": "none",
                                "hover-start-time": "50",
                                "hover-stay-time": "400",
                                id_dd: "tabBNHKBDFL0",
                                style: "true",
                                children: [ "推荐", Object(n["jsx"])("view", {
                                    class: "at-tabs__item-underline",
                                    id_dd: "_n_33",
                                    style: "true"
                                }) ]
                            }), Object(n["jsxs"])("view", {
                                class: "at-tabs__item sk-transparent sk-text sk-text-14-2857-119 sk-text",
                                "hover-class": "none",
                                "hover-start-time": "50",
                                "hover-stay-time": "400",
                                id_dd: "tabBNHKBDFL1",
                                style: "true",
                                children: [ "新品", Object(n["jsx"])("view", {
                                    class: "at-tabs__item-underline",
                                    id_dd: "_n_36",
                                    style: "true"
                                }) ]
                            }), Object(n["jsxs"])("view", {
                                class: "at-tabs__item sk-transparent sk-text sk-text-14-2857-119 sk-text",
                                "hover-class": "none",
                                "hover-start-time": "50",
                                "hover-stay-time": "400",
                                id_dd: "tabBNHKBDFL2",
                                style: "true",
                                children: [ "新品", Object(n["jsx"])("view", {
                                    class: "at-tabs__item-underline",
                                    id_dd: "_n_39",
                                    style: "true"
                                }) ]
                            }), Object(n["jsxs"])("view", {
                                class: "at-tabs__item sk-transparent sk-text sk-text-14-2857-119 sk-text",
                                "hover-class": "none",
                                "hover-start-time": "50",
                                "hover-stay-time": "400",
                                id_dd: "tabBNHKBDFL3",
                                style: "true",
                                children: [ "新品", Object(n["jsx"])("view", {
                                    class: "at-tabs__item-underline",
                                    id_dd: "_n_42",
                                    style: "true"
                                }) ]
                            }), Object(n["jsxs"])("view", {
                                class: "at-tabs__item sk-transparent sk-text sk-text-14-2857-119 sk-text",
                                "hover-class": "none",
                                "hover-start-time": "50",
                                "hover-stay-time": "400",
                                id_dd: "tabBNHKBDFL4",
                                style: "true",
                                children: [ "抢购", Object(n["jsx"])("view", {
                                    class: "at-tabs__item-underline",
                                    id_dd: "_n_45",
                                    style: "true"
                                }) ]
                            }), Object(n["jsxs"])("view", {
                                class: "at-tabs__item sk-transparent sk-text sk-text-14-2857-119 sk-text",
                                "hover-class": "none",
                                "hover-start-time": "50",
                                "hover-stay-time": "400",
                                id_dd: "tabBNHKBDFL5",
                                style: "true",
                                children: [ "促销", Object(n["jsx"])("view", {
                                    class: "at-tabs__item-underline",
                                    id_dd: "_n_48",
                                    style: "true"
                                }) ]
                            }) ]
                        }), Object(n["jsxs"])("view", {
                            class: "at-tabs__body",
                            "hover-class": "none",
                            "hover-start-time": "50",
                            "hover-stay-time": "400",
                            id_dd: "_n_29",
                            style: "transform: translate3d(-0%, 0px, 0px);-webkit-transform: translate3d(-0%, 0px, 0px);",
                            children: [ Object(n["jsx"])("view", {
                                class: "at-tabs__underline",
                                id_dd: "_n_28",
                                style: "height: 1PX;width: 900%;"
                            }), Object(n["jsxs"])("view", {
                                class: "at-tabs-pane at-tabs-pane--active",
                                id_dd: "_n_61",
                                style: "true",
                                children: [ Object(n["jsx"])("view", {
                                    class: "swiper-v",
                                    id_dd: "_n_79",
                                    style: "true",
                                    children: Object(n["jsx"])("swiper", (e = {
                                        autoplay: "false",
                                        circular: "true",
                                        class: "swiper",
                                        "indicator-dots_dd": "false",
                                        current: "0",
                                        "display-multiple-items": "1",
                                        duration: "500",
                                        "easing-function": "default",
                                        id_dd: "_n_78",
                                        "indicator-active-color": "#000000",
                                        "indicator-color": "rgba(0, 0, 0, .3)"
                                    }, Object(c["a"])(e, "indicator-dots_dd", "false"), Object(c["a"])(e, "interval", "5000"), 
                                    Object(c["a"])(e, "next-margin", "0px"), Object(c["a"])(e, "previous-margin", "0px"), 
                                    Object(c["a"])(e, "style", "true"), Object(c["a"])(e, "children", Object(n["jsx"])("swiper-item", {
                                        class: "swiper",
                                        id_dd: "_n_71",
                                        "item-id_dd": "true",
                                        style: "position: absolute; width: 100%; height: 100%; transform: translate(0%, 0px) translateZ(0px);",
                                        children: Object(n["jsx"])("image", {
                                            class: "swiper-image sk-image",
                                            id_dd: "_n_70",
                                            mode: "scaleToFill",
                                            style: "true"
                                        })
                                    })), e))
                                }), Object(n["jsx"])("view", {
                                    class: "category-com-z",
                                    id_dd: "_n_110",
                                    style: "true",
                                    children: Object(n["jsxs"])("view", {
                                        class: "cateicons",
                                        id_dd: "_n_109",
                                        style: "true",
                                        children: [ Object(n["jsxs"])("view", {
                                            class: "icon-cate",
                                            "hover-class": "none",
                                            "hover-start-time": "50",
                                            "hover-stay-time": "400",
                                            id_dd: "_n_88",
                                            style: "true",
                                            children: [ Object(n["jsx"])("view", {
                                                class: "image-v",
                                                id_dd: "_n_85",
                                                style: "true",
                                                children: Object(n["jsx"])("image", {
                                                    class: "image sk-image",
                                                    id_dd: "_n_84",
                                                    mode: "widthFix",
                                                    style: "height: 34.4348px;"
                                                })
                                            }), Object(n["jsx"])("view", {
                                                class: "title-v sk-transparent sk-text-14-2857-50 sk-text",
                                                id_dd: "_n_87",
                                                style: "true",
                                                children: "测试"
                                            }) ]
                                        }), Object(n["jsxs"])("view", {
                                            class: "icon-cate",
                                            "hover-class": "none",
                                            "hover-start-time": "50",
                                            "hover-stay-time": "400",
                                            id_dd: "_n_93",
                                            style: "true",
                                            children: [ Object(n["jsx"])("view", {
                                                class: "image-v",
                                                id_dd: "_n_90",
                                                style: "true",
                                                children: Object(n["jsx"])("image", {
                                                    class: "image sk-image",
                                                    id_dd: "_n_89",
                                                    mode: "widthFix",
                                                    style: "height: 34.4348px;"
                                                })
                                            }), Object(n["jsx"])("view", {
                                                class: "title-v sk-transparent sk-text-14-2857-498 sk-text",
                                                id_dd: "_n_92",
                                                style: "true",
                                                children: "推荐2号"
                                            }) ]
                                        }), Object(n["jsxs"])("view", {
                                            class: "icon-cate",
                                            "hover-class": "none",
                                            "hover-start-time": "50",
                                            "hover-stay-time": "400",
                                            id_dd: "_n_98",
                                            style: "true",
                                            children: [ Object(n["jsx"])("view", {
                                                class: "image-v",
                                                id_dd: "_n_95",
                                                style: "true",
                                                children: Object(n["jsx"])("image", {
                                                    class: "image sk-image",
                                                    id_dd: "_n_94",
                                                    mode: "widthFix",
                                                    style: "height: 34.4348px;"
                                                })
                                            }), Object(n["jsx"])("view", {
                                                class: "title-v sk-transparent sk-text-14-2857-606 sk-text",
                                                id_dd: "_n_97",
                                                style: "true",
                                                children: "推荐3号"
                                            }) ]
                                        }), Object(n["jsxs"])("view", {
                                            class: "icon-cate",
                                            "hover-class": "none",
                                            "hover-start-time": "50",
                                            "hover-stay-time": "400",
                                            id_dd: "_n_103",
                                            style: "true",
                                            children: [ Object(n["jsx"])("view", {
                                                class: "image-v",
                                                id_dd: "_n_100",
                                                style: "true",
                                                children: Object(n["jsx"])("image", {
                                                    class: "image sk-image",
                                                    id_dd: "_n_99",
                                                    mode: "widthFix",
                                                    style: "height: 34.4348px;"
                                                })
                                            }), Object(n["jsx"])("view", {
                                                class: "title-v sk-transparent sk-text-14-2857-26 sk-text",
                                                id_dd: "_n_102",
                                                style: "true",
                                                children: "推荐4号"
                                            }) ]
                                        }), Object(n["jsxs"])("view", {
                                            class: "icon-cate",
                                            "hover-class": "none",
                                            "hover-start-time": "50",
                                            "hover-stay-time": "400",
                                            id_dd: "_n_108",
                                            style: "true",
                                            children: [ Object(n["jsx"])("view", {
                                                class: "image-v",
                                                id_dd: "_n_105",
                                                style: "true",
                                                children: Object(n["jsx"])("image", {
                                                    class: "image sk-image",
                                                    id_dd: "_n_104",
                                                    mode: "widthFix",
                                                    style: "height: 34.4348px;"
                                                })
                                            }), Object(n["jsx"])("view", {
                                                class: "title-v sk-transparent sk-text-14-2857-883 sk-text",
                                                id_dd: "_n_107",
                                                style: "true",
                                                children: "推荐5号"
                                            }) ]
                                        }) ]
                                    })
                                }), Object(n["jsx"])("view", {
                                    class: "swiper-v",
                                    id_dd: "_n_83",
                                    style: "true",
                                    children: Object(n["jsx"])("swiper", (t = {
                                        autoplay: "false",
                                        circular: "true",
                                        class: "swiper",
                                        current: "0",
                                        "indicator-dots_dd": "false",
                                        "display-multiple-items": "1",
                                        duration: "500",
                                        "easing-function": "default",
                                        id_dd: "_n_82",
                                        "indicator-active-color": "#000000",
                                        "indicator-color": "rgba(0, 0, 0, .3)"
                                    }, Object(c["a"])(t, "indicator-dots_dd", "false"), Object(c["a"])(t, "interval", "5000"), 
                                    Object(c["a"])(t, "next-margin", "0px"), Object(c["a"])(t, "previous-margin", "0px"), 
                                    Object(c["a"])(t, "style", "true"), Object(c["a"])(t, "children", Object(n["jsx"])("swiper-item", {
                                        class: "swiper",
                                        id_dd: "_n_81",
                                        "item-id_dd": "true",
                                        style: "position: absolute; width: 100%; height: 100%; transform: translate(0%, 0px) translateZ(0px);",
                                        children: Object(n["jsx"])("image", {
                                            class: "swiper-image sk-image",
                                            id_dd: "_n_80",
                                            mode: "scaleToFill",
                                            style: "true"
                                        })
                                    })), t))
                                }), Object(n["jsxs"])("view", {
                                    class: "data-list",
                                    id_dd: "_n_59",
                                    style: "border: none;",
                                    children: [ Object(n["jsxs"])("view", {
                                        class: "item-com",
                                        "hover-class": "none",
                                        "hover-start-time": "50",
                                        "hover-stay-time": "400",
                                        id_dd: "_n_124",
                                        style: "border: none;",
                                        children: [ Object(n["jsx"])("image", {
                                            class: "image sk-image",
                                            id_dd: "_n_111",
                                            mode: "widthFix",
                                            style: "height: 190px;"
                                        }), Object(n["jsxs"])("view", {
                                            class: "info",
                                            id_dd: "_n_123",
                                            style: "true",
                                            children: [ Object(n["jsx"])("view", {
                                                class: "title sk-transparent sk-text-14-2857-58 sk-text",
                                                id_dd: "_n_113",
                                                style: "true",
                                                children: "普通·普通模式"
                                            }), Object(n["jsxs"])("view", {
                                                class: "price-info",
                                                id_dd: "_n_122",
                                                style: "true",
                                                children: [ Object(n["jsxs"])("view", {
                                                    class: "price sk-transparent",
                                                    id_dd: "_n_117",
                                                    style: "true",
                                                    children: [ Object(n["jsx"])("text", {
                                                        class: "yuan sk-transparent sk-opacity",
                                                        id_dd: "_n_115",
                                                        space: "true",
                                                        style: "true",
                                                        children: "¥"
                                                    }), "0.01" ]
                                                }), Object(n["jsx"])("view", {
                                                    class: "buy_num sk-transparent sk-text-14-2857-650 sk-text",
                                                    id_dd: "_n_121",
                                                    style: "background-position-x: 100%;",
                                                    children: "已售1179盒"
                                                }) ]
                                            }) ]
                                        }) ]
                                    }), Object(n["jsxs"])("view", {
                                        class: "item-com",
                                        "hover-class": "none",
                                        "hover-start-time": "50",
                                        "hover-stay-time": "400",
                                        id_dd: "_n_138",
                                        style: "border: none;",
                                        children: [ Object(n["jsx"])("image", {
                                            class: "image sk-image",
                                            id_dd: "_n_125",
                                            mode: "widthFix",
                                            style: "height: 191px;"
                                        }), Object(n["jsxs"])("view", {
                                            class: "info",
                                            id_dd: "_n_137",
                                            style: "true",
                                            children: [ Object(n["jsx"])("view", {
                                                class: "title sk-transparent sk-text-14-2857-601 sk-text",
                                                id_dd: "_n_127",
                                                style: "true",
                                                children: "这个是幸运"
                                            }), Object(n["jsxs"])("view", {
                                                class: "price-info",
                                                id_dd: "_n_136",
                                                style: "true",
                                                children: [ Object(n["jsxs"])("view", {
                                                    class: "price sk-transparent",
                                                    id_dd: "_n_131",
                                                    style: "true",
                                                    children: [ Object(n["jsx"])("text", {
                                                        class: "yuan sk-transparent sk-opacity",
                                                        id_dd: "_n_129",
                                                        space: "true",
                                                        style: "true",
                                                        children: "¥"
                                                    }), "0.01" ]
                                                }), Object(n["jsx"])("view", {
                                                    class: "buy_num sk-transparent sk-text-14-2857-249 sk-text",
                                                    id_dd: "_n_135",
                                                    style: "background-position-x: 100%;",
                                                    children: "已售451盒"
                                                }) ]
                                            }) ]
                                        }) ]
                                    }), Object(n["jsx"])("view", {
                                        class: "item-com",
                                        "hover-class": "none",
                                        "hover-start-time": "50",
                                        "hover-stay-time": "400",
                                        id_dd: "_n_152",
                                        style: "border: none;"
                                    }) ]
                                }) ]
                            }) ]
                        }) ]
                    }) ]
                })
            });
        };
        t["a"] = i;
    },
    78: function(e, t, s) {
        e.exports = s.p + "assets/hx.png";
    },
    79: function(e, t, s) {
        e.exports = s.p + "assets/images/dizuo.png";
    },
    9: function(e, t, s) {
        "use strict";
        s(2);
        var c = s(1), n = s(0), i = function(e) {
            var t = e.fixed, s = e.style, i = e.iconStyle, a = e.title;
            return Object(n["jsxs"])(c["View"], {
                className: "data-loading ".concat(t ? "data-fixed" : ""),
                style: s,
                onClick: function(e) {
                    e.stopPropagation();
                },
                children: [ Object(n["jsx"])(c["Text"], {
                    className: "iconfont icon-jiazaizhong2",
                    style: i
                }), a ? Object(n["jsx"])(c["Text"], {
                    className: "loading-title",
                    children: a
                }) : null ]
            });
        };
        t["a"] = i;
    }
} ]);