(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 68 ], {
    236: function(e, t, c) {},
    269: function(e, t, c) {
        "use strict";
        c.r(t);
        var a = c(7), i = c(3), s = c(2), n = c(4), l = c.n(n), o = c(1), r = (c(236), c(5)), j = c(33), b = c(10), u = c(0), m = function(e) {
            var t = e.item, c = e.size, a = Object(s["useState"])({}), n = Object(i["a"])(a, 2), j = n[0], b = n[1];
            Object(s["useEffect"])(function() {
                Object(r["f"])(b);
            }, []);
            var m = function() {
                return parseInt(t.batch.sold_num / t.batch.stock * 100);
            };
            return Object(u["jsxs"])(o["View"], {
                className: "box-com ".concat("big" == c ? "box-big" : ""),
                onClick: function() {
                    l.a.navigateTo({
                        url: "/pages/detail/index?id=".concat(t.id)
                    });
                },
                children: [ Object(u["jsxs"])(o["View"], {
                    className: "box-image",
                    children: [ "big" == c ? Object(u["jsx"])(o["Image"], {
                        className: "image",
                        mode: "widthFix",
                        src: "".concat(j.attachurl).concat(t.cabinet_image ? t.cabinet_image : t.item_image)
                    }) : Object(u["jsx"])(o["Image"], {
                        className: "image",
                        mode: "widthFix",
                        src: "".concat(j.attachurl).concat(t.recommend_image ? t.recommend_image : t.item_image)
                    }), Object(u["jsx"])(o["View"], {
                        className: "title",
                        children: Object(u["jsx"])(o["View"], {
                            className: "text",
                            children: t.title
                        })
                    }) ]
                }), Object(u["jsxs"])(o["View"], {
                    className: "pross",
                    children: [ Object(u["jsxs"])(o["View"], {
                        className: "text",
                        children: [ "开奖进度", m(), "%" ]
                    }), Object(u["jsx"])(o["View"], {
                        className: "bg",
                        style: {
                            width: "".concat(m(), "%")
                        }
                    }) ]
                }), Object(u["jsxs"])(o["View"], {
                    className: "bitch",
                    children: [ Object(u["jsxs"])(o["View"], {
                        className: "a",
                        children: [ "第", t.batch.batch_no, "期" ]
                    }), Object(u["jsxs"])(o["View"], {
                        className: "b",
                        children: [ "价值:￥", Object(r["i"])(t.price) ]
                    }) ]
                }) ]
            });
        }, O = m, d = (c(101), c(15)), x = function(e) {
            var t = e.onChange, c = e.categoryData, a = e.current, r = e.fiexdChange, j = Object(s["useState"])(0), b = Object(i["a"])(j, 2), m = b[0], O = b[1], x = Object(s["useState"])(0), g = Object(i["a"])(x, 2), f = g[0], h = g[1], p = Object(s["useState"])(0), w = Object(i["a"])(p, 2), N = w[0], V = w[1], v = Object(s["useState"])(0), y = Object(i["a"])(v, 2), S = y[0], T = y[1], _ = Object(s["useState"])(!1), C = Object(i["a"])(_, 2), k = C[0], B = C[1], I = Object(s["useState"])({}), R = Object(i["a"])(I, 2), E = R[0], z = R[1];
            Object(s["useEffect"])(function() {
                z(Object(d["a"])()), L();
            }, []), Object(s["useEffect"])(function() {
                O(a);
            }, [ a ]);
            var L = function() {
                setTimeout(function() {
                    var e = wx.createSelectorQuery();
                    e.select("#categroy").boundingClientRect(function(e) {
                        h(e.top);
                    }).exec();
                    var t = l.a.getMenuButtonBoundingClientRect(), c = t.top - E.top, a = t.height + 2 * c + E.paddingTop;
                    !isNaN(a) && V(a);
                }, 400);
            };
            Object(n["useReady"])(function() {
                L();
            }), Object(n["usePageScroll"])(function(e) {
                f && (B(f - E.paddingTop - 46 < e.scrollTop), r && r(f - E.paddingTop - 46 < e.scrollTop));
            });
            var P = function(e, c) {
                O(e);
                var a = c.currentTarget.offsetLeft, i = l.a.getSystemInfoSync().windowWidth, s = wx.createSelectorQuery();
                s.select(".tab-item").boundingClientRect(function(e) {
                    T(a - i / 2 + e.width);
                }).exec(), t && t(e);
            };
            return Object(u["jsxs"])(o["View"], {
                className: "category-com-z",
                children: [ k ? Object(u["jsx"])(o["View"], {
                    className: "c-fiexd category-com",
                    id: "categroy",
                    style: k ? {
                        top: N
                    } : {},
                    children: Object(u["jsx"])(o["View"], {
                        className: "texts-v",
                        children: Object(u["jsx"])(o["ScrollView"], {
                            className: "texts",
                            scrollX: !0,
                            scrollLeft: S,
                            scrollWithAnimation: !0,
                            children: c && c.map(function(e, t) {
                                return Object(u["jsx"])(o["View"], {
                                    onClick: function(e) {
                                        return P(t, e);
                                    },
                                    className: "tab-item text ".concat(m == t ? "text-active" : ""),
                                    children: e.name
                                }, t);
                            })
                        })
                    })
                }) : null, Object(u["jsx"])(o["View"], {
                    className: "category-com",
                    id: "categroy",
                    children: Object(u["jsx"])(o["View"], {
                        className: "texts-v",
                        children: Object(u["jsx"])(o["ScrollView"], {
                            className: "texts",
                            scrollX: !0,
                            scrollLeft: S,
                            scrollWithAnimation: !0,
                            children: c && c.map(function(e, t) {
                                return Object(u["jsx"])(o["View"], {
                                    onClick: function(e) {
                                        return P(t, e);
                                    },
                                    className: "tab-item text ".concat(m == t ? "text-active" : ""),
                                    children: e.name
                                }, t);
                            })
                        })
                    })
                }) ]
            });
        }, g = x, f = function() {
            var e = Object(n["useRouter"])(), t = Object(s["useState"])([]), c = Object(i["a"])(t, 2), a = c[0], m = c[1], d = Object(s["useState"])(!1), x = Object(i["a"])(d, 2), f = (x[0], 
            x[1]), h = Object(s["useState"])(1), p = Object(i["a"])(h, 2), w = p[0], N = p[1], V = Object(s["useState"])(0), v = Object(i["a"])(V, 2), y = v[0], S = v[1];
            Object(s["useEffect"])(function() {
                var t = e.params.type;
                "luck" == t ? l.a.setNavigationBarTitle({
                    title: "全部幸运盒子"
                }) : (l.a.setNavigationBarTitle({
                    title: "加载中..."
                }), Object(r["f"])(function(e) {
                    l.a.setNavigationBarTitle({
                        title: e.index_one_title
                    });
                })), T();
            }, []);
            var T = function() {
                Object(r["d"])({
                    url: "entry/wxapp/Special",
                    data: {
                        page: parseInt(y) + 1,
                        type: e.params.type
                    },
                    success: function(e) {
                        var t = e.current_page, c = e.total_page, i = e.list;
                        m(a.concat(i)), N(c), S(t), f(!0);
                    }
                });
            };
            return Object(u["jsxs"])(o["View"], {
                className: "special-page",
                children: [ Object(u["jsx"])(o["View"], {
                    style: {
                        height: "1px"
                    }
                }), Object(u["jsx"])(g, {}), Object(u["jsxs"])(o["View"], {
                    className: "data-list",
                    children: [ a.map(function(t, c) {
                        return "luck" == e.params.type ? Object(u["jsx"])(O, {
                            size: "big",
                            item: t
                        }, t.id) : Object(u["jsx"])(j["a"], {
                            item: t
                        }, t.id);
                    }), y >= w && a.length > 0 ? Object(u["jsx"])(o["View"], {
                        className: "footer-desc",
                        children: "已经到底拉~"
                    }) : null, y >= w && 0 == a.length ? Object(u["jsx"])(b["a"], {
                        title: "暂无活动"
                    }) : null ]
                }) ]
            });
        }, h = f, p = {
            navigationBarTitleText: "专题"
        };
        Page(Object(a["createPageConfig"])(h, "pages/special/index", {
            root: {
                cn: []
            }
        }, p || {}));
    }
}, [ [ 269, 0, 2, 1, 3 ] ] ]);