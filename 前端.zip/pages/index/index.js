(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 34 ], {
    112: function(e, t, c) {
        e.exports = c.p + "assets/images/my/orderedlist.png";
    },
    113: function(e, t, c) {
        e.exports = c.p + "assets/images/my/layout1.png";
    },
    114: function(e, t, c) {
        e.exports = c.p + "assets/ok.jpg";
    },
    204: function(e, t, c) {},
    208: function(e, t, c) {},
    210: function(e, t, c) {},
    267: function(e, t, c) {
        "use strict";
        c.r(t);
        var a = c(7), n = c(3), s = c(2), i = c.n(s), o = c(4), l = c.n(o), j = (c(204), 
        c(5)), r = c(13), u = c(1), b = c(20), O = c(15), x = c(63), h = c(76), d = c(0), m = function(e) {
            var t = e.config, c = Object(s["useState"])({}), a = Object(n["a"])(c, 2), i = a[0], o = a[1], m = Object(s["useState"])([]), p = Object(n["a"])(m, 2), g = p[0], f = p[1], w = Object(s["useState"])(!0), N = Object(n["a"])(w, 2), V = N[0], y = N[1];
            Object(s["useEffect"])(function() {
                o(Object(O["a"])()), Object(j["e"])(function(e) {
                    y(!1), f(e);
                });
            }, []);
            var v = function() {
                l.a.navigateTo({
                    url: "/pages/search/index"
                });
            }, S = function() {
                var e = l.a.getMenuButtonBoundingClientRect(), c = e.top - i.top, a = e.height + 2 * c, n = {
                    height: "".concat(a, "px"),
                    lineHeight: "".concat(a, "px"),
                    paddingTop: "".concat(i.paddingTop, "px")
                };
                return Object(d["jsxs"])(u["View"], {
                    children: [ Object(d["jsx"])(u["View"], {
                        className: "header-white header",
                        style: n,
                        children: Object(d["jsx"])(u["Image"], {
                            className: "mini-logo",
                            mode: "heightFix",
                            src: "".concat(t.attachurl).concat(t.app_logo_a)
                        })
                    }), Object(d["jsx"])(u["View"], {
                        style: n
                    }) ]
                });
            }, _ = function(e) {
                return Object(d["jsxs"])(u["View"], {
                    className: "nav_search",
                    children: [ Object(d["jsxs"])(u["View"], {
                        className: "input",
                        onClick: v,
                        children: [ Object(d["jsx"])(u["Text"], {
                            className: "iconfont icon-sousuo"
                        }), Object(d["jsx"])(u["View"], {
                            className: "input_value",
                            children: "搜索一下您想要的物品"
                        }) ]
                    }), Object(d["jsx"])(u["Text"], {
                        className: "notice iconfont icon-renwuzhongxin-kaiqixiaoxitongzhi",
                        onClick: function() {
                            l.a.navigateTo({
                                url: "/pages/my/notice/index"
                            });
                        }
                    }) ]
                });
            }, k = Object(s["useState"])(0), C = Object(n["a"])(k, 2), T = C[0], I = C[1], F = Object(s["useState"])({
                0: !0
            }), B = Object(n["a"])(F, 2), z = B[0], E = B[1], M = function(e) {
                I(e);
                var t = Object(r["a"])({}, z);
                t[e] = !0, E(t);
            };
            return Object(d["jsx"])(d["Fragment"], {
                children: V ? Object(d["jsx"])(h["a"], {}) : Object(d["jsxs"])(u["View"], {
                    className: "index-page",
                    children: [ S(), _(), Object(d["jsx"])(b["e"], {
                        current: T,
                        scroll: !0,
                        tabList: g,
                        onClick: M,
                        children: g.map(function(e, c) {
                            return Object(d["jsx"])(b["f"], {
                                current: T,
                                index: c,
                                children: z[c] ? Object(d["jsx"])(x["a"], {
                                    categoryId: e.id,
                                    show: c == T,
                                    config: t
                                }) : null
                            }, e.id);
                        })
                    }) ]
                })
            });
        }, p = m, g = (c(208), function(e) {
            var t = e.item, c = (e.size, Object(s["useState"])({})), a = Object(n["a"])(c, 2), i = a[0], o = a[1];
            return Object(s["useEffect"])(function() {
                Object(j["f"])(o);
            }, []), Object(d["jsxs"])(u["View"], {
                className: "com-simplicity",
                onClick: function() {
                    l.a.navigateTo({
                        url: "/pages/detail/index?id=".concat(t.id)
                    });
                },
                children: [ Object(d["jsx"])(u["Image"], {
                    className: "image",
                    mode: "aspectFill",
                    src: "".concat(i.attachurl).concat(t.item_image)
                }), Object(d["jsx"])(u["View"], {
                    className: "title",
                    children: t.title
                }), Object(d["jsx"])(u["View"], {
                    className: "right-top",
                    children: "进行中"
                }), 2 == t.type && t.batch ? Object(d["jsxs"])(u["View"], {
                    className: "left-top",
                    children: [ "第", t.batch.batch_no, "期" ]
                }) : null ]
            });
        }), f = g, w = (c(103), c(112)), N = c.n(w), V = c(113), y = c.n(V), v = function(e) {
            var t = e.config, c = Object(s["useState"])({}), a = Object(n["a"])(c, 2), i = a[0], r = a[1], b = Object(s["useState"])([]), x = Object(n["a"])(b, 2), h = x[0], m = x[1], p = Object(s["useState"])(0), g = Object(n["a"])(p, 2), w = g[0], V = g[1], v = Object(s["useState"])([]), S = Object(n["a"])(v, 2), _ = S[0], k = S[1], C = Object(s["useState"])(1), T = Object(n["a"])(C, 2), I = T[0], F = T[1], B = Object(s["useState"])(0), z = Object(n["a"])(B, 2), E = z[0], M = z[1], A = function() {
                Object(j["d"])({
                    url: "entry/wxapp/index",
                    success: function(e) {
                        var t = e.slide;
                        m(t), R();
                    }
                });
            }, R = function() {
                if (E >= I) return !1;
                Object(j["d"])({
                    url: "entry/wxapp/BoxList",
                    data: {
                        page: parseInt(E) + 1
                    },
                    success: function(e) {
                        var t = e.current_page, c = e.total_page, a = e.list;
                        k(_.concat(a)), F(c), M(t);
                    }
                });
            };
            Object(o["useReachBottom"])(function() {
                A();
            }), Object(s["useEffect"])(function() {
                r(Object(O["a"])()), A();
            }, []);
            var U = function() {
                l.a.navigateTo({
                    url: "/pages/search/index"
                });
            }, q = function() {
                var e = l.a.getMenuButtonBoundingClientRect(), c = e.top - i.top, a = e.height + 2 * c, n = {
                    height: "".concat(a, "px"),
                    lineHeight: "".concat(a, "px"),
                    paddingTop: "".concat(i.paddingTop, "px")
                };
                return Object(d["jsxs"])(u["View"], {
                    children: [ Object(d["jsx"])(u["View"], {
                        className: "header-white header",
                        style: n,
                        children: Object(d["jsx"])(u["Image"], {
                            className: "mini-logo",
                            mode: "heightFix",
                            src: "".concat(t.attachurl).concat(t.app_logo_a)
                        })
                    }), Object(d["jsx"])(u["View"], {
                        style: n
                    }) ]
                });
            }, D = function() {
                return Object(d["jsx"])(u["View"], {
                    className: "swiper-v-big",
                    children: Object(d["jsx"])(u["Swiper"], {
                        className: "swiper",
                        indicatorDots: !1,
                        autoplay: !0,
                        circular: !0,
                        children: h.map(function(e, c) {
                            return Object(d["jsx"])(u["SwiperItem"], {
                                className: "swiper",
                                onClick: function() {
                                    return Object(j["a"])(e);
                                },
                                children: Object(d["jsx"])(u["Image"], {
                                    className: "swiper-image",
                                    src: "".concat(t.attachurl).concat(e.image)
                                })
                            }, c);
                        })
                    })
                });
            }, P = function(e) {
                return Object(d["jsxs"])(u["View"], {
                    className: "nav_search",
                    children: [ Object(d["jsxs"])(u["View"], {
                        className: "input",
                        onClick: U,
                        children: [ Object(d["jsx"])(u["Text"], {
                            className: "iconfont icon-sousuo"
                        }), Object(d["jsx"])(u["View"], {
                            className: "input_value",
                            children: "搜索一下您想要物品"
                        }) ]
                    }), Object(d["jsx"])(u["Text"], {
                        className: "notice iconfont icon-renwuzhongxin-kaiqixiaoxitongzhi",
                        onClick: function() {
                            l.a.navigateTo({
                                url: "/pages/my/notice/index"
                            });
                        }
                    }) ]
                });
            };
            return Object(d["jsxs"])(u["View"], {
                className: "index-page",
                children: [ q(), P(), D(), Object(d["jsx"])(u["View"], {
                    className: "simplictiy-v",
                    children: Object(d["jsxs"])(u["View"], {
                        className: "simplictiy",
                        children: [ Object(d["jsxs"])(u["View"], {
                            className: "simplictiy-top",
                            children: [ Object(d["jsxs"])(u["View"], {
                                className: "userinfo",
                                children: [ Object(d["jsx"])(u["View"], {
                                    className: "avatar",
                                    children: Object(d["jsx"])(u["OpenData"], {
                                        type: "userAvatarUrl"
                                    })
                                }), Object(d["jsx"])(u["OpenData"], {
                                    type: "userNickName"
                                }) ]
                            }), Object(d["jsx"])(u["View"], {
                                style: {
                                    marginRight: 10
                                },
                                className: "r-icon",
                                onClick: function() {
                                    return V(1 == w ? 0 : 1);
                                },
                                children: 0 == w ? Object(d["jsx"])(u["Image"], {
                                    src: y.a,
                                    style: {
                                        height: 20,
                                        width: 20
                                    }
                                }) : Object(d["jsx"])(u["Image"], {
                                    src: N.a,
                                    style: {
                                        height: 20,
                                        width: 20
                                    }
                                })
                            }) ]
                        }), Object(d["jsx"])(u["View"], {
                            className: 1 == w ? "simplicity-item-row" : "",
                            children: _.map(function(e, t) {
                                return Object(d["jsx"])(f, {
                                    item: e
                                }, t);
                            })
                        }), E >= I ? Object(d["jsx"])(u["View"], {
                            className: "footer-desc",
                            children: "已经到底拉~"
                        }) : null ]
                    })
                }) ]
            });
        }, S = v, _ = c(61), k = c(14), C = c(114), T = c.n(C), I = (c(210), i.a.memo(function() {
            var e = Object(s["useState"])(!1), t = Object(n["a"])(e, 2), c = t[0], a = t[1], i = Object(s["useState"])(!1), o = Object(n["a"])(i, 2), l = o[0], r = o[1], O = Object(s["useState"])({}), x = Object(n["a"])(O, 2), h = x[0], m = x[1], p = Object(s["useState"])([]), g = Object(n["a"])(p, 2), f = g[0], w = g[1];
            Object(s["useEffect"])(function() {
                Object(j["f"])(m), N(), y();
            }, []);
            var N = function() {
                var e = wx.getStorageSync("getUserProfile");
                a(1 == e);
            }, V = function(e, t) {
                N(), console.log(t), w(t);
            }, y = function() {
                Object(j["d"])({
                    url: "entry/wxapp/GetNewUserCoupon",
                    data: {},
                    success: function(e) {
                        r(e.has);
                    }
                });
            };
            return Object(d["jsxs"])(d["Fragment"], {
                children: [ c ? null : Object(d["jsx"])(u["View"], {
                    class: "user-login-tips-view ".concat(c ? "fadeOutIn" : "fadelogIn"),
                    children: Object(d["jsxs"])(u["View"], {
                        class: "user-login-tips bb-shadow ",
                        children: [ Object(d["jsx"])(u["View"], {
                            class: "tips",
                            children: "登录后享受完整服务"
                        }), Object(d["jsx"])(k["a"], {
                            className: "nocss-button login-btn",
                            onClick: N,
                            size: "mini",
                            children: "微信一键登陆"
                        }) ]
                    })
                }), h.new_user_coupon_image && !c ? Object(d["jsx"])(b["a"], {
                    isOpened: l,
                    onClose: function() {
                        r(!1);
                    },
                    children: Object(d["jsx"])(k["a"], {
                        className: "nocss-button n",
                        onClick: V,
                        children: Object(d["jsx"])(u["Image"], {
                            style: "width:100%;height:250px",
                            mode: "widthFix",
                            src: "".concat(h.attachurl).concat(h.new_user_coupon_image)
                        })
                    })
                }) : null, f.length > 0 ? Object(d["jsx"])(u["View"], {
                    className: "lq-ok",
                    children: Object(d["jsxs"])(u["View"], {
                        className: "con",
                        children: [ Object(d["jsx"])(u["Image"], {
                            src: T.a,
                            className: "top-image",
                            mode: "widthFix"
                        }), Object(d["jsx"])(u["View"], {
                            className: "coupons",
                            children: f.map(function(e, t) {
                                return Object(d["jsxs"])(u["View"], {
                                    className: "coupon",
                                    children: [ Object(d["jsxs"])(u["View"], {
                                        className: "c-left",
                                        children: [ Object(d["jsx"])(u["View"], {
                                            className: "desc",
                                            children: 0 == e.limit ? "无门槛" : "满".concat(Object(j["i"])(e.limit), "元可用")
                                        }), Object(d["jsxs"])(u["View"], {
                                            className: "ppr",
                                            children: [ Object(d["jsx"])(u["Text"], {
                                                className: "yuan",
                                                children: "¥"
                                            }), Object(j["i"])(e.price) ]
                                        }) ]
                                    }), Object(d["jsxs"])(u["View"], {
                                        className: "c-right",
                                        children: [ Object(d["jsx"])(u["View"], {
                                            className: "title",
                                            children: "代金券"
                                        }), Object(d["jsxs"])(u["View"], {
                                            className: "desc",
                                            children: [ "有效期至 ", -1 == e.expr ? "永不过期" : e.expr ]
                                        }) ]
                                    }) ]
                                });
                            })
                        }), Object(d["jsx"])(k["a"], {
                            className: "nocss-button du_btn njk",
                            onClick: function() {
                                w([]);
                            },
                            children: "我知道了"
                        }) ]
                    })
                }) : null ]
            });
        })), F = I, B = function() {
            var e = Object(s["useState"])({
                home_style: -1
            }), t = Object(n["a"])(e, 2), c = t[0], a = t[1];
            return Object(s["useEffect"])(function() {
                Object(j["f"])(a);
            }, []), Object(o["useShareAppMessage"])(function() {
                var e = l.a.getStorageSync("userInfo"), t = e.uid;
                return {
                    title: c.share_title,
                    path: t ? "/pages/index/index?fuid=".concat(t) : "/pages/index/index",
                    imageUrl: "".concat(c.attachurl).concat(c.share_image)
                };
            }), Object(d["jsxs"])(d["Fragment"], {
                children: [ 2 == c.home_style ? Object(d["jsx"])(p, {
                    config: c
                }) : null, 1 == c.home_style ? Object(d["jsx"])(S, {
                    config: c
                }) : null, Object(d["jsx"])(_["a"], {}), Object(d["jsx"])(F, {}) ]
            });
        }, z = B, E = {
            navigationBarTitleText: "牛牛盒子",
            navigationStyle: "custom",
            enableShareAppMessage: !0
        };
        z.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(z, "pages/index/index", {
            root: {
                cn: []
            }
        }, E || {}));
    }
}, [ [ 267, 0, 2, 1, 3 ] ] ]);