(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 30 ], {
    128: function(e, s, c) {
        e.exports = c.p + "assets/images/result_rule.jpg";
    },
    244: function(e, s, c) {},
    292: function(e, s, c) {
        "use strict";
        c.r(s);
        var i = c(7), t = c(3), a = c(2), l = c(4), j = c.n(l), r = c(1), n = (c(15), c(30), 
        c(35), c(34), c(79), c(128)), d = c.n(n), b = (c(244), c(5)), x = c(0), O = function() {
            var e = Object(l["useRouter"])(), s = Object(a["useState"])(!1), c = Object(t["a"])(s, 2), i = c[0], n = c[1], O = Object(a["useState"])(!1), o = Object(t["a"])(O, 2), h = o[0], m = o[1], w = Object(a["useState"])({}), p = Object(t["a"])(w, 2), V = p[0], _ = p[1], u = Object(a["useState"])([]), N = Object(t["a"])(u, 2), g = N[0], f = N[1], y = Object(a["useState"])(0), z = Object(t["a"])(y, 2), B = z[0], k = z[1], A = Object(a["useState"])(0), S = Object(t["a"])(A, 2), T = S[0], v = S[1];
            Object(l["useShareAppMessage"])(function() {
                var e = j.a.getStorageSync("userInfo"), s = e.uid;
                return {
                    title: V.share_title,
                    path: s ? "/pages/index/index?fuid=".concat(s) : "/pages/index/index",
                    imageUrl: "".concat(V.attachurl).concat(V.share_image)
                };
            }), Object(a["useEffect"])(function() {
                Object(b["f"])(_), W();
            }, []);
            var C = function(s) {
                var c = e.params, i = c.batch_no, t = c.box_id;
                Object(b["d"])({
                    url: "entry/wxapp/BatchBuyList",
                    data: {
                        batch_no: i,
                        box_id: t,
                        page: s ? B + 1 : B - 1
                    },
                    success: function(e) {
                        k(e.current_page), f(e.list), v(e.total_page);
                    }
                });
            }, W = function() {
                var s = e.params, c = s.batch_no, i = s.box_id;
                Object(b["d"])({
                    url: "entry/wxapp/BatchDetails",
                    data: {
                        batch_no: c,
                        box_id: i
                    },
                    success: function(e) {
                        m(e), 3 == e.open_prize && C();
                    }
                });
            };
            return Object(x["jsxs"])(r["View"], {
                className: "results-page",
                children: [ Object(x["jsx"])(r["View"], {
                    className: "title",
                    children: Object(x["jsxs"])(r["View"], {
                        children: [ "第", e.params.batch_no, "期开奖详情" ]
                    })
                }), Object(x["jsxs"])(r["View"], {
                    className: "prize",
                    children: [ Object(x["jsx"])(r["View"], {
                        className: "p_title",
                        children: "奖品信息"
                    }), Object(x["jsxs"])(r["View"], {
                        className: "p",
                        children: [ Object(x["jsx"])(r["Image"], {
                            className: "prizeimage",
                            src: "".concat(V.attachurl).concat(h.prize_image)
                        }), Object(x["jsxs"])(r["View"], {
                            className: "p-i",
                            children: [ Object(x["jsx"])(r["View"], {
                                className: "t",
                                children: h.prize_name
                            }), Object(x["jsxs"])(r["View"], {
                                className: "red",
                                children: [ "价值 ￥", Object(b["i"])(h.prize_price) ]
                            }) ]
                        }) ]
                    }) ]
                }), 3 == h.open_prize ? Object(x["jsxs"])(r["View"], {
                    className: "prize",
                    children: [ Object(x["jsx"])(r["View"], {
                        className: "p_title",
                        children: "奖品获得者"
                    }), Object(x["jsxs"])(r["View"], {
                        className: "p",
                        children: [ Object(x["jsx"])(r["Image"], {
                            className: "avatar",
                            src: h.luck_user_avatar
                        }), Object(x["jsxs"])(r["View"], {
                            className: "info",
                            children: [ Object(x["jsxs"])(r["View"], {
                                children: [ "本期中奖: ", h.luck_user_nickname ]
                            }), Object(x["jsxs"])(r["View"], {
                                children: [ "用户ID: ", h.luck_user_uid ]
                            }), Object(x["jsxs"])(r["View"], {
                                children: [ "中奖号码: ", h.code ]
                            }), Object(x["jsxs"])(r["View"], {
                                children: [ "购买时间: ", h.luck_user_buy_time ]
                            }), Object(x["jsxs"])(r["View"], {
                                children: [ "中奖时间: ", h.luck_user_open_time ]
                            }) ]
                        }) ]
                    }) ]
                }) : null, Object(x["jsxs"])(r["View"], {
                    className: "prize",
                    style: {
                        overflow: "hidden"
                    },
                    children: [ Object(x["jsx"])(r["View"], {
                        style: {
                            backgroundColor: "#fcd554",
                            borderBottom: "0.5px solid rgba(255,255,255,.6)"
                        },
                        className: "p_title",
                        children: "中奖码计算公式"
                    }), Object(x["jsx"])(r["View"], {
                        className: "p",
                        style: {
                            backgroundColor: "#fcd554"
                        },
                        children: Object(x["jsx"])(r["Image"], {
                            mode: "widthFix",
                            className: "result_rule_image",
                            src: d.a
                        })
                    }), Object(x["jsxs"])(r["View"], {
                        className: "djcd",
                        style: {
                            backgroundColor: "#fcd554"
                        },
                        onClick: function() {
                            return n(!i);
                        },
                        children: [ "点击查看中奖码计算公式说明", Object(x["jsx"])(r["Text"], {
                            className: "iconfont icon-arrowRight-copy ".concat(i ? "z" : "")
                        }) ]
                    }), i ? Object(x["jsxs"])(r["View"], {
                        className: "desc",
                        style: {
                            backgroundColor: "#fcd554"
                        },
                        children: [ Object(x["jsx"])(r["View"], {
                            children: "1、本期最后一个销售完毕后，将公示该时间点前开奖数的20%取整（大于100取100）名用户的购买时间;"
                        }), Object(x["jsx"])(r["View"], {
                            children: "2、将这个时间的数值进行求和(得出购买时间参数A) (每 个时间按时、分、的顺序组合，如2021-03-19 15:30则取值为2103191530) ;"
                        }), Object(x["jsx"])(r["View"], {
                            children: "3、本期最后一个销售时间的下一个整数分钟对应的比特币美元报价的值(得出第三方随机参数B) (取值 为该时间点比特币美元报价所有数字的组合，如最后一名用户的购买时间为2021-4-09 09:20，对应的下一个整数分钟: 2021-04-09 09:20的比特币美元报价为58463.82元，则取值58463)"
                        }), Object(x["jsx"])(r["View"], {
                            children: "4、购买时间参数A加上第三方随机参数B,然后除以本期销售总数后的余数+原始数1000001,得到本期的中奖号码。1、本期最后一个销售完毕后，将公示该时间点前最后10名或100名用户的购买时间;"
                        }), Object(x["jsx"])(r["View"], {
                            children: "4、购买时间参数A加上第三方随机参数B,然后除以本期销售总数后的余数+原始数1000001,得到本期的中奖号码。"
                        }), Object(x["jsx"])(r["View"], {
                            style: {
                                fontWeight: "bold"
                            },
                            children: '特别说明:取"余数\'是指取没有被整除的部分例如30: 8,可以整除的部分是24,不能被整除的部分是6,所以30: 8的余数是6。(小数不同于余数，同样是_上面的例子，30: 8=3.75,部分用户会误以为余数是0.75,事实.上余数应为6。更多关于余数的介绍，请百度搜索"余数")'
                        }) ]
                    }) : null ]
                }), 3 == h.open_prize ? Object(x["jsxs"])(r["View"], {
                    className: "prize",
                    children: [ Object(x["jsx"])(r["View"], {
                        className: "p_title",
                        children: "购买时间参数A"
                    }), Object(x["jsxs"])(r["View"], {
                        className: "desc",
                        style: {
                            color: "#333",
                            fontSize: "12px",
                            padding: "10px"
                        },
                        children: [ Object(x["jsxs"])(r["View"], {
                            children: [ "每期最后一名用户购买完成之后,系统自动将最后", h.prize_time_sum_num, "名下单用户的购买时间的值(时:分:秒:毫秒)取和，该值即为购买时间参数A。" ]
                        }), Object(x["jsx"])(r["View"], {
                            style: {
                                color: "rgba(0,0,0,.5)",
                                padding: "5px",
                                margin: "10px 0",
                                borderLeft: "3px solid #a9a9a9"
                            },
                            children: "例如:最后一名用户购买时间为2020-05-2215:41:30.711,则取值为154130711,按照同样的取值规则取最后10名用户购买时间值逐一加和，加和后得到的值即为本期购买时间参数A。"
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ "本期最后一名用户购买时间:", h.last_order_buy_time ]
                        }), Object(x["jsx"])(r["View"], {
                            children: "本期所有用户的购买时间如下,欢迎截屏存档，以便开奖后验证"
                        }) ]
                    }), Object(x["jsxs"])(r["View"], {
                        className: "time_list",
                        children: [ g.map(function(e, s) {
                            return Object(x["jsxs"])(r["View"], {
                                className: "time_list_row",
                                children: [ Object(x["jsx"])(r["View"], {
                                    children: e.ms_time
                                }), Object(x["jsx"])(r["View"], {
                                    children: e.code
                                }), Object(x["jsx"])(r["View"], {
                                    children: e.user_nickname
                                }) ]
                            }, s);
                        }), Object(x["jsxs"])(r["View"], {
                            className: "time_list_row",
                            children: [ B > 1 ? Object(x["jsx"])(r["View"], {
                                onClick: function() {
                                    return C(!1);
                                },
                                children: "上一页"
                            }) : Object(x["jsx"])(r["View"], {}), Object(x["jsx"])(r["View"], {}), B >= T ? Object(x["jsx"])(r["View"], {
                                onClick: function() {
                                    return C();
                                },
                                children: "下一页"
                            }) : Object(x["jsx"])(r["View"], {}) ]
                        }) ]
                    }), Object(x["jsxs"])(r["View"], {
                        className: "desc",
                        style: {
                            color: "#333",
                            fontSize: "12px",
                            padding: "10px"
                        },
                        children: [ Object(x["jsxs"])(r["View"], {
                            children: [ "本期最后", h.prize_time_sum_num, "名用户购买时间值加和为", h.params_a ]
                        }), Object(x["jsxs"])(r["View"], {
                            style: {
                                fontWeight: "bold"
                            },
                            children: [ "所以本期“购买时间参数A”取值:", h.params_a ]
                        }) ]
                    }) ]
                }) : null, 3 == h.open_prize ? Object(x["jsxs"])(r["View"], {
                    className: "prize",
                    children: [ Object(x["jsx"])(r["View"], {
                        className: "p_title",
                        children: "第三方随机参数B"
                    }), Object(x["jsxs"])(r["View"], {
                        className: "desc",
                        style: {
                            color: "#333",
                            fontSize: "12px",
                            padding: "10px"
                        },
                        children: [ Object(x["jsx"])(r["View"], {
                            children: "每期最后一名用户购买完成之后系统自动获取下一个整数分钟的比特币美元报价,将报价去除小数点后得到的数字串即为第三方随机参数B。"
                        }), Object(x["jsx"])(r["View"], {
                            style: {
                                color: "rgba(0,0,0,.5)",
                                padding: "5px",
                                margin: "10px 0",
                                borderLeft: "3px solid #a9a9a9"
                            },
                            children: "例如:最后一名用户的购买时间为2020-11-05 15:09:30.711,对应的下一个整数分钟:2020-11-05 15:10:00的比特币美元报价为14367.05元,则取值1436705,该数值即为本期第三方随机参数B"
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ "本期最后一名用户购买时间", Object(x["jsx"])(r["Text"], {
                                style: {
                                    fontWeight: "bold",
                                    color: "red"
                                },
                                children: h.last_order_buy_time
                            }), ",下一个整数分钟为:", Object(x["jsx"])(r["Text"], {
                                style: {
                                    fontWeight: "bold",
                                    color: "red"
                                },
                                children: h.params_b_time_at
                            }), ",该时间的比特币美元报价为", Object(x["jsx"])(r["Text"], {
                                style: {
                                    fontWeight: "bold",
                                    color: "red"
                                },
                                children: Object(b["i"])(h.params_b)
                            }) ]
                        }), Object(x["jsxs"])(r["View"], {
                            style: {
                                fontWeight: "bold"
                            },
                            children: [ "所以本期“第三方随机参数B取值", Object(x["jsx"])(r["Text"], {
                                style: {
                                    fontWeight: "bold",
                                    color: "red"
                                },
                                children: h.params_b
                            }) ]
                        }) ]
                    }) ]
                }) : null, Object(x["jsxs"])(r["View"], {
                    className: "prize",
                    children: [ Object(x["jsx"])(r["View"], {
                        className: "p_title",
                        children: "本期中奖号码"
                    }), Object(x["jsxs"])(r["View"], {
                        className: "code",
                        children: [ 3 == h.open_prize ? Object(x["jsxs"])(r["View"], {
                            className: "_code",
                            children: [ Object(x["jsx"])(r["View"], {
                                children: h.code
                            }), Object(x["jsx"])(r["View"], {
                                className: "_desc",
                                children: "本期中奖码"
                            }) ]
                        }) : Object(x["jsxs"])(r["View"], {
                            className: "_code",
                            children: [ Object(x["jsx"])(r["View"], {
                                children: h.code
                            }), Object(x["jsx"])(r["View"], {
                                className: "_desc",
                                children: "尚未开奖"
                            }) ]
                        }), Object(x["jsx"])(r["View"], {
                            children: "="
                        }), Object(x["jsxs"])(r["View"], {
                            className: "gs",
                            children: [ Object(x["jsxs"])(r["View"], {
                                children: [ Object(x["jsxs"])(r["View"], {
                                    className: "ss",
                                    children: [ Object(x["jsxs"])(r["View"], {
                                        className: "param",
                                        children: [ Object(x["jsx"])(r["View"], {
                                            className: "red",
                                            children: h.params_a ? h.params_a : "?"
                                        }), Object(x["jsx"])(r["View"], {
                                            className: "f",
                                            children: "购买时间参数A"
                                        }) ]
                                    }), Object(x["jsx"])(r["View"], {
                                        className: "add",
                                        children: "+"
                                    }), Object(x["jsxs"])(r["View"], {
                                        className: "param",
                                        children: [ Object(x["jsx"])(r["View"], {
                                            className: "red",
                                            children: h.params_b ? h.params_b : "?"
                                        }), Object(x["jsx"])(r["View"], {
                                            className: "f",
                                            children: "第三方随机参数B"
                                        }) ]
                                    }) ]
                                }), Object(x["jsx"])(r["View"], {
                                    className: "ss",
                                    style: {
                                        borderBottom: 0
                                    },
                                    children: Object(x["jsxs"])(r["View"], {
                                        className: "param",
                                        children: [ Object(x["jsx"])(r["View"], {
                                            className: "red",
                                            children: h.open_stock
                                        }), Object(x["jsx"])(r["View"], {
                                            className: "f",
                                            children: "抽奖码总数"
                                        }) ]
                                    })
                                }) ]
                            }), Object(x["jsx"])(r["View"], {
                                style: {
                                    flex: "1"
                                },
                                children: "取余数"
                            }), Object(x["jsx"])(r["View"], {
                                className: "add",
                                children: "+"
                            }), Object(x["jsx"])(r["View"], {
                                children: Object(x["jsxs"])(r["View"], {
                                    className: "param",
                                    children: [ Object(x["jsx"])(r["View"], {
                                        className: "red",
                                        children: "10000001"
                                    }), Object(x["jsx"])(r["View"], {
                                        className: "f",
                                        children: "原始数"
                                    }) ]
                                })
                            }) ]
                        }) ]
                    }) ]
                }), Object(x["jsxs"])(r["View"], {
                    className: "prize",
                    children: [ Object(x["jsx"])(r["View"], {
                        className: "p_title",
                        children: "中奖逻辑"
                    }), Object(x["jsxs"])(r["View"], {
                        className: "desc desc_",
                        children: [ Object(x["jsxs"])(r["View"], {
                            children: [ Object(x["jsx"])(r["Text"], {
                                className: "as"
                            }), "用户在购买盒子时获赠的抽奖码是从10000001开始逐号递增，连续发放,直至当期的盒子全部抢完。" ]
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ Object(x["jsx"])(r["Text"], {
                                className: "as"
                            }), "通过观察中奖公式可以发现,对除法的结果取余数，因为除数是本期的盒子总数,所以余数的结果可能为0至(本期盒子总数-1)中的任何一个整数，在这个结果的基础上+10000001,就可以确保一定有 人中奖，且中奖码为当期所有抽奖码中的一个。" ]
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ Object(x["jsx"])(r["Text"], {
                                className: "as"
                            }), "由开奖步骤可以知道，系统预先按照购买顺序分配了抽奖码，这些抽奖码已经固定下来而且对全网公示，任何人都不可能更改。" ]
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ Object(x["jsx"])(r["Text"], {
                                className: "as"
                            }), "参数A和参数B都是在确认了每个人的抽奖码以后才能产生。中奖公式中的“购买时间参数A”是系统自动记录的用户的购买时间，“第三方随机参数B”是在A值确定之后,再引入的是互联网上完全公开的权威变动数值,任何人都不可能控制。在在这种情况下，运算出来的数值完全不存在人为操纵的可能性。" ]
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ Object(x["jsx"])(r["Text"], {
                                className: "as"
                            }), "假设试图作弊需要在购买盒子获得抽奖码后，人为修改“购买时间参数A”和“第三方随机参数B”，这样才能影响到运算的结果。事实上，在最后个用户购买完成之 后，购买时间参数A已经固定且在全网公示，旦被篡改一定会被发现。而且第三方随机参数B还产生在此之后，第三方随机参数B是互联网上全网可查的权威数值，更不存在人为控制的可能性" ]
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ Object(x["jsx"])(r["Text"], {
                                className: "as"
                            }), "综上所述，获奖编码的运算完全基于随机,包含运营方在内的任何人不存在操控结果的主客观条件，开奖步骤全程公开，开奖结果绝对公平所有数据都在往期记录中永久保存，支持任何方式验证。" ]
                        }), Object(x["jsxs"])(r["View"], {
                            children: [ Object(x["jsx"])(r["Text"], {
                                className: "as"
                            }), "用户也可以通过独自买断一期全部盒子,或者联合几个朋友共同买断一期所有盒子等任何方式进行真实性验证。" ]
                        }) ]
                    }) ]
                }) ]
            });
        }, o = O, h = {
            navigationBarTitleText: "开奖结果",
            enableShareAppMessage: !0
        };
        o.enableShareAppMessage = !0;
        Page(Object(i["createPageConfig"])(o, "pages/detail/results/index", {
            root: {
                cn: []
            }
        }, h || {}));
    }
}, [ [ 292, 0, 2, 1, 3 ] ] ]);