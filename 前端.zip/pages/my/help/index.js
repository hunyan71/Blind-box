(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 50 ], {
    223: function(e, t, c) {},
    276: function(e, t, c) {
        "use strict";
        c.r(t);
        var n = c(7), i = c(3), a = c(2), s = c(4), r = c.n(s), o = c(1), l = (c(223), c(5)), j = c(0), u = function() {
            var e = Object(a["useState"])([]), t = Object(i["a"])(e, 2), c = t[0], n = t[1];
            Object(a["useEffect"])(function() {
                s();
            }, []);
            var s = function() {
                Object(l["d"])({
                    url: "entry/wxapp/HelpList",
                    success: function(e) {
                        n(e);
                    }
                });
            };
            return Object(j["jsxs"])(o["View"], {
                className: "help-page",
                children: [ Object(j["jsx"])(o["View"], {
                    className: "title",
                    children: "常见问题"
                }), c.map(function(e, t) {
                    return Object(j["jsxs"])(o["View"], {
                        className: "trow",
                        onClick: function() {
                            r.a.navigateTo({
                                url: "/pages/my/help/details/index?id=".concat(e.id)
                            });
                        },
                        children: [ Object(j["jsx"])(o["View"], {
                            className: "t",
                            children: e.title
                        }), Object(j["jsx"])(o["View"], {
                            children: Object(j["jsx"])(o["Text"], {
                                className: "iconfont icon-arrow-right"
                            })
                        }) ]
                    }, t);
                }) ]
            });
        }, p = u, b = {
            navigationBarTitleText: "常见问题"
        };
        Page(Object(n["createPageConfig"])(p, "pages/my/help/index", {
            root: {
                cn: []
            }
        }, b || {}));
    }
}, [ [ 276, 0, 2, 1, 3 ] ] ]);