create table ims_niuniu_mang_category
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `sort`       int          not null default 0,
    `uniacid`    int          not null,
    `parent_id`  int                   default 0 comment '上级id',
    `name`       varchar(255) not null comment '分类名称',
    `image`      varchar(255)          default '' comment '分类图片',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_commodity
(
    `id`                   int auto_increment primary key,
    `acid`                 int          not null,
    `uniacid`              int          not null,
    `type`                 int          not null comment '1 正常盲盒 2 幸运盲盒',
    `title`                varchar(255) not null comment '盲盒标题',
    `category_id`          int          not null default 0 comment '分类',
    `category_sub_id`      int          not null default 0 comment '二级分类',
    `sub_title`            varchar(255) not null comment '盲盒副标题',
    `price`                int          not null comment '盲盒单价',
    `text_content`         longtext comment '详情图文',
    `text_rule`            longtext comment '规则图文',
    `cabinet_image`        varchar(255) comment '盒子图片',
    `batch_num`            int comment '一共发送多少期',
    `batch_draw_num`       int comment '开奖数量 每期多少个',
    `prize_name`           varchar(255) comment '奖品名称',
    `prize_image`          varchar(255) comment '奖品图片',
    `prize_price`          varchar(255) comment '奖品价值',
    `page_bg_color`        varchar(255) comment '背景色',
    `page_bg_music`        varchar(255) comment '页面背景音乐',
    `page_bg_image`        varchar(255) comment '背景图片',
    `page_banner_image`    varchar(255) comment '上部分跳动图片',
    `page_box_base_image`  varchar(255) comment '盒子底座',
    `page_box_panel_image` varchar(255) comment '盒子前面板',
    `page_box_image`       varchar(255) comment '盒子的图片',
    `page_one_box_image`   varchar(255) comment '单个盒子的图片',
    `page_box_row_num`     int comment '盒子的大小 1 大[一排3个共9个] 2 小[一排4个共12个] ',

    `luck_image`           varchar(255) comment '幸运盒子的首页图片',
    `item_image`           varchar(255) comment '正常图片',
    `share_desc`           varchar(255) comment '分享简介',
    `share_image`          varchar(255) comment '分享图片',
    `share_title`          varchar(255) comment '分享标题',

    `recommend`            int not default 0 comment '是否推荐',
    `recommend_image`      varchar(255) comment '推荐位图片',

    `dan_open`             int          not null default '0',
    `dan_prize_open`       int          not null default '0',
    `status`               int          not null default '2' comment '1 正常 2 待上传物品 3 下架',

    `sort`                 int          not null default '0',
    `deleted`              int          not null default '0',
    `deleted_at`           int          null,
    `created_at`           int          not null,
    `updated_at`           int          not null
) charset utf8;

create table ims_niuniu_mang_commodity_item
(
    `id`             int auto_increment primary key,
    `acid`           int          not null,
    `uniacid`        int          not null,
    `bid`            int          not null comment '盲盒id',
    `num`            int          not null comment '总数 0 不限制',
    `rate`           float        not null comment '稀有度',
    `image`          varchar(255) not null comment '图片',
    `name`           varchar(255) not null comment '名称',
    `special`        int          not null default 0 comment '特殊款？',
    `deleted`        int          not null default '0',
    `sort`           int          not null default '0',
    `price`          varchar(255) not null default '0',
    `recovery_price` int          not null default '0',
    `deleted_at`     int          null,
    `created_at`     int          not null,
    `updated_at`     int          not null
) charset utf8;


create table ims_niuniu_mang_setting
(
    `id`                   int auto_increment primary key,
    `acid`                 int          not null,
    `uniacid`              int          not null,
    `app_logo_a`           varchar(255) not null comment '淡色Logo',
    `app_logo_b`           varchar(255) not null comment '深色Logo',
    `delevery_price`       int          not null comment '发货运费',
    `delevery_api_appcode` varchar(255) null,

    `submsg_open`          varchar(255) null comment '订阅消息ID 开奖提醒',
    `submsg_1`             varchar(255) null comment '订阅消息ID 活动提醒1',
    `submsg_2`             varchar(255) null comment '订阅消息ID 活动提醒2',
    `submsg_3`             varchar(255) null comment '订阅消息ID 活动提醒',
    `share_title`          varchar(255) not null comment '分享标题',
    `share_desc`           varchar(255) not null comment '分享标题',
    `share_image`          varchar(255) not null comment '分享图片',

/* 更新 */
    `home_style`           int          not null default 1 comment '1 简约版 2 电商版',

    `index_luck_open`      int          not null default '1',
    `index_luck_bgcolor`   varchar(255) null,
    `index_luck_logo`      varchar(255) null,
    `index_one_open`       int          not null default '1',
    `index_one_title`      varchar(255) not null,
    `deleted`              int          not null default '0',
    `deleted_at`           int          null,
    `created_at`           int          not null,
    `updated_at`           int          not null
) charset utf8;



create table ims_niuniu_mang_slide
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `image`      varchar(255) not null,
    `jump_type`  int                   default 0 not null,
    `jump_path`  varchar(255),
    `sort`       int          not null default '0',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;


create table ims_niuniu_mang_luck_batch
(
    `id`            int auto_increment primary key,
    `acid`          int          not null,
    `uniacid`       int          not null,
    `bid`           int          not null comment '盲盒id',
    `batch_no`      int          not null comment '期数',
    `stock`         int          not null comment '本期数量',
    `sold_num`      int          not null comment '已售数量',
    `status`        int          not null comment '1进行中 2已完成',
    `open_prize`    int          not null default 1 comment '1 正常 2 待开奖 3 已开将',
    `open_time`     int          null comment '开奖时间',
    `params_a`      varchar(255) null,
    `params_b`      varchar(255) null,
    `params_b_time` varchar(255) null,
    `code`          varchar(255) null,
    `deleted`       int          not null default '0',
    `deleted_at`    int          null,
    `created_at`    int          not null,
    `updated_at`    int          not null
) charset utf8;

create table ims_niuniu_mang_barrage
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`        int          not null,
    `bid`        int          not null,
    `message`    varchar(255) not null,
    `status`     int          not null comment '1 正常 2 审核中 3 拒绝',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_user
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`        int          not null,
    `avatar`     varchar(255) not null,
    `nickname`   varchar(255) not null,
    `bot`        varchar(255) not null default 0 comment '1 机器人',
    `status`     int          not null comment '1 正常 2 拉黑',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_user_bill
(
    `id`         int auto_increment primary key,
    `acid`       int not null,
    `uniacid`    int not null,
    `uid`        int not null,
    `type`       int not null comment '1 收入 2 支出',
    `pay_type`   int not null comment '1 微信 2 余额',
    `price`      int not null comment '金额',
    `order_no`   int not null comment '订单',
    `order_type` int not null comment '1 订单 2 回收 3 充值 4 发货 5 一级分佣 6 二级分佣 7 提现 8 手动充值',
    `status`     int not null comment '1 正常 2 审核中 3 拒绝',
    `deleted`    int not null default '0',
    `deleted_at` int null,
    `created_at` int not null,
    `updated_at` int not null
) charset utf8;


create table ims_niuniu_mang_order
(
    `id`                   int auto_increment primary key,
    `acid`                 int          not null,
    `uniacid`              int          not null,
    `uid`                  int          not null,
    `appid`                varchar(255) not null,
    `mch_id`               varchar(255) not null,
    `box_id`               int          not null comment '盲盒id',
    `box_type`             int          not null comment '盲盒类型',
    `out_trade_no`         varchar(255) not null comment '平台订单号',
    `transaction_id`       varchar(255) null comment '微信订单号',
    `unit_price`           int          not null comment '单价',
    `total_price`          int          not null comment '总价',
    `wxpay_price`          int          not null comment '微信支付金额',
    `balance_price`        int          not null comment '余额支付金额',
    `pay_status`           int          not null comment '支付状态，1 已支付 2 未支付',
    `pay_time`             int          not null comment '付款时间',
    `luck_order_time`      varchar(255) not null comment '毫秒时间戳',
    `buy_num`              int          not null default 1,
    `extract_status`       int          not null default 0 comment '1 已抽物品 0 未抽取 2 异常',
    `extract_success`      int          not null default 0 comment '发放成功数量',
    `extract_code_success` int          not null default 0 comment '发放成功数量',
    `preferential_price`   int          not null default 0 comment '优惠金额',
    `deleted`              int          not null default '0',
    `deleted_at`           int          null,
    `created_at`           int          not null,
    `updated_at`           int          not null
) charset utf8;

create table ims_niuniu_mang_order_item
(
    `id`                         int auto_increment primary key,
    `acid`                       int not null,
    `uniacid`                    int not null,
    `uid`                        int not null,
    `order_id`                   int not null comment '订单id',
    `box_id`                     int not null comment '盲盒id',
    `item_id`                    int not null comment '物品id',
    `status`                     int not null default 1 comment '1 正常 2 回收 3 发货 4 兑换卡片 5 已核销 6 已领取',
    `recovery_order_id`          int null comment '回收订单id',
    `delivery_order_id`          int null comment '发货订单id',

#     `recovery_price` int null comment '回收价格',
    `recovery_transaction_price` int null comment '回收成交价格',
    `deleted`                    int not null default '0',
    `deleted_at`                 int null,
    `created_at`                 int not null,
    `updated_at`                 int not null
) charset utf8;

create table ims_niuniu_mang_luck_code
(
    `id`                int auto_increment primary key,
    `acid`              int          not null,
    `uniacid`           int          not null,
    `uid`               int          not null,
    `order_id`          int          not null comment '订单号',
    `box_id`            int          not null comment '盲盒id',
    `batch_no`          int          not null comment '批次',
    `order_item_id`     int          not null comment '订单物品号',
    `item_id`           int          not null comment '物品id',
    `code`              varchar(255) not null comment '抽奖码',
    `status`            int          not null comment '0 未开奖 1 中奖 2 未中奖',

    `is_fa`             int          not null default 0 comment '是否发货 1 发货了 2 核销了',
    `ms_time`           varchar(255) not null,
    `delivery_order_id` int          null comment '回收订单id',
    `deleted`           int          not null default '0',
    `deleted_at`        int          null,
    `created_at`        int          not null,
    `updated_at`        int          not null
) charset utf8;



create table ims_niuniu_mang_search_key
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `search_key` varchar(255) not null,
    `num`        int          not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;


create table ims_niuniu_mang_recovery_order
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`        varchar(255) not null,
    `order_no`   varchar(255) not null,
    `price`      int          not null,
    `count_num`  int          not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_delivery_order
(
    `id`                int auto_increment primary key,
    `acid`              int          not null,
    `uniacid`           int          not null,
    `uid`               varchar(255) not null,
    `out_trade_no`      varchar(255) not null comment '平台订单号',
    `transaction_id`    varchar(255) null comment '微信订单号',
    `total_price`       int          not null,
    `wx_pay_price`      int          not null,
    `balance_pay_price` int          not null,
    `ids`               text         not null,
    `address`           varchar(255) not null,
    `tel`               varchar(255) not null,
    `name`              varchar(255) not null,
    `pay_status`        int          not null default 0,
    `pay_time`          int          null,
    `type`              int          not null default 1,
    `remark`            varchar(255) null,
    `status`            int          not null default 0 comment '0 待发货 1 已发货',
    `express_number`    varchar(255) null,
    `express_type`      varchar(255) null,
    `deleted`           int          not null default '0',
    `deleted_at`        int          null,
    `created_at`        int          not null,
    `updated_at`        int          not null
) charset = utf8;


create table ims_niuniu_mang_express_query
(
    `id`             int auto_increment primary key,
    `acid`           int          not null,
    `uniacid`        int          not null,
    `number`         varchar(255) not null,
    `type`           varchar(255) null,
    `typename`       varchar(255) null,
    `logo`           varchar(255) null,
    `list`           text         null,
    `deliverystatus` int          null,
    `query_time`     int          not null,
    `deleted`        int          not null default '0',
    `deleted_at`     int          null,
    `created_at`     int          not null,
    `updated_at`     int          not null
) charset = utf8;

# create table ims_niuniu_mang_open_prize_msg_task
# (
#     `id`         int auto_increment primary key,
#     `acid`       int not null,
#     `uniacid`    int not null,
#     `box_id`     int not null,
#     `batch_no`   int not null,
#     `status`     int not null default 0 comment '0 待处理 1 处理完成',
#     `deleted`    int not null default '0',
#     `deleted_at` int null,
#     `created_at` int not null,
#     `updated_at` int not null
# ) charset = utf8;

create table ims_niuniu_mang_sub_msg
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`        int          not null,
    `tmp_id`     varchar(255) not null,
    `num`        int          not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset = utf8;

create table ims_niuniu_mang_sub_msg_task
(
    `id`          int auto_increment primary key,
    `acid`        int          not null,
    `uniacid`     int          not null,
    `key`         varchar(255) not null,
    `uid`         int          not null,
    `msg_tmpl_id` varchar(255) null comment '模板消息',
    `content`     text,
    `status`      int          not null default 0 comment '0 未发送 1 待处理 2 已发送',
    `send_resp`   text,
    `deleted`     int          not null default '0',
    `deleted_at`  int          null,
    `created_at`  int          not null,
    `updated_at`  int          not null
) charset utf8;

create table ims_niuniu_mang_help
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `title`      varchar(255) not null,
    `text`       text,
    `sort`       int          not null default '0',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset = utf8;

create table ims_niuniu_mang_notice
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `title`      varchar(255) not null,
    `text`       text,
    `sort`       int          not null default '0',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset = utf8;


create table ims_niuniu_mang_user
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`        int          not null,
    `nickname`   varchar(255) not null,
    `openid`     varchar(255) not null,
    `avatar`     varchar(255) not null,
    `sort`       int          not null default '0',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset = utf8;

/* 新版 */

ALTER TABLE `ims_niuniu_mang_setting`
    ADD `home_style` INT NOT NULL DEFAULT '1' COMMENT '1 简约版 2 电商版' AFTER `delevery_api_appcode`;
ALTER TABLE `ims_niuniu_mang_setting`
    ADD `recommend_icon` VARCHAR(255) NULL DEFAULT NULL AFTER `home_style`;

ALTER TABLE `ims_niuniu_mang_setting`  ADD `new_user_coupon_image` VARCHAR(255) NULL DEFAULT NULL AFTER `home_style`;
ALTER TABLE `ims_niuniu_mang_setting`  ADD `spread_coupon_id` int default 0  AFTER `home_style`;

create table ims_niuniu_mang_recommende_slide
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `image`      varchar(255) not null,
    `top`        int                   default 0 not null,
    `jump_type`  int                   default 0 not null,
    `jump_path`  varchar(255),
    `sort`       int          not null default '0',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_recommende_icon
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `image`      varchar(255) not null,
    `name`       varchar(255) not null,
    `jump_type`  int                   default 0 not null,
    `jump_path`  varchar(255),
    `sort`       int          not null default '0',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;


ALTER TABLE `ims_niuniu_mang_slide`
    ADD `category_id` INT NULL DEFAULT '0' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_category`
    ADD `is_recommend` INT NULL DEFAULT '0' AFTER `updated_at`;

ALTER TABLE `ims_niuniu_mang_slide`
    ADD `jump_appid` VARCHAR(255) NULL AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_recommende_slide`
    ADD `jump_appid` VARCHAR(255) NULL AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_recommende_icon`
    ADD `jump_appid` VARCHAR(255) NULL AFTER `updated_at`;

ALTER TABLE `ims_niuniu_mang_setting`
    ADD `spread_banner` VARCHAR(255) NULL AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_setting`
    ADD `spread_level_1` int default 0 AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_setting`
    ADD `spread_level_2` int default 0 NULL AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_setting`
    ADD `invitation_top_image` varchar(255)  NULL AFTER `updated_at`;


ALTER TABLE `ims_niuniu_mang_commodity`
    add `style_type` int default 1 COMMENT '1 普通风格 2 商户风格' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity`
    add `ios_hidden` int default 1 COMMENT '0 ios 不显示 1 ios端显示' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity`
    add `merchant_id` int default 0 COMMENT '商户id' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity`
    add `prize_desc` VARCHAR(255) COMMENT '奖品介绍' AFTER `updated_at`;

ALTER TABLE `ims_niuniu_mang_commodity`
    add `prize_type` int default 0 COMMENT '物品类型 0 实物 1 虚拟 3 核销' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity`
    add `prize_fahuo_tempid` int default 0 COMMENT '虚拟发货id' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity`
    add `prize_ver_type` int default 1 COMMENT '核销方式' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity`
    add `prize_ver_code` VARCHAR(255) null COMMENT '核销码' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity`
    add `prize_merchant_id` int default 0 COMMENT '商户id' AFTER `updated_at`;


ALTER TABLE `ims_niuniu_mang_commodity_item`
    add `fahuo_tempid` int default 0 COMMENT '虚拟发货id' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity_item`
    add `ver_type` int default 1 COMMENT '核销方式' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity_item`
    add `ver_code` VARCHAR(255) null COMMENT '核销码' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity_item`
    add `desc` VARCHAR(255) null COMMENT '介绍 商家模板会显示' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity_item`
    add `merchant_id` int default 0 COMMENT '所属商户' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_commodity_item`
    add `type` int default 0 COMMENT '物品类型 0 实物 1 虚拟 3 核销' AFTER `updated_at`;

ALTER TABLE `ims_niuniu_mang_order_item`
    add `get_code` varchar(255) null COMMENT ' 1 虚拟 物品发货码' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_order_item`
    add `get_status` int default 0 COMMENT ' 1 已领取 0 未领取' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_order_item`
    add `get_type` int default 0 COMMENT ' 1 自动发码 2 固定二维码 2 固定码' AFTER `updated_at`;



ALTER TABLE `ims_niuniu_mang_order_item`
    add `code` VARCHAR(255) default null COMMENT '核销码' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_order_item`
    add `type` int default 0 COMMENT '物品类型 0 实物 1 虚拟 3 核销' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_order_item`
    add `exchange_card_order_id` int null comment '兑换订单id' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_order_item`
    add `he_status` int null default 0 comment '1 核销了 0 未核销' AFTER `updated_at`;

ALTER TABLE `ims_niuniu_mang_luck_code`
    add `vcode` VARCHAR(255) null comment '核销码' AFTER `updated_at`;

ALTER TABLE `ims_niuniu_mang_luck_code`
    add `get_code` varchar(255) null COMMENT ' 1 虚拟 物品发货码' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_luck_code`
    add `get_status` int default 0 COMMENT ' 1 已领取 0 未领取' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_luck_code`
    add `get_type` int default 0 COMMENT ' 1 自动发码 2 固定二维码 2 固定码' AFTER `updated_at`;

create table ims_niuniu_mang_merchant
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `name`       varchar(255) not null,
    `admin_uid`  int                   default 0 not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_merchant_store
(
    `id`          int auto_increment primary key,
    `acid`        int          not null,
    `uniacid`     int          not null,
    `merchant_id` int          not null,
    `name`        varchar(255) not null,
    `telphone`    varchar(255) not null,
    `open_time`   varchar(255) not null,
    `address`     varchar(255) not null,
    `location`    varchar(255) not null,
    `deleted`     int          not null default '0',
    `deleted_at`  int          null,
    `created_at`  int          not null,
    `updated_at`  int          not null
) charset utf8;


create table ims_niuniu_mang_card_prize
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`        int          not null,
    `box_id`     int          not null comment '盲盒id',
    `type`       int          not null comment '盲盒id',
    `code`       varchar(255) not null comment '核销码',
    `status`     int                   default 0 comment '0 未发货 1 已发货或核销',
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;



ALTER TABLE `ims_niuniu_mang_card_prize`
    add `get_code` varchar(255) null COMMENT ' 1 虚拟 物品发货码' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_card_prize`
    add `get_status` int default 0 COMMENT ' 1 已领取 0 未领取' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_card_prize`
    add `get_type` int default 0 COMMENT ' 1 自动发码 2 固定二维码 2 固定码' AFTER `updated_at`;
ALTER TABLE `ims_niuniu_mang_card_prize`
    add `delivery_order_id` int default 0 COMMENT ' 发货订单号' AFTER `updated_at`;


ALTER TABLE `ims_niuniu_mang_user`
    add parent_uid int default null comment '上级id';

create table ims_niuniu_mang_fictitious_tempalte
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`        int          not null,
    `name`       varchar(255) not null,
    `type`       int                   default 1,
    `qrcode`     varchar(255) null,
    `code`       varchar(255) null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;



create table ims_niuniu_mang_fictitious_code
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `ftid`       int          not null,
    `uid`        int          null,
    `code`       varchar(255) not null,
    `status`     int          not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_coupon
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `key` varchar(255) not null,
    `name` varchar(255) not null,
    `limit` int  not null,
    `price` int  not null,
    `num` int  not null default  0,
    `is_new_user` int default 0 not null,
    `use_key` int default 0 not null,
    `status`     int          not null default 1 comment  '1 正常 2 已下线',
    `expr_type` int  not null default 0,
    `expr_day` int not null,
    `expr_time` int not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

create table ims_niuniu_mang_coupon_user_log
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`    int          not null,
    `coupon_id`    int          not null,
    `name` varchar(255) not null,
    `limit` int  not null,
    `price` int  not null,
    `is_new_user` int default 0 not null,
    `status`     int          not null default 1 comment  '0 正常 2 已使用 3 过期了',
    `order_no` varchar(255) null,
    `expr_type` int  not null default 0,
    `expr_day` int not null,
    `expr_time` int not null,
    `expr` int not null,
    `use_time` int not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

ALTER TABLE `ims_niuniu_mang_order` add `preferential_id` int default 0 COMMENT '优惠券id' AFTER `updated_at`;



create table ims_niuniu_mang_give_log
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`    int          not null,
    `item_order_id`    int          not null,
    `token`    varchar(255)          not null,
    `gei_uid` int default  0,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;

# 2021年05月07日13:47:13

ALTER TABLE `ims_niuniu_mang_user_bill` CHANGE `order_no` `order_no` VARCHAR(255) NOT NULL COMMENT '订单';

#

ALTER TABLE `ims_niuniu_mang_setting`
    ADD `ktx` INT NOT NULL DEFAULT '1';


create table ims_niuniu_mang_user_tx
(
    `id`         int auto_increment primary key,
    `acid`       int          not null,
    `uniacid`    int          not null,
    `uid`    int          not null,
    `price`    int          not null,
    `image` longtext,
    `status` int default 0 comment '0 待处理 1 已处理 2 已到账',
    `eid` int not null,
    `deleted`    int          not null default '0',
    `deleted_at` int          null,
    `created_at` int          not null,
    `updated_at` int          not null
) charset utf8;