(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 18 ], {
    104: function(e, t, c) {},
    214: function(e, t, c) {},
    215: function(e, t, c) {},
    216: function(e, t, c) {},
    217: function(e, t, c) {},
    218: function(e, t, c) {},
    266: function(e, t, c) {
        "use strict";
        c.r(t);
        var s = c(7), n = c(12), a = c(13), i = c(3), l = c(2), o = c.n(l), r = c(4), j = c.n(r), b = c(1), d = c(5), u = c(44), m = (c(214), 
        c(0)), O = function() {
            return Object(m["jsx"])("view", {
                class: "sk-container",
                children: Object(m["jsxs"])("view", {
                    class: "box-details-page",
                    no_id: "_n_36",
                    style: "true",
                    children: [ Object(m["jsxs"])("view", {
                        class: "box-list",
                        "hover-class": "none",
                        "hover-start-time": "50",
                        "hover-stay-time": "400",
                        no_id: "_n_23",
                        style: "true",
                        children: [ Object(m["jsx"])("view", {
                            class: "badge-image-v",
                            no_id: "_n_10",
                            style: "true",
                            children: Object(m["jsx"])("view", {
                                class: "inf",
                                no_id: "_n_9",
                                style: "true"
                            })
                        }), Object(m["jsx"])("image", {
                            class: "box-image sk-image",
                            no_id: "_n_11",
                            mode: "widthFix",
                            style: "height: 132.042px;"
                        }), Object(m["jsxs"])("view", {
                            class: "info",
                            no_id: "_n_22",
                            style: "true",
                            children: [ Object(m["jsx"])("view", {
                                class: "t t-s sk-transparent sk-text-14-2857-503 sk-text",
                                no_id: "_n_12",
                                style: "true",
                                children: "iphone12免费送纸巾一包"
                            }), Object(m["jsx"])("view", {
                                class: "p",
                                no_id: "_n_21",
                                style: "width: auto;",
                                children: Object(m["jsxs"])("view", {
                                    class: "_num sk-transparent",
                                    no_id: "_n_15",
                                    style: "padding-top: 0px;",
                                    children: [ "已收集完成，共", Object(m["jsx"])("text", {
                                        class: "t-r sk-transparent sk-opacity",
                                        no_id: "_n_42",
                                        space: "true",
                                        style: "true",
                                        children: "5"
                                    }), "款" ]
                                })
                            }) ]
                        }) ]
                    }), Object(m["jsx"])("view", {
                        class: "padding20",
                        no_id: "_n_35",
                        style: "true",
                        children: Object(m["jsxs"])("view", {
                            class: "big_luck",
                            no_id: "_n_34",
                            style: "true",
                            children: [ Object(m["jsxs"])("view", {
                                class: "n_title",
                                no_id: "_n_33",
                                style: "true",
                                children: [ Object(m["jsx"])("view", {
                                    class: "text sk-transparent sk-text-14-2857-780 sk-text",
                                    no_id: "_n_27",
                                    style: "true",
                                    children: "我收集的物品 (5/5)"
                                }), Object(m["jsx"])("view", {
                                    class: "right sk-transparent sk-text-14-2857-537 sk-text",
                                    "hover-class": "none",
                                    "hover-start-time": "50",
                                    "hover-stay-time": "400",
                                    no_id: "_n_30",
                                    style: "margin-right: 10px; border: none;",
                                    children: "批量回收(240)"
                                }), Object(m["jsx"])("view", {
                                    class: "right sk-transparent sk-text-14-2857-236 sk-text",
                                    "hover-class": "none",
                                    "hover-start-time": "50",
                                    "hover-stay-time": "400",
                                    no_id: "_n_32",
                                    style: "background-color: rgb(50, 183, 254); color: rgb(255, 255, 255); border: none;",
                                    children: "批量发货"
                                }) ]
                            }), Object(m["jsxs"])("view", {
                                class: "prize mtb30",
                                no_id: "_n_1124",
                                style: "true",
                                children: [ Object(m["jsx"])("image", {
                                    class: "prize-image sk-image",
                                    no_id: "_n_1112",
                                    mode: "scaleToFill",
                                    style: "true"
                                }), Object(m["jsxs"])("view", {
                                    class: "prize-info",
                                    no_id: "_n_1123",
                                    style: "true",
                                    children: [ Object(m["jsx"])("view", {
                                        class: "ptitle t-s sk-transparent sk-text-14-2857-46 sk-text",
                                        no_id: "_n_1114",
                                        style: "true",
                                        children: "纸巾3"
                                    }), Object(m["jsxs"])("view", {
                                        class: "pbtns",
                                        no_id: "_n_1122",
                                        style: "true",
                                        children: [ Object(m["jsx"])("view", {
                                            class: "mbtn m-num sk-transparent sk-text-14-2857-713 sk-text",
                                            no_id: "_n_1117",
                                            style: "border: none;",
                                            children: "数量:55"
                                        }), Object(m["jsx"])("view", {
                                            class: "mbtn m-re sk-transparent sk-text-14-2857-218 sk-text",
                                            no_id: "_n_1119",
                                            style: "border: none;",
                                            children: "回收"
                                        }) ]
                                    }) ]
                                }) ]
                            }), Object(m["jsxs"])("view", {
                                class: "prize mtb30",
                                no_id: "_n_1137",
                                style: "true",
                                children: [ Object(m["jsx"])("image", {
                                    class: "prize-image sk-image",
                                    no_id: "_n_1125",
                                    mode: "scaleToFill",
                                    style: "true"
                                }), Object(m["jsxs"])("view", {
                                    class: "prize-info",
                                    no_id: "_n_1136",
                                    style: "true",
                                    children: [ Object(m["jsx"])("view", {
                                        class: "ptitle t-s sk-transparent sk-text-14-2857-355 sk-text",
                                        no_id: "_n_1127",
                                        style: "true",
                                        children: "纸巾5"
                                    }), Object(m["jsxs"])("view", {
                                        class: "pbtns",
                                        no_id: "_n_1135",
                                        style: "true",
                                        children: [ Object(m["jsx"])("view", {
                                            class: "mbtn m-num sk-transparent sk-text-14-2857-985 sk-text",
                                            no_id: "_n_1130",
                                            style: "border: none;",
                                            children: "数量:54"
                                        }), Object(m["jsx"])("view", {
                                            class: "mbtn m-re sk-transparent sk-text-14-2857-507 sk-text",
                                            no_id: "_n_1132",
                                            style: "border: none;",
                                            children: "回收"
                                        }) ]
                                    }) ]
                                }) ]
                            }), Object(m["jsxs"])("view", {
                                class: "prize mtb30",
                                no_id: "_n_1150",
                                style: "true",
                                children: [ Object(m["jsx"])("image", {
                                    class: "prize-image sk-image",
                                    no_id: "_n_1138",
                                    mode: "scaleToFill",
                                    style: "true"
                                }), Object(m["jsxs"])("view", {
                                    class: "prize-info",
                                    no_id: "_n_1149",
                                    style: "true",
                                    children: [ Object(m["jsx"])("view", {
                                        class: "ptitle t-s sk-transparent sk-text-14-2857-866 sk-text",
                                        no_id: "_n_1140",
                                        style: "true",
                                        children: "纸巾2"
                                    }), Object(m["jsxs"])("view", {
                                        class: "pbtns",
                                        no_id: "_n_1148",
                                        style: "true",
                                        children: [ Object(m["jsx"])("view", {
                                            class: "mbtn m-num sk-transparent sk-text-14-2857-502 sk-text",
                                            no_id: "_n_1143",
                                            style: "border: none;",
                                            children: "数量:72"
                                        }), Object(m["jsx"])("view", {
                                            class: "mbtn m-re sk-transparent sk-text-14-2857-801 sk-text",
                                            no_id: "_n_1145",
                                            style: "border: none;",
                                            children: "回收"
                                        }) ]
                                    }) ]
                                }) ]
                            }) ]
                        })
                    }) ]
                })
            });
        }, x = O, h = c(16), p = c(20), f = c(40), _ = c.n(f), w = c(14), g = (c(215), c(104), 
        c(10)), y = c(9), v = !1, N = function(e) {
            var t = e.boxId, c = e.items, s = e.show, n = e.onClose, o = e.oneItem, r = e.recoveryAfter, u = Object(l["useState"])({}), O = Object(i["a"])(u, 2), x = O[0], p = O[1], f = Object(l["useState"])({}), _ = Object(i["a"])(f, 2), N = _[0], V = _[1], k = Object(l["useState"])(0), C = Object(i["a"])(k, 2), S = C[0], T = C[1], I = Object(l["useState"])(!1), z = Object(i["a"])(I, 2), M = z[0], F = z[1], q = Object(l["useState"])(!0), L = Object(i["a"])(q, 2), P = L[0], A = L[1], E = Object(l["useState"])(!1), R = Object(i["a"])(E, 2), B = R[0], D = R[1];
            Object(l["useEffect"])(function() {
                Object(d["f"])(p);
            }, []), Object(l["useEffect"])(function() {
                for (var e in c) {
                    var t = c[e];
                    t.recovery_price > 0 && t.has_num > 0 && A(!1);
                }
            }, [ c ]), Object(l["useEffect"])(function() {
                F(s);
            }, [ s ]);
            var J = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                if (v) return !1;
                if (v = !0, !e) {
                    if (0 == Object.keys(N).length) return v = !1, j.a.showToast({
                        title: "请选择要回收的数量",
                        icon: "none"
                    });
                    var t = !0;
                    for (var c in N) {
                        var s = N[c];
                        if (s > 0) {
                            t = !1;
                            break;
                        }
                    }
                    if (t) return v = !1, j.a.showToast({
                        title: "请选择要回收的数量",
                        icon: "none"
                    });
                }
                j.a.showModal({
                    title: "一经变卖无法撤回",
                    content: e ? "回收金额将进入您的余额，不会退回支付账户，请谨慎操作！" : "变卖可得".concat(Object(d["i"])(S), "元，回收金额将进入您的余额，不会退回支付账户，请谨慎操作！"),
                    complete: function(t) {
                        t.confirm ? U(e) : (v = !1, j.a.showToast({
                            title: "回收取消",
                            icon: "none"
                        }));
                    }
                });
            }, U = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                D(!0), Object(d["d"])({
                    url: "entry/wxapp/RecoveryDo",
                    data: e ? {
                        box_id: t,
                        all: 1
                    } : {
                        ids: JSON.parse(JSON.stringify(N)),
                        box_id: t
                    },
                    success: function(e) {
                        setTimeout(function() {
                            r && r(), j.a.showModal({
                                title: "回收成功",
                                content: "可以在消费账单中查看详情",
                                showCancel: !1,
                                complete: function() {
                                    v = !1, T(0), V({}), D(!1), H();
                                }
                            });
                        }, 3e3);
                    },
                    fail: function(e) {
                        var t = e.data;
                        j.a.showModal({
                            title: "提示",
                            content: t.message,
                            showCancel: !1,
                            complete: function() {
                                setTimeout(function() {
                                    v = !1, D(!1);
                                }, 3e3);
                            }
                        });
                    }
                });
            }, G = function(e, t) {
                return 0 == e.has_num || e.recovery_price < 1 ? null : Object(m["jsxs"])(b["View"], {
                    className: "recovery-item",
                    children: [ Object(m["jsx"])(b["Image"], {
                        src: "".concat(x.attachurl).concat(e.image),
                        mode: "aspectFit",
                        className: "item-image"
                    }), Object(m["jsxs"])(b["View"], {
                        className: "recovery-info",
                        children: [ Object(m["jsx"])(b["View"], {
                            className: "title",
                            children: e.name
                        }), Object(m["jsxs"])(b["View"], {
                            className: "recovery-price",
                            children: [ "可回收数:", e.has_num ]
                        }), Object(m["jsxs"])(b["View"], {
                            className: "recovery-price",
                            children: [ "回收价:", Object(m["jsxs"])(b["Text"], {
                                className: "p-price",
                                children: [ "￥", Object(d["i"])(e.recovery_price) ]
                            }) ]
                        }) ]
                    }), Object(m["jsxs"])(b["View"], {
                        className: "recovery-num",
                        children: [ Object(m["jsx"])(b["View"], {
                            className: "left",
                            onClick: function() {
                                return Q(e.id, -1, t);
                            },
                            children: "-"
                        }), Object(m["jsx"])(b["Input"], {
                            className: "input",
                            disabled: !0,
                            value: N[e.id] ? N[e.id] : 0
                        }), Object(m["jsx"])(b["View"], {
                            className: "right",
                            onClick: function() {
                                return Q(e.id, 1, t);
                            },
                            children: "+"
                        }) ]
                    }) ]
                }, t);
            }, Q = function(e, t, s) {
                var n = Object(a["a"])({}, N);
                return n[e] = n[e] ? n[e] + t : t, !(c[s].has_num < n[e]) && (!(n[e] < 0) && (T(S + t * c[s].recovery_price), 
                void V(n)));
            }, H = function() {
                F(!1), T(0), V({}), D(!1), n();
            };
            return Object(m["jsx"])(b["View"], {
                className: "recovery-com",
                children: M ? Object(m["jsx"])(h["a"], {
                    title: "回收",
                    onClose: H,
                    children: B ? Object(m["jsx"])(y["a"], {
                        iconStyle: {
                            color: "rgba(0,0,0,0.4)"
                        },
                        title: "回收中..."
                    }) : P ? Object(m["jsx"])(g["a"], {
                        title: "无可回收物品"
                    }) : Object(m["jsxs"])(b["View"], {
                        children: [ Object(m["jsx"])(b["View"], {
                            className: "items",
                            children: c.map(G)
                        }), Object(m["jsxs"])(b["View"], {
                            className: "recovery-btn",
                            children: [ Object(m["jsxs"])(b["View"], {
                                className: "recovery-p",
                                children: [ "回收所得金额 ", Object(m["jsxs"])(b["Text"], {
                                    className: "price",
                                    children: [ "￥", Object(d["i"])(S) ]
                                }) ]
                            }), Object(m["jsx"])(w["a"], {
                                className: "nocss-button button-p",
                                type: "primary",
                                onClick: function() {
                                    return J();
                                },
                                children: "确认回收"
                            }), o ? null : Object(m["jsx"])(w["a"], {
                                className: "nocss-button button-g",
                                type: "",
                                style: {
                                    marginTop: "10px"
                                },
                                onClick: function() {
                                    return J(!0);
                                },
                                children: "一键全部回收"
                            }) ]
                        }) ]
                    })
                }) : null
            });
        }, V = N, k = c(77), C = (c(216), function(e) {
            var t = e.boxId, c = e.type, s = void 0 === c ? 1 : c, n = e.itemId, a = void 0 === n ? 0 : n, o = e.onClose, r = Object(l["useState"])(!1), u = Object(i["a"])(r, 2), O = u[0], x = u[1], p = Object(l["useState"])(!0), f = Object(i["a"])(p, 2), _ = f[0], w = f[1], g = Object(l["useState"])({}), v = Object(i["a"])(g, 2), N = v[0], V = v[1], C = Object(l["useState"])(""), S = Object(i["a"])(C, 2), T = S[0], I = S[1];
            Object(l["useEffect"])(function() {
                z();
            }, []);
            var z = function() {
                Object(d["d"])({
                    url: "entry/wxapp/getVerData",
                    data: {
                        box_id: t,
                        type: s,
                        item_id: a
                    },
                    success: function(e) {
                        var t = e.status, c = e.data, s = e.msg;
                        0 == t ? (V(c), 1 == c.ver_type ? setTimeout(function() {
                            x(!0);
                        }, 1e3) : w(!1)) : j.a.showModal({
                            title: "提示",
                            content: s,
                            showCancel: !1,
                            complete: function() {
                                o();
                            }
                        });
                    }
                });
            }, M = function() {
                if (!T) return j.a.showToast({
                    title: "请输入核销码",
                    icon: "none"
                });
                Object(d["d"])({
                    url: "entry/wxapp/VerCode",
                    data: {
                        box_id: t,
                        type: s,
                        item_id: a,
                        ver_code: T
                    },
                    success: function(e) {
                        var t = e.status, c = e.msg;
                        0 == t ? j.a.showModal({
                            title: "核销成功",
                            content: "该物品已被成功核销",
                            showCancel: !1,
                            complete: function() {
                                o(!0);
                            }
                        }) : j.a.showModal({
                            title: "提示",
                            content: c,
                            showCancel: !1
                        });
                    }
                });
            };
            return Object(m["jsxs"])(b["View"], {
                className: "v-com",
                children: [ Object(m["jsx"])(h["a"], {
                    title: "核销物品",
                    onClose: o,
                    children: _ ? Object(m["jsx"])(y["a"], {
                        iconStyle: {
                            color: "rgba(0,0,0,0.4)"
                        },
                        title: "加载中..."
                    }) : Object(m["jsxs"])(b["View"], {
                        className: "q-content",
                        children: [ Object(m["jsx"])(b["View"], {
                            className: "q-title",
                            children: N.name
                        }), N.code && 2 == N.ver_type ? Object(m["jsx"])(k["QRCode"], {
                            text: N.code,
                            size: 200,
                            scale: 4,
                            errorCorrectLevel: "M",
                            typeNumber: 2
                        }) : null, Object(m["jsx"])(b["Button"], {
                            className: "nocss-button du_btn",
                            style: {
                                width: "100%",
                                marginTop: 30
                            },
                            onClick: function() {
                                return x(!0);
                            },
                            children: "核销码核销"
                        }) ]
                    })
                }), O ? Object(m["jsx"])(h["a"], {
                    title: "核销码核销",
                    onClose: function() {
                        1 == N.ver_type && o(), x(!1);
                    },
                    children: Object(m["jsxs"])(b["View"], {
                        className: "q-content",
                        style: {
                            height: 300
                        },
                        children: [ Object(m["jsx"])(b["View"], {
                            className: "q-title",
                            children: N.name
                        }), Object(m["jsx"])(b["View"], {
                            className: "q-title",
                            children: "请商家输入核销码"
                        }), Object(m["jsx"])(b["View"], {
                            className: "q-input",
                            children: Object(m["jsx"])(b["Input"], {
                                placeholder: "请输入核销密码",
                                type: "password",
                                onInput: function(e) {
                                    return I(e.detail.value);
                                }
                            })
                        }), Object(m["jsx"])(b["Button"], {
                            className: "nocss-button du_btn",
                            style: {
                                width: "90%",
                                marginTop: 30
                            },
                            onClick: M,
                            children: "核销码核销"
                        }) ]
                    })
                }) : null ]
            });
        }), S = o.a.memo(C), T = (c(217), function(e) {
            var t = e.boxId, c = e.type, s = void 0 === c ? 1 : c, n = e.itemId, a = void 0 === n ? 0 : n, o = e.onClose, r = void 0 === o ? function() {} : o, u = Object(l["useState"])(!0), O = Object(i["a"])(u, 2), x = O[0], p = O[1], f = Object(l["useState"])({}), _ = Object(i["a"])(f, 2), w = _[0], g = _[1];
            Object(l["useEffect"])(function() {
                V();
            }, []);
            var v = function() {
                j.a.downloadFile({
                    url: w.image,
                    success: function(e) {
                        200 === e.statusCode && j.a.saveImageToPhotosAlbum({
                            filePath: e.tempFilePath,
                            success: function() {
                                j.a.showToast({
                                    title: "保存成功",
                                    icon: "none"
                                });
                            },
                            fail: function() {
                                j.a.showModal({
                                    title: "提示",
                                    content: "保存失败",
                                    showCancel: !1
                                });
                            }
                        });
                    }
                });
            }, N = function() {
                j.a.setClipboardData({
                    data: w.code,
                    success: function() {
                        j.a.showToast({
                            title: "复制成功",
                            icon: "none"
                        });
                    },
                    fail: function() {
                        j.a.showModal({
                            title: "提示",
                            content: "复制失败",
                            showCancel: !1
                        });
                    }
                });
            }, V = function() {
                Object(d["d"])({
                    url: "entry/wxapp/GetFictitiousItem",
                    data: {
                        box_id: t,
                        type: s,
                        item_id: a
                    },
                    success: function(e) {
                        var t = e.status, c = e.data, s = e.msg;
                        p(!1), 0 == t ? (g(c), -1 == c.type && j.a.showModal({
                            title: "提示",
                            content: c.msg,
                            showCancel: !1,
                            complete: function() {
                                r();
                            }
                        })) : j.a.showModal({
                            title: "提示",
                            content: s,
                            showCancel: !1,
                            complete: function() {
                                r();
                            }
                        });
                    }
                });
            }, k = function() {
                return Object(m["jsxs"])(b["View"], {
                    className: "add-f",
                    children: [ Object(m["jsx"])(b["View"], {
                        children: "添加好友后领取"
                    }), Object(m["jsx"])(b["Image"], {
                        className: "qrcode",
                        src: w.image,
                        mode: "widthFix"
                    }), Object(m["jsx"])(b["Button"], {
                        className: "nocss-button du_btn",
                        style: {
                            width: "80%"
                        },
                        onClick: v,
                        children: "保存二维码到相册"
                    }) ]
                });
            }, C = function() {
                return Object(m["jsxs"])(b["View"], {
                    className: "add-f",
                    children: [ Object(m["jsx"])(b["View"], {
                        children: "兑换码"
                    }), Object(m["jsx"])(b["View"], {
                        className: "code",
                        children: Object(m["jsx"])(b["Text"], {
                            children: w.code
                        })
                    }), Object(m["jsx"])(b["Button"], {
                        className: "nocss-button du_btn",
                        style: {
                            width: "80%"
                        },
                        onClick: N,
                        children: "复制兑换码"
                    }), Object(m["jsx"])(b["View"], {
                        className: "desc",
                        style: {
                            marginTop: 10
                        },
                        children: "使用方法请查看活动说明"
                    }) ]
                });
            };
            return Object(m["jsx"])(b["View"], {
                className: "get-com",
                children: Object(m["jsx"])(h["a"], {
                    title: "领取物品",
                    onClose: r,
                    children: x ? Object(m["jsx"])(y["a"], {
                        iconStyle: {
                            color: "rgba(0,0,0,0.4)"
                        },
                        title: "加载中..."
                    }) : Object(m["jsxs"])(m["Fragment"], {
                        children: [ 2 == w.type ? k() : null, 1 == w.type || 3 == w.type ? C() : null ]
                    })
                })
            });
        }), I = o.a.memo(T), z = (c(218), function(e) {
            var t = e.item, c = e.setShareToken, s = void 0 === c ? function() {} : c, n = e.onClose, a = void 0 === n ? function() {} : n, o = Object(l["useState"])(!0), r = Object(i["a"])(o, 2), j = r[0], u = r[1], O = Object(l["useState"])({}), x = Object(i["a"])(O, 2), p = (x[0], 
            x[1]);
            Object(l["useEffect"])(function() {
                f();
            }, []);
            var f = function() {
                Object(d["d"])({
                    url: "entry/wxapp/GiveToFriends",
                    data: {
                        item_id: t.id
                    },
                    success: function(e) {
                        u(!1), p(e), s(e);
                    }
                });
            }, _ = function() {
                return Object(m["jsxs"])(b["View"], {
                    className: "add-f",
                    children: [ Object(m["jsx"])(b["View"], {
                        children: "提示"
                    }), Object(m["jsx"])(b["View"], {
                        className: "code",
                        style: {
                            height: 100
                        },
                        children: "送出后无法撤回，好友领取后可发货可兑换。"
                    }), Object(m["jsx"])(b["Button"], {
                        className: "nocss-button du_btn",
                        style: {
                            width: "80%"
                        },
                        openType: "share",
                        children: "点击送给你好友"
                    }), Object(m["jsx"])(b["View"], {
                        className: "desc",
                        style: {
                            marginTop: 10
                        },
                        children: "具体详情请查看活动说明"
                    }) ]
                });
            };
            return Object(m["jsx"])(b["View"], {
                className: "get-com",
                children: Object(m["jsx"])(h["a"], {
                    title: "送给好友",
                    onClose: a,
                    children: j ? Object(m["jsx"])(y["a"], {
                        iconStyle: {
                            color: "rgba(0,0,0,0.4)"
                        },
                        title: "加载中..."
                    }) : Object(m["jsx"])(m["Fragment"], {
                        children: _()
                    })
                })
            });
        }), M = o.a.memo(z), F = null, q = function() {
            var e, t, c = Object(r["useRouter"])(), s = Object(l["useState"])({}), o = Object(i["a"])(s, 2), O = o[0], f = o[1], g = Object(l["useState"])({}), y = Object(i["a"])(g, 2), v = y[0], N = y[1], k = Object(l["useState"])(!1), C = Object(i["a"])(k, 2), T = C[0], z = C[1], q = Object(l["useState"])(0), L = Object(i["a"])(q, 2), P = (L[0], 
            L[1]), A = Object(l["useState"])(!1), E = Object(i["a"])(A, 2), R = E[0], B = E[1], D = Object(l["useState"])(1), J = Object(i["a"])(D, 2), U = J[0], G = J[1], Q = Object(l["useState"])(0), H = Object(i["a"])(Q, 2), K = H[0], W = H[1], X = Object(l["useState"])([]), Y = Object(i["a"])(X, 2), Z = Y[0], $ = Y[1], ee = Object(l["useState"])(!1), te = Object(i["a"])(ee, 2), ce = te[0], se = te[1], ne = Object(l["useState"])(!0), ae = Object(i["a"])(ne, 2), ie = ae[0], le = ae[1], oe = Object(l["useState"])(!1), re = Object(i["a"])(oe, 2), je = re[0], be = re[1], de = Object(l["useState"])(-1), ue = Object(i["a"])(de, 2), me = ue[0], Oe = ue[1], xe = Object(l["useState"])(-1), he = Object(i["a"])(xe, 2), pe = he[0], fe = he[1], _e = Object(l["useState"])(0), we = Object(i["a"])(_e, 2), ge = we[0], ye = we[1], ve = Object(l["useState"])(0), Ne = Object(i["a"])(ve, 2), Ve = Ne[0], ke = Ne[1], Ce = Object(l["useState"])(0), Se = Object(i["a"])(Ce, 2), Te = Se[0], Ie = Se[1], ze = Object(l["useState"])(!1), Me = Object(i["a"])(ze, 2), Fe = Me[0], qe = Me[1], Le = Object(l["useState"])(""), Pe = Object(i["a"])(Le, 2), Ae = Pe[0], Ee = Pe[1], Re = Object(l["useState"])(0), Be = Object(i["a"])(Re, 2), De = Be[0], Je = Be[1], Ue = Object(l["useState"])(!1), Ge = Object(i["a"])(Ue, 2), Qe = Ge[0], He = Ge[1], Ke = Object(l["useState"])(""), We = Object(i["a"])(Ke, 2), Xe = We[0], Ye = We[1], Ze = Object(l["useState"])(""), $e = Object(i["a"])(Ze, 2), et = $e[0], tt = $e[1], ct = Object(l["useState"])(""), st = Object(i["a"])(ct, 2), nt = st[0], at = st[1], it = Object(l["useState"])(1), lt = Object(i["a"])(it, 2), ot = lt[0], rt = lt[1], jt = Object(l["useState"])(!1), bt = Object(i["a"])(jt, 2), dt = bt[0], ut = bt[1], mt = Object(l["useState"])(!1), Ot = Object(i["a"])(mt, 2), xt = Ot[0], ht = Ot[1], pt = Object(l["useState"])(!1), ft = Object(i["a"])(pt, 2), _t = ft[0], wt = ft[1], gt = Object(l["useState"])(!1), yt = Object(i["a"])(gt, 2), vt = yt[0], Nt = yt[1], Vt = Object(l["useState"])(!1), kt = Object(i["a"])(Vt, 2), Ct = kt[0], St = kt[1];
            Object(r["useShareAppMessage"])(function() {
                var e = j.a.getStorageSync("userInfo"), t = e.uid;
                return Ct ? (console.log("/pages/give/index?fuid=".concat(t, "&st=").concat(Ct.token)), 
                {
                    title: "".concat(Ct.nickname, "送您").concat(Ct.item, ",点击领取"),
                    path: "/pages/give/index?fuid=".concat(t, "&st=").concat(Ct.token),
                    imageUrl: "".concat(O.attachurl).concat(O.share_image)
                }) : {
                    title: O.share_title,
                    path: t ? "/pages/index/index?fuid=".concat(t) : "/pages/index/index",
                    imageUrl: "".concat(O.attachurl).concat(O.share_image)
                };
            });
            var Tt = function() {
                var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], t = e ? ot + 1 : ot - 1;
                return !(t < 1) && (!(t > ce.has_num) && void rt(t));
            }, It = function() {
                j.a.chooseAddress().then(function(e) {
                    var t = e.errMsg, c = e.cityName, s = e.countyName, n = e.detailInfo, a = e.provinceName, i = e.telNumber, l = e.userName;
                    "chooseAddress:ok" == t && (Ye("".concat(a).concat(c).concat(s).concat(n)), tt(l), 
                    at(i));
                }).catch(function() {});
            }, zt = function() {
                if (!Xe) return j.a.showModal({
                    title: "提示",
                    content: "请选择您的收货地址",
                    showCancel: !1,
                    complete: function() {
                        It();
                    }
                });
                j.a.showLoading({
                    title: "创建订单中..."
                }), Object(d["d"])({
                    url: "entry/wxapp/DeliveryPrize",
                    data: {
                        address: Xe,
                        tel: nt,
                        name: et,
                        num: ot,
                        box_id: c.params.id
                    },
                    success: function(e) {
                        var t = e.order_no;
                        j.a.hideLoading();
                        var c = [];
                        O.submsg_1 && c.push(O.submsg_1), Object(d["g"])(c, function() {
                            e.need_pay ? j.a.requestPayment(Object(a["a"])({}, e.pay_config)).then(function(e) {
                                Mt(t);
                            }).catch(function(e) {
                                var t = e.errMsg;
                                "requestPayment:fail cancel" == t ? j.a.showToast({
                                    title: "取消支付",
                                    icon: "none"
                                }) : j.a.showToast({
                                    title: "支付失败",
                                    icon: "none"
                                });
                            }) : (ut(!0), Wt());
                        });
                    }
                });
            }, Mt = function(e) {
                j.a.showLoading({
                    title: "确认支付..."
                }), F = setInterval(function() {
                    Ft(e);
                }, 3e3);
            }, Ft = function(e) {
                Object(d["d"])({
                    url: "entry/wxapp/DeliveryPayStatus",
                    data: {
                        order_no: e
                    },
                    success: function(e) {
                        var t = e.pay_status;
                        1 == t && (clearInterval(F), j.a.hideLoading(), ut(!0), Wt());
                    },
                    fail: function() {
                        clearInterval(F);
                    }
                });
            }, qt = function() {
                Object(d["d"])({
                    url: "entry/wxapp/deliveryInfo",
                    success: function(e) {
                        ye(e.balance_price), Je(e.wx_pay_price), He(e.all_balance), ke(e.delivery_price), 
                        Ie(e.balance_price_pay), qe(!0);
                    }
                });
            }, Lt = function() {
                j.a.navigateTo({
                    url: "/pages/box/deliver/index"
                });
            };
            Object(r["useDidShow"])(function() {
                Wt();
            }, []);
            var Pt = Object(l["useState"])(!1), At = Object(i["a"])(Pt, 2), Et = At[0], Rt = At[1], Bt = Object(l["useState"])(!1), Dt = Object(i["a"])(Bt, 2), Jt = Dt[0], Ut = Dt[1], Gt = Object(l["useState"])(!1), Qt = Object(i["a"])(Gt, 2), Ht = Qt[0], Kt = Qt[1], Wt = function() {
                Object(d["d"])({
                    url: "entry/wxapp/UserBoxDetails",
                    data: {
                        box_id: c.params.id
                    },
                    success: function(e) {
                        var t = e.box, c = e.code_list, s = e.item_list, n = e.prize_data;
                        N(t), $(s), se(n), c && (z(c.list), P(c.total), G(c.total_page), W(c.current_page)), 
                        setTimeout(function() {
                            s.map(function(e) {
                                1 == e.type && !Et && Rt(!0), 2 == e.type && !Jt && Ut(!0), 3 == e.type && !Ht && Kt(!0);
                            }), le(!1);
                        }, 600);
                    }
                });
            }, Xt = function() {
                if (K >= U) return !1;
                B(!0), Object(d["d"])({
                    url: "entry/wxapp/UserLuckCodeList",
                    data: {
                        box_id: c.params.id,
                        page: parseInt(K) + 1
                    },
                    success: function(e) {
                        var t = e.list, c = e.total, s = e.total_page, n = e.current_page;
                        z(T.concat(t)), P(c), G(s), W(n), setTimeout(function() {
                            B(!1);
                        }, 600);
                    }
                });
            };
            Object(l["useEffect"])(function() {
                Object(d["f"])(f), Wt();
            }, []);
            var Yt = function() {
                j.a.navigateTo({
                    url: "/pages/detail/index?id=".concat(c.params.id)
                });
            }, Zt = function() {
                j.a.showLoading({
                    title: "兑换中..."
                }), Object(d["d"])({
                    url: "entry/wxapp/CardExchange",
                    data: {
                        box_id: c.params.id
                    },
                    success: function(e) {
                        var t = e.status, c = e.msg;
                        j.a.hideLoading(), 0 == t ? (j.a.showToast({
                            title: "兑换成功",
                            icon: "none"
                        }), Wt()) : j.a.showModal({
                            title: "提示",
                            content: c,
                            showCancel: !1
                        });
                    }
                });
            };
            return Object(m["jsxs"])(b["View"], {
                children: [ ie ? Object(m["jsx"])(x, {}) : Object(m["jsxs"])(b["View"], {
                    className: "box-details-page",
                    children: [ Object(m["jsx"])(b["View"], {
                        style: {
                            height: "1px"
                        }
                    }), Object(m["jsx"])(u["a"], {
                        config: O,
                        item: v,
                        onItemClick: Yt
                    }), Object(m["jsxs"])(b["View"], {
                        className: "padding20",
                        children: [ ce ? Object(m["jsxs"])(b["View"], {
                            className: "big_luck luck",
                            children: [ Object(m["jsxs"])(b["View"], {
                                className: "n_title",
                                children: [ Object(m["jsx"])(b["View"], {
                                    className: "text",
                                    children: 3 == v.type ? "集齐卡片即可兑换" : "幸运盒子奖品"
                                }), Object(m["jsx"])(b["View"], {
                                    className: "right",
                                    style: {
                                        marginRight: 10
                                    },
                                    onClick: function() {
                                        0 == ce.type && j.a.navigateTo({
                                            url: "/pages/my/delivery/index"
                                        }), 1 == ce.type && j.a.navigateTo({
                                            url: "/pages/my/logs/index?tab=".concat(v.type - 1, "&box_id=").concat(v.box_id)
                                        }), 2 == ce.type && j.a.navigateTo({
                                            url: "/pages/my/helogs/index?tab=".concat(v.type - 1, "&box_id=").concat(v.box_id)
                                        });
                                    },
                                    children: {
                                        0: "发货记录",
                                        1: "领取记录",
                                        2: "核销记录"
                                    }[ce.type]
                                }), Object(m["jsxs"])(b["View"], {
                                    className: "right",
                                    onClick: Yt,
                                    children: [ "去收集", Object(m["jsx"])(b["Text"], {
                                        className: "iconfont icon-weimingmingwenjianjia_jiantou"
                                    }) ]
                                }) ]
                            }), Object(m["jsxs"])(b["View"], {
                                className: "prize ",
                                children: [ Object(m["jsx"])(b["Image"], {
                                    className: "prize-image",
                                    src: "".concat(O.attachurl).concat(ce.image)
                                }), Object(m["jsxs"])(b["View"], {
                                    className: "prize-info",
                                    children: [ Object(m["jsx"])(b["View"], {
                                        className: "ptitle t-s",
                                        children: ce.name
                                    }), Object(m["jsxs"])(b["View"], {
                                        className: "pbtns",
                                        children: [ Object(m["jsxs"])(b["View"], {
                                            className: "mbtn m-num",
                                            children: [ "数量:", ce.has_num ]
                                        }), ce.has_num > 0 ? Object(m["jsxs"])(m["Fragment"], {
                                            children: [ 0 == ce.type ? Object(m["jsx"])(b["View"], {
                                                className: "mbtn m-dev",
                                                onClick: function() {
                                                    qt();
                                                },
                                                children: "发货"
                                            }) : null, 1 == ce.type ? Object(m["jsx"])(b["View"], {
                                                className: "mbtn m-dev",
                                                onClick: function() {
                                                    wt({
                                                        type: v.type
                                                    });
                                                },
                                                children: "领取"
                                            }) : null, 2 == ce.type ? Object(m["jsx"])(b["View"], {
                                                className: "mbtn m-dev",
                                                onClick: function() {
                                                    ht({
                                                        type: v.type
                                                    });
                                                },
                                                children: "核销"
                                            }) : null ]
                                        }) : Object(m["jsx"])(b["View"], {
                                            className: "mbtn",
                                            onClick: Yt,
                                            children: "去收集"
                                        }) ]
                                    }) ]
                                }) ]
                            }) ]
                        }) : null, Object(m["jsxs"])(b["View"], {
                            className: "big_luck",
                            children: [ Object(m["jsxs"])(b["View"], {
                                className: "n_title",
                                children: [ Object(m["jsxs"])(b["View"], {
                                    className: "text",
                                    children: [ 3 == v.type ? "卡片" : "物品", " (", v.item_has_count, "/", v.item_count, ")" ]
                                }), 3 == v.type ? Object(m["jsx"])(m["Fragment"], {
                                    children: Object(m["jsx"])(b["View"], {
                                        className: "right",
                                        onClick: function() {
                                            j.a.showModal({
                                                title: "确认兑换",
                                                content: "将消耗一套卡片进行兑换",
                                                complete: function(e) {
                                                    var t = e.confirm;
                                                    t && Zt();
                                                }
                                            });
                                        },
                                        style: {
                                            backgroundColor: "#01cbcd",
                                            color: "#ffffff"
                                        },
                                        children: "兑换奖品"
                                    })
                                }) : Object(m["jsxs"])(m["Fragment"], {
                                    children: [ Jt ? Object(m["jsx"])(b["View"], (e = {
                                        className: "right",
                                        onClick: function() {
                                            j.a.navigateTo({
                                                url: "/pages/my/helogs/index?box_id=".concat(v.box_id)
                                            });
                                        },
                                        style: {
                                            backgroundColor: "#01cbcd",
                                            color: "#ffffff"
                                        }
                                    }, Object(n["a"])(e, "style", {
                                        marginRight: "10px"
                                    }), Object(n["a"])(e, "children", "核销记录"), e)) : null, Et ? Object(m["jsx"])(b["View"], (t = {
                                        className: "right",
                                        onClick: function() {
                                            j.a.navigateTo({
                                                url: "/pages/my/logs/index?box_id=".concat(v.box_id)
                                            });
                                        },
                                        style: {
                                            backgroundColor: "#01cbcd",
                                            color: "#ffffff"
                                        }
                                    }, Object(n["a"])(t, "style", {
                                        marginRight: "10px"
                                    }), Object(n["a"])(t, "children", "领取记录"), t)) : null, Jt || Ht ? null : Object(m["jsx"])(b["View"], {
                                        className: "right",
                                        onClick: function() {
                                            be(!0);
                                        },
                                        style: {
                                            marginRight: "10px"
                                        },
                                        children: "批量回收"
                                    }), Object(m["jsx"])(b["View"], {
                                        className: "right",
                                        onClick: Lt,
                                        style: {
                                            backgroundColor: "#01cbcd",
                                            color: "#ffffff"
                                        },
                                        children: "批量发货"
                                    }) ]
                                }) ]
                            }), Object(m["jsx"])(b["View"], {
                                className: "i-row",
                                children: Z.map(function(e, t) {
                                    return Object(m["jsxs"])(b["View"], {
                                        className: "row_prize ",
                                        children: [ Object(m["jsxs"])(b["View"], {
                                            className: "prize-image",
                                            children: [ Object(m["jsx"])(b["Image"], {
                                                className: "prize-_image",
                                                mode: "heightFix",
                                                src: "".concat(O.attachurl).concat(e.image)
                                            }), Object(m["jsxs"])(b["View"], {
                                                className: "ckqx",
                                                children: [ "数量:", e.has_num ]
                                            }) ]
                                        }), Object(m["jsxs"])(b["View"], {
                                            className: "prize-info",
                                            children: [ Object(m["jsx"])(b["View"], {
                                                className: "ptitle t-s",
                                                children: e.name
                                            }), Object(m["jsxs"])(b["View"], {
                                                className: "pbtns",
                                                children: [ 0 == e.has_num ? Object(m["jsx"])(b["View"], {
                                                    className: "mbtn m-go",
                                                    onClick: Yt,
                                                    children: "去收集"
                                                }) : null, e.has_num > 0 && e.recovery_price > 0 ? Object(m["jsx"])(b["View"], {
                                                    className: "mbtn m-re",
                                                    onClick: function() {
                                                        be(!0), Oe(t);
                                                    },
                                                    children: "回收"
                                                }) : null, e.has_num > 0 && 1 == e.type ? Object(m["jsx"])(b["View"], {
                                                    className: "mbtn m-re",
                                                    style: {
                                                        backgroundColor: "#000",
                                                        color: "#fff"
                                                    },
                                                    onClick: function() {
                                                        wt({
                                                            type: 1,
                                                            itemId: e.id
                                                        });
                                                    },
                                                    children: "领取"
                                                }) : null, e.has_num > 0 && 2 == e.type ? Object(m["jsx"])(b["View"], {
                                                    className: "mbtn m-re",
                                                    style: {
                                                        backgroundColor: "#000",
                                                        color: "#fff"
                                                    },
                                                    onClick: function() {
                                                        ht({
                                                            type: 1,
                                                            itemId: e.id
                                                        });
                                                    },
                                                    children: "核销"
                                                }) : null, e.has_num > 0 && 2 != e.type && 1 != e.type ? Object(m["jsx"])(b["View"], {
                                                    className: "mbtn m-re",
                                                    style: {
                                                        backgroundColor: "#000",
                                                        color: "#fff"
                                                    },
                                                    onClick: function() {
                                                        j.a.showModal({
                                                            title: "确认送给好友",
                                                            content: "送给好友您好友将获得此卡片或物品。您的卡片或者物品就会被消耗！",
                                                            showCancel: !1,
                                                            complete: function() {
                                                                Nt(e);
                                                            }
                                                        });
                                                    },
                                                    children: "送好友"
                                                }) : null ]
                                            }) ]
                                        }) ]
                                    }, t);
                                })
                            }) ]
                        }), T ? Object(m["jsxs"])(b["View"], {
                            className: "big_luck luck_code",
                            children: [ Object(m["jsxs"])(b["View"], {
                                className: "n_title",
                                children: [ Object(m["jsx"])(b["View"], {
                                    className: "text",
                                    children: "我的抽奖码"
                                }), Object(m["jsxs"])(b["View"], {
                                    className: "right",
                                    onClick: Yt,
                                    children: [ "获得更多抽奖码", Object(m["jsx"])(b["Text"], {
                                        className: "iconfont icon-weimingmingwenjianjia_jiantou"
                                    }) ]
                                }) ]
                            }), T.map(function(e, t) {
                                return Object(m["jsxs"])(b["View"], {
                                    className: "prize-code-v mtb30",
                                    children: [ Object(m["jsxs"])(b["View"], {
                                        className: "prize-code  h-a",
                                        children: [ Object(m["jsxs"])(b["View"], {
                                            className: "prize-image",
                                            onClick: function() {
                                                j.a.navigateTo({
                                                    url: "/pages/detail/results/index?box_id=".concat(e.box_id, "&batch_no=").concat(e.batch_no)
                                                });
                                            },
                                            children: [ Object(m["jsx"])(b["Image"], {
                                                className: "prize-_image",
                                                src: "".concat(O.attachurl).concat(ce.image)
                                            }), Object(m["jsx"])(b["View"], {
                                                className: "ckqx",
                                                children: "查看详情"
                                            }) ]
                                        }), Object(m["jsxs"])(b["View"], {
                                            className: "prize-info w-a",
                                            children: [ Object(m["jsxs"])(b["View"], {
                                                className: "qi_prize ",
                                                children: [ Object(m["jsxs"])(b["Text"], {
                                                    className: "qi",
                                                    children: [ "第", e.batch_no, "期" ]
                                                }), Object(m["jsx"])(b["View"], {
                                                    className: "t-s",
                                                    children: ce.name
                                                }) ]
                                            }), Object(m["jsxs"])(b["View"], {
                                                className: "t-s t-ss",
                                                children: [ "中奖号码:", Object(m["jsx"])(b["Text"], {
                                                    className: "t-r",
                                                    children: e.prize_code ? e.prize_code : "开奖进行中"
                                                }) ]
                                            }), e.prize_code ? Object(m["jsxs"])(b["View"], {
                                                className: "t-s t-ss",
                                                children: [ "开奖时间:", e.open_time ]
                                            }) : null, Object(m["jsxs"])(b["View"], {
                                                className: "t-s t-ss",
                                                onClick: function() {
                                                    return fe(pe == t ? "-1" : t);
                                                },
                                                children: [ "本期获得的中奖码", " ", Object(m["jsx"])(b["Text"], {
                                                    className: "iconfont icon-arrowRight-copy ".concat(pe == t ? "rotate180" : "none")
                                                }) ]
                                            }) ]
                                        }) ]
                                    }), Object(m["jsx"])(b["View"], {
                                        className: "prize-codes",
                                        style: {
                                            height: pe == t ? "auto" : "0px",
                                            display: pe == t ? "flex" : "none"
                                        },
                                        children: e.codes.map(function(e, t) {
                                            return Object(m["jsx"])(b["View"], {
                                                className: "code-v",
                                                children: e
                                            }, "".concat(t, "-").concat(e));
                                        })
                                    }) ]
                                }, t);
                            }), !R && K < U ? Object(m["jsx"])(b["View"], {
                                className: "more_code",
                                onClick: Xt,
                                children: "加载更多抽奖码"
                            }) : null, R ? Object(m["jsx"])(b["View"], {
                                className: "more_code",
                                children: "加载中..."
                            }) : null ]
                        }) : null ]
                    }) ]
                }), Object(m["jsx"])(V, {
                    items: -1 != me ? [ Z[me] ] : Z,
                    boxId: c.params.id,
                    oneItem: -1 != me,
                    show: je,
                    recoveryAfter: function() {
                        Wt();
                    },
                    onClose: function() {
                        Oe(-1), be(!1);
                    }
                }), Fe ? Object(m["jsx"])(h["a"], {
                    title: dt ? "发货成功" : "发货订单",
                    onClose: function() {
                        qe(!1), ut(!1);
                    },
                    show: Fe,
                    children: dt ? Object(m["jsxs"])(b["View"], {
                        className: "pay_success",
                        children: [ Object(m["jsx"])(b["View"], {
                            children: Object(m["jsx"])(b["Text"], {
                                className: "iconfont icon-fahuo"
                            })
                        }), Object(m["jsx"])(b["View"], {
                            className: "title",
                            children: "发货成功"
                        }), Object(m["jsx"])(b["View"], {
                            className: "desc",
                            children: "系统将在48小时内给您安排发货"
                        }) ]
                    }) : Object(m["jsxs"])(b["View"], {
                        className: "delivery_v",
                        children: [ Object(m["jsxs"])(b["View"], {
                            className: "yprice",
                            children: [ "运费 ", Object(d["i"])(Ve), " 元" ]
                        }), Object(m["jsxs"])(b["View"], {
                            className: "sh_address",
                            onClick: It,
                            children: [ Object(m["jsx"])(b["View"], {
                                className: "left-icon",
                                children: Object(m["jsx"])(b["Text"], {
                                    className: "iconfont icon-fahuo"
                                })
                            }), Object(m["jsxs"])(b["View"], {
                                className: "right-address",
                                children: [ Object(m["jsxs"])(b["View"], {
                                    children: [ "收货人: ", et ? "".concat(et, " ").concat(nt) : "暂无收货地址信息", " " ]
                                }), Object(m["jsx"])(b["View"], {
                                    style: {
                                        marginTop: "5px"
                                    },
                                    children: Xe || "点击选择收货地址"
                                }) ]
                            }), Object(m["jsx"])(b["View"], {
                                children: Object(m["jsx"])(b["Text"], {
                                    className: "iconfont icon-arrow-right"
                                })
                            }) ]
                        }), Object(m["jsx"])(b["View"], {
                            className: "delivery_list_title",
                            children: "发货物品"
                        }), Object(m["jsx"])(b["View"], {
                            className: "delivery_list",
                            children: Object(m["jsxs"])(b["View"], {
                                className: "deliver-item",
                                children: [ Object(m["jsx"])(b["Image"], {
                                    src: "".concat(O.attachurl).concat(ce.image),
                                    className: "item-image"
                                }), Object(m["jsxs"])(b["View"], {
                                    className: "deliver-info",
                                    children: [ Object(m["jsx"])(b["View"], {
                                        className: "title",
                                        children: ce.name
                                    }), Object(m["jsxs"])(b["View"], {
                                        className: "deliver-price",
                                        children: [ "可发货数量:", ce.has_num ]
                                    }) ]
                                }), Object(m["jsxs"])(b["View"], {
                                    className: "deliver-num",
                                    children: [ Object(m["jsx"])(b["View"], {
                                        className: "left",
                                        onClick: function() {
                                            return Tt(!1);
                                        },
                                        children: "-"
                                    }), Object(m["jsx"])(b["Input"], {
                                        className: "input",
                                        disabled: !0,
                                        value: ot || 1
                                    }), Object(m["jsx"])(b["View"], {
                                        className: "right",
                                        onClick: function() {
                                            return Tt(!0);
                                        },
                                        children: "+"
                                    }) ]
                                }) ]
                            })
                        }), Object(m["jsx"])(b["View"], {
                            className: "remark",
                            children: Object(m["jsx"])(p["g"], {
                                className: "textarea",
                                placeholder: "发货备注信息",
                                onChange: Ee,
                                value: Ae,
                                height: 100,
                                maxLength: 80
                            })
                        }), Object(m["jsxs"])(b["View"], {
                            className: "ban",
                            children: [ Object(m["jsxs"])(b["View"], {
                                className: "text",
                                children: [ Object(m["jsx"])(b["Text"], {
                                    className: "iconfont icon-yuebao"
                                }), Object(m["jsxs"])(b["Text"], {
                                    children: [ "余额支付￥", Object(d["i"])(Te) ]
                                }) ]
                            }), Object(m["jsxs"])(b["View"], {
                                className: "desc",
                                children: [ "当前余额￥", Object(d["i"])(ge) ]
                            }), Object(m["jsx"])(b["Image"], {
                                className: "ej",
                                src: _.a
                            }) ]
                        }), Object(m["jsx"])(b["View"], {
                            className: "pb",
                            children: Qe ? Object(m["jsx"])(w["a"], {
                                className: "nocss-button button-p",
                                type: "primary",
                                onClick: zt,
                                children: "余额支付"
                            }) : Object(m["jsxs"])(w["a"], {
                                className: "nocss-button button-p",
                                type: "primary",
                                onClick: zt,
                                children: [ "微信支付运费", Object(d["i"])(De), "元" ]
                            })
                        }) ]
                    })
                }) : null, v.box_id && xt ? Object(m["jsx"])(S, Object(a["a"])(Object(a["a"])({
                    boxId: v.box_id
                }, xt), {}, {
                    onClose: function(e) {
                        ht(!1), e && Wt();
                    }
                })) : null, v.box_id && _t ? Object(m["jsx"])(I, Object(a["a"])(Object(a["a"])({
                    boxId: v.box_id
                }, _t), {}, {
                    onClose: function(e) {
                        wt(!1), Wt();
                    }
                })) : null, v.box_id && vt ? Object(m["jsx"])(M, {
                    setShareToken: function(e) {
                        St(e);
                    },
                    onClose: function() {
                        St(!1), Nt(!1);
                    },
                    item: vt
                }) : null ]
            });
        }, L = q, P = {
            navigationBarTitleText: "详情",
            enableShareAppMessage: !0
        };
        L.enableShareAppMessage = !0;
        Page(Object(s["createPageConfig"])(L, "pages/box/details/index", {
            root: {
                cn: []
            }
        }, P || {}));
    }
}, [ [ 266, 0, 2, 1, 3 ] ] ]);