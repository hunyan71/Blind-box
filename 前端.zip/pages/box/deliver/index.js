(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 16 ], {
    219: function(e, t, c) {},
    274: function(e, t, c) {
        "use strict";
        c.r(t);
        var a = c(7), s = c(13), n = c(3), i = c(2), l = c(4), r = c.n(l), j = c(1), o = (c(219), 
        c(44), c(5)), b = c(16), u = c(10), d = c(9), O = c(14), m = c(20), h = c(40), x = c.n(h), f = c(0), p = null, w = function() {
            var e = Object(i["useState"])([]), t = Object(n["a"])(e, 2), c = t[0], a = t[1], h = Object(i["useState"])({}), w = Object(n["a"])(h, 2), N = w[0], g = w[1], v = Object(i["useState"])(!0), V = Object(n["a"])(v, 2), y = V[0], S = V[1], _ = Object(i["useState"])({}), I = Object(n["a"])(_, 2), T = I[0], k = I[1], C = Object(i["useState"])(0), A = Object(n["a"])(C, 2), M = A[0], L = A[1], P = Object(i["useState"])(0), q = Object(n["a"])(P, 2), D = q[0], E = q[1], J = Object(i["useState"])(0), U = Object(n["a"])(J, 2), B = U[0], F = U[1], z = Object(i["useState"])(!1), G = Object(n["a"])(z, 2), H = G[0], K = G[1], Q = Object(i["useState"])(""), R = Object(n["a"])(Q, 2), W = R[0], X = R[1], Y = Object(i["useState"])(0), Z = Object(n["a"])(Y, 2), $ = Z[0], ee = Z[1], te = Object(i["useState"])(!1), ce = Object(n["a"])(te, 2), ae = ce[0], se = ce[1], ne = Object(i["useState"])(""), ie = Object(n["a"])(ne, 2), le = ie[0], re = ie[1], je = Object(i["useState"])(""), oe = Object(n["a"])(je, 2), be = oe[0], ue = oe[1], de = Object(i["useState"])(""), Oe = Object(n["a"])(de, 2), me = Oe[0], he = Oe[1], xe = Object(i["useState"])({}), fe = Object(n["a"])(xe, 2), pe = fe[0], we = fe[1], Ne = Object(i["useState"])(!1), ge = Object(n["a"])(Ne, 2), ve = ge[0], Ve = ge[1];
            Object(l["useShareAppMessage"])(function() {
                var e = r.a.getStorageSync("userInfo"), t = e.uid;
                return {
                    title: N.share_title,
                    path: t ? "/pages/index/index?fuid=".concat(t) : "/pages/index/index",
                    imageUrl: "".concat(N.attachurl).concat(N.share_image)
                };
            }), Object(i["useEffect"])(function() {
                Object(o["f"])(g), ye();
            }, []), Object(i["useEffect"])(function() {
                1 == ve && (ye(), k({}), we({}));
            }, [ ve ]);
            var ye = function() {
                Object(o["d"])({
                    url: "entry/wxapp/UserItemAll",
                    success: function(e) {
                        a(e), S(!1);
                    }
                });
            }, Se = function() {
                r.a.chooseAddress().then(function(e) {
                    var t = e.errMsg, c = e.cityName, a = e.countyName, s = e.detailInfo, n = e.provinceName, i = e.telNumber, l = e.userName;
                    "chooseAddress:ok" == t && (re("".concat(n).concat(c).concat(a).concat(s)), ue(l), 
                    he(i));
                }).catch(function() {});
            }, _e = function() {
                if (!le) return r.a.showModal({
                    title: "提示",
                    content: "请选择您的收货地址",
                    showCancel: !1,
                    complete: function() {
                        Se();
                    }
                });
                r.a.showLoading({
                    title: "创建订单中..."
                }), Object(o["d"])({
                    url: "entry/wxapp/Delivery",
                    data: {
                        address: le,
                        tel: me,
                        name: be,
                        ids: T
                    },
                    success: function(e) {
                        r.a.hideLoading();
                        var t = e.order_no, c = [];
                        N.submsg_1 && c.push(N.submsg_1), Object(o["g"])(c, function() {
                            e.need_pay ? r.a.requestPayment(Object(s["a"])({}, e.pay_config)).then(function(e) {
                                Ie(t);
                            }).catch(function(e) {
                                var t = e.errMsg;
                                "requestPayment:fail cancel" == t ? r.a.showToast({
                                    title: "取消支付",
                                    icon: "none"
                                }) : r.a.showToast({
                                    title: "支付失败",
                                    icon: "none"
                                });
                            }) : Ve(!0);
                        });
                    }
                });
            }, Ie = function(e) {
                r.a.showLoading({
                    title: "确认支付..."
                }), p = setInterval(function() {
                    Te(e);
                }, 3e3);
            }, Te = function(e) {
                Object(o["d"])({
                    url: "entry/wxapp/DeliveryPayStatus",
                    data: {
                        order_no: e
                    },
                    success: function(e) {
                        var t = e.pay_status;
                        1 == t && (clearInterval(p), r.a.hideLoading(), Ve(!0));
                    },
                    fail: function() {
                        clearInterval(p);
                    }
                });
            }, ke = Object(i["useState"])(!1), Ce = Object(n["a"])(ke, 2), Ae = Ce[0], Me = Ce[1], Le = function() {
                K(!0), Me(!0), Object(o["d"])({
                    url: "entry/wxapp/deliveryInfo",
                    success: function(e) {
                        L(e.balance_price), ee(e.wx_pay_price), se(e.all_balance), E(e.delivery_price), 
                        F(e.balance_price_pay), setTimeout(function() {
                            Me(!1);
                        }, 300);
                    }
                });
            }, Pe = function(e) {
                var t = Object(s["a"])({}, pe);
                t[e.id] || (t[e.id] = e, we(t));
            }, qe = function(e, t, a, n) {
                var i = Object(s["a"])({}, T);
                return i[e] = i[e] ? i[e] + t : t, !(c[n]["items"][a].have_num < i[e]) && (!(i[e] < 0) && (0 == i[e] && delete i[e], 
                k(i), void Pe(c[n]["items"][a])));
            }, De = function(e, t, c) {
                return Object(f["jsxs"])(j["View"], {
                    className: "deliver-item",
                    children: [ Object(f["jsx"])(j["Image"], {
                        src: "".concat(N.attachurl).concat(e.image),
                        className: "item-image",
                        mode: "aspectFit"
                    }), Object(f["jsxs"])(j["View"], {
                        className: "deliver-info",
                        children: [ Object(f["jsx"])(j["View"], {
                            className: "title",
                            children: e.name
                        }), Object(f["jsxs"])(j["View"], {
                            className: "deliver-price",
                            children: [ "可发货数:", e.have_num ]
                        }) ]
                    }), Object(f["jsxs"])(j["View"], {
                        className: "deliver-num",
                        children: [ Object(f["jsx"])(j["View"], {
                            className: "left",
                            onClick: function() {
                                return qe(e.id, -1, t, c);
                            },
                            children: "-"
                        }), Object(f["jsx"])(j["Input"], {
                            className: "input",
                            disabled: !0,
                            value: T[e.id] ? T[e.id] : 0
                        }), Object(f["jsx"])(j["View"], {
                            className: "right",
                            onClick: function() {
                                return qe(e.id, 1, t, c);
                            },
                            children: "+"
                        }) ]
                    }) ]
                }, t);
            }, Ee = function(e, t) {
                return Object(f["jsxs"])(j["View"], {
                    className: "deliver-item",
                    children: [ Object(f["jsx"])(j["Image"], {
                        src: "".concat(N.attachurl).concat(e.image),
                        className: "item-image"
                    }), Object(f["jsxs"])(j["View"], {
                        className: "deliver-info",
                        children: [ Object(f["jsx"])(j["View"], {
                            className: "title",
                            children: e.name
                        }), Object(f["jsxs"])(j["View"], {
                            className: "deliver-price",
                            children: [ "发货数:", T[e.id] ? T[e.id] : 0 ]
                        }) ]
                    }) ]
                }, t);
            };
            return Object(f["jsxs"])(j["View"], {
                className: "deliver-page",
                children: [ !y && c.map(function(e, t) {
                    return Object(f["jsxs"])(j["View"], {
                        className: "ditem",
                        children: [ Object(f["jsx"])(j["View"], {
                            className: "ditem-head",
                            children: e.name
                        }), Object(f["jsx"])(j["View"], {
                            className: "ditem-content",
                            children: e.items.map(function(e, c) {
                                return De(e, c, t);
                            })
                        }) ]
                    }, t);
                }), y ? Object(f["jsx"])(d["a"], {
                    iconStyle: {
                        color: "rgba(0,0,0,0.4)"
                    }
                }) : null, y || 0 != c.length ? null : Object(f["jsx"])(u["a"], {}), Object(f["jsx"])(j["View"], {
                    className: "deliver-btn",
                    children: Object(f["jsx"])(O["a"], {
                        className: "nocss-button button-p",
                        type: "primary",
                        disabled: 0 == Object.values(T).length,
                        onClick: function() {
                            return Le();
                        },
                        children: "确认发货"
                    })
                }), H ? Object(f["jsx"])(b["a"], {
                    title: ve ? "发货成功" : "发货订单",
                    onClose: function() {
                        K(!1), Ve(!1);
                    },
                    show: H,
                    children: Ae ? Object(f["jsx"])(d["a"], {
                        iconStyle: {
                            color: "rgba(0,0,0,0.4)"
                        }
                    }) : ve ? Object(f["jsxs"])(j["View"], {
                        className: "pay_success",
                        children: [ Object(f["jsx"])(j["View"], {
                            children: Object(f["jsx"])(j["Text"], {
                                className: "iconfont icon-fahuo"
                            })
                        }), Object(f["jsx"])(j["View"], {
                            className: "title",
                            children: "发货成功"
                        }), Object(f["jsx"])(j["View"], {
                            className: "desc",
                            children: "系统将在48小时内给您安排发货"
                        }) ]
                    }) : Object(f["jsxs"])(j["View"], {
                        className: "delivery_v",
                        children: [ Object(f["jsxs"])(j["View"], {
                            className: "yprice",
                            children: [ "运费 ", Object(o["i"])(D), " 元" ]
                        }), Object(f["jsxs"])(j["View"], {
                            className: "sh_address",
                            onClick: Se,
                            children: [ Object(f["jsx"])(j["View"], {
                                className: "left-icon",
                                children: Object(f["jsx"])(j["Text"], {
                                    className: "iconfont icon-fahuo"
                                })
                            }), Object(f["jsxs"])(j["View"], {
                                className: "right-address",
                                children: [ Object(f["jsxs"])(j["View"], {
                                    children: [ "收货人: ", be ? "".concat(be, " ").concat(me) : "暂无信息", " " ]
                                }), Object(f["jsx"])(j["View"], {
                                    style: {
                                        marginTop: "5px"
                                    },
                                    children: le || "点击选择收货地址"
                                }) ]
                            }), Object(f["jsx"])(j["View"], {
                                children: Object(f["jsx"])(j["Text"], {
                                    className: "iconfont icon-arrow-right"
                                })
                            }) ]
                        }), Object(f["jsx"])(j["View"], {
                            className: "delivery_list_title",
                            children: "发货物品"
                        }), Object(f["jsx"])(j["View"], {
                            className: "delivery_list",
                            children: Object.values(pe).map(Ee)
                        }), Object(f["jsx"])(j["View"], {
                            className: "remark",
                            children: Object(f["jsx"])(m["g"], {
                                className: "textarea",
                                placeholder: "发货备注信息",
                                onChange: X,
                                value: W,
                                height: 100,
                                maxLength: 80
                            })
                        }), Object(f["jsxs"])(j["View"], {
                            className: "ban",
                            children: [ Object(f["jsxs"])(j["View"], {
                                className: "text",
                                children: [ Object(f["jsx"])(j["Text"], {
                                    className: "iconfont icon-yuebao"
                                }), Object(f["jsxs"])(j["Text"], {
                                    children: [ "余额支付￥", Object(o["i"])(B) ]
                                }) ]
                            }), Object(f["jsxs"])(j["View"], {
                                className: "desc",
                                children: [ "当前余额￥", Object(o["i"])(M) ]
                            }), Object(f["jsx"])(j["Image"], {
                                className: "ej",
                                src: x.a
                            }) ]
                        }), Object(f["jsx"])(j["View"], {
                            className: "pb",
                            children: ae ? Object(f["jsx"])(O["a"], {
                                className: "nocss-button button-p",
                                type: "primary",
                                onClick: _e,
                                children: "余额支付"
                            }) : Object(f["jsxs"])(O["a"], {
                                className: "nocss-button button-p",
                                type: "primary",
                                onClick: _e,
                                children: [ "微信支付运费", Object(o["i"])($), "元" ]
                            })
                        }) ]
                    })
                }) : null ]
            });
        }, N = w, g = {
            navigationBarTitleText: "批量发货",
            enableShareAppMessage: !0
        };
        N.enableShareAppMessage = !0;
        Page(Object(a["createPageConfig"])(N, "pages/box/deliver/index", {
            root: {
                cn: []
            }
        }, g || {}));
    }
}, [ [ 274, 0, 2, 1, 3 ] ] ]);