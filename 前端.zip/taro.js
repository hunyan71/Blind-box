/*! For license information please see taro.js.LICENSE.txt */
(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 2 ], {
    1: function(e, t, n) {
        "use strict";
        n.r(t), n.d(t, "Ad", function() {
            return F;
        }), n.d(t, "AdCustom", function() {
            return K;
        }), n.d(t, "Audio", function() {
            return x;
        }), n.d(t, "Block", function() {
            return B;
        }), n.d(t, "Button", function() {
            return u;
        }), n.d(t, "Camera", function() {
            return A;
        }), n.d(t, "Canvas", function() {
            return R;
        }), n.d(t, "Checkbox", function() {
            return s;
        }), n.d(t, "CheckboxGroup", function() {
            return l;
        }), n.d(t, "CoverImage", function() {
            return w;
        }), n.d(t, "CoverView", function() {
            return k;
        }), n.d(t, "CustomWrapper", function() {
            return H;
        }), n.d(t, "Editor", function() {
            return $;
        }), n.d(t, "Form", function() {
            return d;
        }), n.d(t, "FunctionalPageNavigator", function() {
            return z;
        }), n.d(t, "Icon", function() {
            return i;
        }), n.d(t, "Image", function() {
            return I;
        }), n.d(t, "Input", function() {
            return f;
        }), n.d(t, "KeyboardAccessory", function() {
            return X;
        }), n.d(t, "Label", function() {
            return h;
        }), n.d(t, "LivePlayer", function() {
            return L;
        }), n.d(t, "LivePusher", function() {
            return q;
        }), n.d(t, "Map", function() {
            return D;
        }), n.d(t, "MatchMedia", function() {
            return W;
        }), n.d(t, "MovableArea", function() {
            return E;
        }), n.d(t, "MovableView", function() {
            return T;
        }), n.d(t, "NavigationBar", function() {
            return G;
        }), n.d(t, "Navigator", function() {
            return P;
        }), n.d(t, "OfficialAccount", function() {
            return V;
        }), n.d(t, "OpenData", function() {
            return Q;
        }), n.d(t, "PageContainer", function() {
            return Z;
        }), n.d(t, "PageMeta", function() {
            return J;
        }), n.d(t, "Picker", function() {
            return p;
        }), n.d(t, "PickerView", function() {
            return v;
        }), n.d(t, "PickerViewColumn", function() {
            return b;
        }), n.d(t, "Progress", function() {
            return o;
        }), n.d(t, "Radio", function() {
            return g;
        }), n.d(t, "RadioGroup", function() {
            return m;
        }), n.d(t, "RichText", function() {
            return a;
        }), n.d(t, "ScrollView", function() {
            return C;
        }), n.d(t, "Slider", function() {
            return y;
        }), n.d(t, "Slot", function() {
            return U;
        }), n.d(t, "Swiper", function() {
            return S;
        }), n.d(t, "SwiperItem", function() {
            return _;
        }), n.d(t, "Switch", function() {
            return O;
        }), n.d(t, "Text", function() {
            return c;
        }), n.d(t, "Textarea", function() {
            return j;
        }), n.d(t, "Video", function() {
            return N;
        }), n.d(t, "View", function() {
            return r;
        }), n.d(t, "VoipRoom", function() {
            return Y;
        }), n.d(t, "WebView", function() {
            return M;
        });
        var r = "view", i = "icon", o = "progress", a = "rich-text", c = "text", u = "button", s = "checkbox", l = "checkbox-group", d = "form", f = "input", h = "label", p = "picker", v = "picker-view", b = "picker-view-column", g = "radio", m = "radio-group", y = "slider", O = "switch", w = "cover-image", j = "textarea", k = "cover-view", E = "movable-area", T = "movable-view", C = "scroll-view", S = "swiper", _ = "swiper-item", P = "navigator", x = "audio", A = "camera", I = "image", L = "live-player", N = "video", R = "canvas", F = "ad", M = "web-view", B = "block", D = "map", U = "slot", H = "custom-wrapper", $ = "editor", W = "match-media", z = "functional-page-navigator", q = "live-pusher", V = "official-account", Q = "open-data", G = "navigation-bar", J = "page-meta", Y = "voip-room", K = "ad-custom", Z = "page-container", X = "keyboard-accessory";
    },
    108: function(e, t, n) {
        e.exports = n(170).default, e.exports.default = e.exports;
    },
    110: function(e, t, n) {
        "use strict";
        var r = n(17), i = n(18), o = n(111), a = n.n(o), c = n(75), u = n(7), s = n(6);
        function l(e) {
            return "o" === e[0] && "n" === e[1];
        }
        var d = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord/i;
        function f(e, t, n) {
            var r;
            for (r in t) r in n || v(e, r, null, t[r]);
            var i = e instanceof u["FormElement"];
            for (r in n) (t[r] !== n[r] || i && "value" === r) && v(e, r, n[r], t[r]);
        }
        function h(e, t, n, r) {
            var i = t.endsWith("Capture"), o = t.toLowerCase().slice(2);
            i && (o = o.slice(0, -7));
            var a = Object(s["capitalize"])(Object(s["toCamelCase"])(e.tagName.toLowerCase()));
            "click" === o && a in s["internalComponents"] && (o = "tap"), Object(s["isFunction"])(n) ? (r || e.addEventListener(o, n, i), 
            "regionchange" === o ? (e.__handlers.begin[0] = n, e.__handlers.end[0] = n) : e.__handlers[o][0] = n) : e.removeEventListener(o, r);
        }
        function p(e, t, n) {
            "-" === t[0] && e.setProperty(t, n.toString()), e[t] = Object(s["isNumber"])(n) && !1 === d.test(t) ? n + "px" : null == n ? "" : n;
        }
        function v(e, t, n, r) {
            var i, o, a, c;
            if (t = "className" === t ? "class" : t, "key" === t || "children" === t || "ref" === t) ; else if ("style" === t) {
                var u = e.style;
                if (Object(s["isString"])(n)) u.cssText = n; else {
                    if (Object(s["isString"])(r) && (u.cssText = "", r = null), Object(s["isObject"])(r)) for (var d in r) n && d in n || p(u, d, "");
                    if (Object(s["isObject"])(n)) for (var f in n) r && n[f] === r[f] || p(u, f, n[f]);
                }
            } else if (l(t)) h(e, t, n, r); else if ("dangerouslySetInnerHTML" === t) {
                var v = null !== (o = null === (i = n) || void 0 === i ? void 0 : i.__html) && void 0 !== o ? o : "", b = null !== (c = null === (a = r) || void 0 === a ? void 0 : a.__html) && void 0 !== c ? c : "";
                (v || b) && b !== v && (e.innerHTML = v);
            } else Object(s["isFunction"])(n) || (null == n ? e.removeAttribute(t) : e.setAttribute(t, n));
        }
        var b = c["unstable_now"];
        function g() {
            return !1;
        }
        var m = {
            createInstance: function(e) {
                return u["document"].createElement(e);
            },
            createTextInstance: function(e) {
                return u["document"].createTextNode(e);
            },
            getPublicInstance: function(e) {
                return e;
            },
            getRootHostContext: function() {
                return {};
            },
            getChildHostContext: function() {
                return {};
            },
            appendChild: function(e, t) {
                e.appendChild(t);
            },
            appendInitialChild: function(e, t) {
                e.appendChild(t);
            },
            appendChildToContainer: function(e, t) {
                e.appendChild(t);
            },
            removeChild: function(e, t) {
                e.removeChild(t);
            },
            removeChildFromContainer: function(e, t) {
                e.removeChild(t);
            },
            insertBefore: function(e, t, n) {
                e.insertBefore(t, n);
            },
            insertInContainerBefore: function(e, t, n) {
                e.insertBefore(t, n);
            },
            commitTextUpdate: function(e, t, n) {
                e.nodeValue = n;
            },
            finalizeInitialChildren: function(e, t, n) {
                return f(e, {}, n), !1;
            },
            prepareUpdate: function() {
                return s["EMPTY_ARR"];
            },
            commitUpdate: function(e, t, n, r, i) {
                f(e, r, i);
            },
            hideInstance: function(e) {
                var t = e.style;
                t.setProperty("display", "none");
            },
            unhideInstance: function(e, t) {
                var n = t.style, r = (null === n || void 0 === n ? void 0 : n.hasOwnProperty("display")) ? n.display : null;
                r = null == r || "boolean" === typeof r || "" === r ? "" : ("" + r).trim(), e.style["display"] = r;
            },
            clearContainer: function(e) {
                e.childNodes.length > 0 && (e.textContent = "");
            },
            queueMicrotask: "undefined" !== typeof Promise ? function(e) {
                return Promise.resolve(null).then(e).catch(function(e) {
                    setTimeout(function() {
                        throw e;
                    });
                });
            } : setTimeout,
            shouldSetTextContent: g,
            prepareForCommit: function() {
                return null;
            },
            resetAfterCommit: s["noop"],
            commitMount: s["noop"],
            now: b,
            cancelTimeout: clearTimeout,
            scheduleTimeout: setTimeout,
            preparePortalMount: s["noop"],
            noTimeout: -1,
            supportsMutation: !0,
            supportsPersistence: !1,
            isPrimaryRenderer: !0,
            supportsHydration: !1
        }, y = a()(m), O = new WeakMap(), w = function() {
            function e(t, n) {
                Object(r["a"])(this, e), this.renderer = t, this.internalRoot = t.createContainer(n, 0, !1, null);
            }
            return Object(i["a"])(e, [ {
                key: "render",
                value: function(e, t) {
                    return this.renderer.updateContainer(e, this.internalRoot, null, t), this.renderer.getPublicRootInstance(this.internalRoot);
                }
            }, {
                key: "unmount",
                value: function(e) {
                    this.renderer.updateContainer(null, this.internalRoot, null, e);
                }
            } ]), e;
        }();
        function j(e, t, n) {
            var r = O.get(t);
            if (null != r) return r.render(e, n);
            var i = new w(y, t);
            return O.set(t, i), i.render(e, n);
        }
        var k = y.batchedUpdates;
        function E(e) {
            Object(s["ensure"])(e && [ 1, 8, 9, 11 ].includes(e.nodeType), "unmountComponentAtNode(...): Target container is not a DOM element.");
            var t = O.get(e);
            return !!t && (k(function() {
                t.unmount(function() {
                    O.delete(e);
                });
            }, null), !0);
        }
        function T(e) {
            if (null == e) return null;
            var t = e.nodeType;
            return 1 === t || 3 === t ? e : y.findHostInstance(e);
        }
        var C = "function" === typeof Symbol && Symbol.for ? Symbol.for("react.portal") : 60106;
        function S(e, t, n) {
            return {
                $$typeof: C,
                key: null == n ? null : String(n),
                children: e,
                containerInfo: t,
                implementation: null
            };
        }
        var _ = {
            render: j,
            unstable_batchedUpdates: k,
            unmountComponentAtNode: E,
            findDOMNode: T,
            createPortal: S
        };
        t["a"] = _;
    },
    162: function(e, t, n) {
        "use strict";
        var r = n(6), i = new Set([ "authPrivateMessage", "disableAlertBeforeUnload", "enableAlertBeforeUnload", "getBackgroundFetchData", "getGroupEnterInfo", "getShareInfo", "getWeRunData", "join1v1Chat", "openVideoEditor", "saveFileToDisk", "scanItem", "setEnable1v1Chat", "setWindowSize", "sendBizRedPacket", "startFacialRecognitionVerify" ]);
        function o(e) {
            Object(r["processApis"])(e, wx, {
                needPromiseApis: i,
                modifyApis: function(e) {
                    e.delete("lanDebug");
                }
            }), e.cloud = wx.cloud;
        }
        var a = {
            Progress: {
                "border-radius": "0",
                "font-size": "16",
                duration: "30",
                bindActiveEnd: ""
            },
            RichText: {
                space: ""
            },
            Text: {
                "user-select": "false"
            },
            Map: {
                polygons: "[]",
                subkey: "",
                rotate: "0",
                skew: "0",
                "enable-3D": "false",
                "show-compass": "false",
                "show-scale": "false",
                "enable-overlooking": "false",
                "enable-zoom": "true",
                "enable-scroll": "true",
                "enable-rotate": "false",
                "enable-satellite": "false",
                "enable-traffic": "false",
                setting: "[]",
                bindLabelTap: "",
                bindRegionChange: "",
                bindPoiTap: ""
            },
            Button: {
                lang: "en",
                "session-from": "",
                "send-message-title": "",
                "send-message-path": "",
                "send-message-img": "",
                "app-parameter": "",
                "show-message-card": "false",
                "business-id": "",
                bindGetUserInfo: "",
                bindContact: "",
                bindGetPhoneNumber: "",
                bindError: "",
                bindOpenSetting: "",
                bindLaunchApp: ""
            },
            Form: {
                "report-submit-timeout": "0"
            },
            Input: {
                "always-embed": "false",
                "adjust-position": "true",
                "hold-keyboard": "false",
                bindKeyboardHeightChange: ""
            },
            Picker: {
                "header-text": ""
            },
            PickerView: {
                bindPickStart: "",
                bindPickEnd: ""
            },
            Slider: {
                color: Object(r["singleQuote"])("#e9e9e9"),
                "selected-color": Object(r["singleQuote"])("#1aad19")
            },
            Textarea: {
                "show-confirm-bar": "true",
                "adjust-position": "true",
                "hold-keyboard": "false",
                "disable-default-padding": "false",
                "confirm-type": Object(r["singleQuote"])("return"),
                "confirm-hold": "false",
                bindKeyboardHeightChange: ""
            },
            ScrollView: {
                "enable-flex": "false",
                "scroll-anchoring": "false",
                "refresher-enabled": "false",
                "refresher-threshold": "45",
                "refresher-default-style": Object(r["singleQuote"])("black"),
                "refresher-background": Object(r["singleQuote"])("#FFF"),
                "refresher-triggered": "false",
                enhanced: "false",
                bounces: "true",
                "show-scrollbar": "true",
                "paging-enabled": "false",
                "fast-deceleration": "false",
                bindDragStart: "",
                bindDragging: "",
                bindDragEnd: "",
                bindRefresherPulling: "",
                bindRefresherRefresh: "",
                bindRefresherRestore: "",
                bindRefresherAbort: ""
            },
            Swiper: {
                "snap-to-edge": "false",
                "easing-function": Object(r["singleQuote"])("default")
            },
            SwiperItem: {
                "skip-hidden-item-layout": "false"
            },
            Navigator: {
                target: Object(r["singleQuote"])("self"),
                "app-id": "",
                path: "",
                "extra-data": "",
                version: Object(r["singleQuote"])("version")
            },
            Camera: {
                mode: Object(r["singleQuote"])("normal"),
                resolution: Object(r["singleQuote"])("medium"),
                "frame-size": Object(r["singleQuote"])("medium"),
                bindInitDone: "",
                bindScanCode: ""
            },
            Image: {
                webp: "false",
                "show-menu-by-longpress": "false"
            },
            LivePlayer: {
                mode: Object(r["singleQuote"])("live"),
                "sound-mode": Object(r["singleQuote"])("speaker"),
                "auto-pause-if-navigate": "true",
                "auto-pause-if-open-native": "true",
                "picture-in-picture-mode": "[]",
                bindstatechange: "",
                bindfullscreenchange: "",
                bindnetstatus: "",
                bindAudioVolumeNotify: "",
                bindEnterPictureInPicture: "",
                bindLeavePictureInPicture: ""
            },
            Video: {
                title: "",
                "play-btn-position": Object(r["singleQuote"])("bottom"),
                "enable-play-gesture": "false",
                "auto-pause-if-navigate": "true",
                "auto-pause-if-open-native": "true",
                "vslide-gesture": "false",
                "vslide-gesture-in-fullscreen": "true",
                "ad-unit-id": "",
                "poster-for-crawler": "",
                "show-casting-button": "false",
                "picture-in-picture-mode": "[]",
                "enable-auto-rotation": "false",
                "show-screen-lock-button": "false",
                "show-snapshot-button": "false",
                "show-background-playback-button": "false",
                "background-poster": "",
                bindProgress: "",
                bindLoadedMetadata: "",
                bindControlsToggle: "",
                bindEnterPictureInPicture: "",
                bindLeavePictureInPicture: "",
                bindSeekComplete: "",
                bindAdLoad: "",
                bindAdError: "",
                bindAdClose: "",
                bindAdPlay: ""
            },
            Canvas: {
                type: ""
            },
            Ad: {
                "ad-type": Object(r["singleQuote"])("banner"),
                "ad-theme": Object(r["singleQuote"])("white")
            },
            CoverView: {
                "marker-id": "",
                slot: ""
            },
            Editor: {
                "read-only": "false",
                placeholder: "",
                "show-img-size": "false",
                "show-img-toolbar": "false",
                "show-img-resize": "false",
                focus: "false",
                bindReady: "",
                bindFocus: "",
                bindBlur: "",
                bindInput: "",
                bindStatusChange: "",
                name: ""
            },
            MatchMedia: {
                "min-width": "",
                "max-width": "",
                width: "",
                "min-height": "",
                "max-height": "",
                height: "",
                orientation: ""
            },
            FunctionalPageNavigator: {
                version: Object(r["singleQuote"])("release"),
                name: "",
                args: "",
                bindSuccess: "",
                bindFail: "",
                bindCancel: ""
            },
            LivePusher: {
                url: "",
                mode: Object(r["singleQuote"])("RTC"),
                autopush: "false",
                muted: "false",
                "enable-camera": "true",
                "auto-focus": "true",
                orientation: Object(r["singleQuote"])("vertical"),
                beauty: "0",
                whiteness: "0",
                aspect: Object(r["singleQuote"])("9:16"),
                "min-bitrate": "200",
                "max-bitrate": "1000",
                "audio-quality": Object(r["singleQuote"])("high"),
                "waiting-image": "",
                "waiting-image-hash": "",
                zoom: "false",
                "device-position": Object(r["singleQuote"])("front"),
                "background-mute": "false",
                mirror: "false",
                "remote-mirror": "false",
                "local-mirror": "false",
                "audio-reverb-type": "0",
                "enable-mic": "true",
                "enable-agc": "false",
                "enable-ans": "false",
                "audio-volume-type": Object(r["singleQuote"])("voicecall"),
                "video-width": "360",
                "video-height": "640",
                "beauty-style": Object(r["singleQuote"])("smooth"),
                filter: Object(r["singleQuote"])("standard"),
                animation: "",
                bindStateChange: "",
                bindNetStatus: "",
                bindBgmStart: "",
                bindBgmProgress: "",
                bindBgmComplete: "",
                bindAudioVolumeNotify: ""
            },
            OfficialAccount: {
                bindLoad: "",
                bindError: ""
            },
            OpenData: {
                type: "",
                "open-gid": "",
                lang: Object(r["singleQuote"])("en"),
                "default-text": "",
                "default-avatar": "",
                bindError: ""
            },
            NavigationBar: {
                title: "",
                loading: "false",
                "front-color": "",
                "background-color": "",
                "color-animation-duration": "0",
                "color-animation-timing-func": Object(r["singleQuote"])("linear")
            },
            PageMeta: {
                "background-text-style": "",
                "background-color": "",
                "background-color-top": "",
                "background-color-bottom": "",
                "scroll-top": Object(r["singleQuote"])(""),
                "scroll-duration": "300",
                "page-style": Object(r["singleQuote"])(""),
                "root-font-size": Object(r["singleQuote"])(""),
                bindResize: "",
                bindScroll: "",
                bindScrollDone: ""
            },
            VoipRoom: {
                openid: "",
                mode: Object(r["singleQuote"])("camera"),
                "device-position": Object(r["singleQuote"])("front"),
                bindError: ""
            },
            AdCustom: {
                "unit-id": "",
                "ad-intervals": "",
                bindLoad: "",
                bindError: ""
            },
            PageContainer: {
                show: "false",
                duration: "300",
                "z-index": "100",
                overlay: "true",
                position: Object(r["singleQuote"])("bottom"),
                round: "false",
                "close-on-slideDown": "false",
                "overlay-style": "",
                "custom-style": "",
                bindBeforeEnter: "",
                bindEnter: "",
                bindAfterEnter: "",
                bindBeforeLeave: "",
                bindLeave: "",
                bindAfterLeave: "",
                bindClickOverlay: ""
            },
            KeyboardAccessory: {}
        }, c = {
            initNativeApi: o
        };
        Object(r["mergeReconciler"])(c), Object(r["mergeInternalComponents"])(a);
    },
    166: function(e, t, n) {
        var r = function() {
            return this;
        }() || Function("return this")(), i = r.regeneratorRuntime && Object.getOwnPropertyNames(r).indexOf("regeneratorRuntime") >= 0, o = i && r.regeneratorRuntime;
        if (r.regeneratorRuntime = void 0, e.exports = n(167), i) r.regeneratorRuntime = o; else try {
            delete r.regeneratorRuntime;
        } catch (e) {
            r.regeneratorRuntime = void 0;
        }
    },
    167: function(e, t, n) {
        (function(e) {
            var t = n(21);
            !function(n) {
                "use strict";
                var r, i = Object.prototype, o = i.hasOwnProperty, a = "function" === typeof Symbol ? Symbol : {}, c = a.iterator || "@@iterator", u = a.asyncIterator || "@@asyncIterator", s = a.toStringTag || "@@toStringTag", l = "object" === t(e), d = n.regeneratorRuntime;
                if (d) l && (e.exports = d); else {
                    d = n.regeneratorRuntime = l ? e.exports : {}, d.wrap = w;
                    var f = "suspendedStart", h = "suspendedYield", p = "executing", v = "completed", b = {}, g = {};
                    g[c] = function() {
                        return this;
                    };
                    var m = Object.getPrototypeOf, y = m && m(m(L([])));
                    y && y !== i && o.call(y, c) && (g = y);
                    var O = T.prototype = k.prototype = Object.create(g);
                    E.prototype = O.constructor = T, T.constructor = E, T[s] = E.displayName = "GeneratorFunction", 
                    d.isGeneratorFunction = function(e) {
                        var t = "function" === typeof e && e.constructor;
                        return !!t && (t === E || "GeneratorFunction" === (t.displayName || t.name));
                    }, d.mark = function(e) {
                        return Object.setPrototypeOf ? Object.setPrototypeOf(e, T) : (e.__proto__ = T, s in e || (e[s] = "GeneratorFunction")), 
                        e.prototype = Object.create(O), e;
                    }, d.awrap = function(e) {
                        return {
                            __await: e
                        };
                    }, C(S.prototype), S.prototype[u] = function() {
                        return this;
                    }, d.AsyncIterator = S, d.async = function(e, t, n, r) {
                        var i = new S(w(e, t, n, r));
                        return d.isGeneratorFunction(t) ? i : i.next().then(function(e) {
                            return e.done ? e.value : i.next();
                        });
                    }, C(O), O[s] = "Generator", O[c] = function() {
                        return this;
                    }, O.toString = function() {
                        return "[object Generator]";
                    }, d.keys = function(e) {
                        var t = [];
                        for (var n in e) t.push(n);
                        return t.reverse(), function n() {
                            while (t.length) {
                                var r = t.pop();
                                if (r in e) return n.value = r, n.done = !1, n;
                            }
                            return n.done = !0, n;
                        };
                    }, d.values = L, I.prototype = {
                        constructor: I,
                        reset: function(e) {
                            if (this.prev = 0, this.next = 0, this.sent = this._sent = r, this.done = !1, this.delegate = null, 
                            this.method = "next", this.arg = r, this.tryEntries.forEach(A), !e) for (var t in this) "t" === t.charAt(0) && o.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = r);
                        },
                        stop: function() {
                            this.done = !0;
                            var e = this.tryEntries[0], t = e.completion;
                            if ("throw" === t.type) throw t.arg;
                            return this.rval;
                        },
                        dispatchException: function(e) {
                            if (this.done) throw e;
                            var t = this;
                            function n(n, i) {
                                return c.type = "throw", c.arg = e, t.next = n, i && (t.method = "next", t.arg = r), 
                                !!i;
                            }
                            for (var i = this.tryEntries.length - 1; i >= 0; --i) {
                                var a = this.tryEntries[i], c = a.completion;
                                if ("root" === a.tryLoc) return n("end");
                                if (a.tryLoc <= this.prev) {
                                    var u = o.call(a, "catchLoc"), s = o.call(a, "finallyLoc");
                                    if (u && s) {
                                        if (this.prev < a.catchLoc) return n(a.catchLoc, !0);
                                        if (this.prev < a.finallyLoc) return n(a.finallyLoc);
                                    } else if (u) {
                                        if (this.prev < a.catchLoc) return n(a.catchLoc, !0);
                                    } else {
                                        if (!s) throw new Error("try statement without catch or finally");
                                        if (this.prev < a.finallyLoc) return n(a.finallyLoc);
                                    }
                                }
                            }
                        },
                        abrupt: function(e, t) {
                            for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                                var r = this.tryEntries[n];
                                if (r.tryLoc <= this.prev && o.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                                    var i = r;
                                    break;
                                }
                            }
                            i && ("break" === e || "continue" === e) && i.tryLoc <= t && t <= i.finallyLoc && (i = null);
                            var a = i ? i.completion : {};
                            return a.type = e, a.arg = t, i ? (this.method = "next", this.next = i.finallyLoc, 
                            b) : this.complete(a);
                        },
                        complete: function(e, t) {
                            if ("throw" === e.type) throw e.arg;
                            return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, 
                            this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), 
                            b;
                        },
                        finish: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var n = this.tryEntries[t];
                                if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), A(n), b;
                            }
                        },
                        catch: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var n = this.tryEntries[t];
                                if (n.tryLoc === e) {
                                    var r = n.completion;
                                    if ("throw" === r.type) {
                                        var i = r.arg;
                                        A(n);
                                    }
                                    return i;
                                }
                            }
                            throw new Error("illegal catch attempt");
                        },
                        delegateYield: function(e, t, n) {
                            return this.delegate = {
                                iterator: L(e),
                                resultName: t,
                                nextLoc: n
                            }, "next" === this.method && (this.arg = r), b;
                        }
                    };
                }
                function w(e, t, n, r) {
                    var i = t && t.prototype instanceof k ? t : k, o = Object.create(i.prototype), a = new I(r || []);
                    return o._invoke = _(e, n, a), o;
                }
                function j(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        };
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        };
                    }
                }
                function k() {}
                function E() {}
                function T() {}
                function C(e) {
                    [ "next", "throw", "return" ].forEach(function(t) {
                        e[t] = function(e) {
                            return this._invoke(t, e);
                        };
                    });
                }
                function S(e) {
                    function n(r, i, a, c) {
                        var u = j(e[r], e, i);
                        if ("throw" !== u.type) {
                            var s = u.arg, l = s.value;
                            return l && "object" === t(l) && o.call(l, "__await") ? Promise.resolve(l.__await).then(function(e) {
                                n("next", e, a, c);
                            }, function(e) {
                                n("throw", e, a, c);
                            }) : Promise.resolve(l).then(function(e) {
                                s.value = e, a(s);
                            }, c);
                        }
                        c(u.arg);
                    }
                    var r;
                    function i(e, t) {
                        function i() {
                            return new Promise(function(r, i) {
                                n(e, t, r, i);
                            });
                        }
                        return r = r ? r.then(i, i) : i();
                    }
                    this._invoke = i;
                }
                function _(e, t, n) {
                    var r = f;
                    return function(i, o) {
                        if (r === p) throw new Error("Generator is already running");
                        if (r === v) {
                            if ("throw" === i) throw o;
                            return N();
                        }
                        n.method = i, n.arg = o;
                        while (1) {
                            var a = n.delegate;
                            if (a) {
                                var c = P(a, n);
                                if (c) {
                                    if (c === b) continue;
                                    return c;
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg; else if ("throw" === n.method) {
                                if (r === f) throw r = v, n.arg;
                                n.dispatchException(n.arg);
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = p;
                            var u = j(e, t, n);
                            if ("normal" === u.type) {
                                if (r = n.done ? v : h, u.arg === b) continue;
                                return {
                                    value: u.arg,
                                    done: n.done
                                };
                            }
                            "throw" === u.type && (r = v, n.method = "throw", n.arg = u.arg);
                        }
                    };
                }
                function P(e, t) {
                    var n = e.iterator[t.method];
                    if (n === r) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = r, P(e, t), "throw" === t.method)) return b;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method");
                        }
                        return b;
                    }
                    var i = j(n, e.iterator, t.arg);
                    if ("throw" === i.type) return t.method = "throw", t.arg = i.arg, t.delegate = null, 
                    b;
                    var o = i.arg;
                    return o ? o.done ? (t[e.resultName] = o.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", 
                    t.arg = r), t.delegate = null, b) : o : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), 
                    t.delegate = null, b);
                }
                function x(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), 
                    this.tryEntries.push(t);
                }
                function A(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t;
                }
                function I(e) {
                    this.tryEntries = [ {
                        tryLoc: "root"
                    } ], e.forEach(x, this), this.reset(!0);
                }
                function L(e) {
                    if (e) {
                        var t = e[c];
                        if (t) return t.call(e);
                        if ("function" === typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var n = -1, i = function t() {
                                while (++n < e.length) if (o.call(e, n)) return t.value = e[n], t.done = !1, t;
                                return t.value = r, t.done = !0, t;
                            };
                            return i.next = i;
                        }
                    }
                    return {
                        next: N
                    };
                }
                function N() {
                    return {
                        value: r,
                        done: !0
                    };
                }
            }(function() {
                return this;
            }() || Function("return this")());
        }).call(this, n(85)(e));
    },
    168: function(e, t, n) {
        "use strict";
        n.r(t), function(e, r) {
            var i = n(21), o = n.n(i), a = n(107), c = n.n(a), u = n(58), s = n.n(u), l = n(59), d = n.n(l), f = n(50), h = n.n(f), p = n(7);
            "function" !== typeof Object.assign && (Object.assign = function(e) {
                if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                for (var t = Object(e), n = 1; n < arguments.length; n++) {
                    var r = arguments[n];
                    if (null != r) for (var i in r) Object.prototype.hasOwnProperty.call(r, i) && (t[i] = r[i]);
                }
                return t;
            }), "function" !== typeof Object.defineProperties && (Object.defineProperties = function(e, t) {
                function n(e) {
                    function t(e, t) {
                        return Object.prototype.hasOwnProperty.call(e, t);
                    }
                    function n(e) {
                        return "function" === typeof e;
                    }
                    if ("object" !== o()(e) || null === e) throw new TypeError("bad desc");
                    var r = {};
                    if (t(e, "enumerable") && (r.enumerable = !!e.enumerable), t(e, "configurable") && (r.configurable = !!e.configurable), 
                    t(e, "value") && (r.value = e.value), t(e, "writable") && (r.writable = !!e.writable), 
                    t(e, "get")) {
                        var i = e.get;
                        if (!n(i) && "undefined" !== typeof i) throw new TypeError("bad get");
                        r.get = i;
                    }
                    if (t(e, "set")) {
                        var a = e.set;
                        if (!n(a) && "undefined" !== typeof a) throw new TypeError("bad set");
                        r.set = a;
                    }
                    if (("get" in r || "set" in r) && ("value" in r || "writable" in r)) throw new TypeError("identity-confused descriptor");
                    return r;
                }
                if ("object" !== o()(e) || null === e) throw new TypeError("bad obj");
                t = Object(t);
                for (var r = Object.keys(t), i = [], a = 0; a < r.length; a++) i.push([ r[a], n(t[r[a]]) ]);
                for (var c = 0; c < i.length; c++) Object.defineProperty(e, i[c][0], i[c][1]);
                return e;
            });
            var v = {
                WEAPP: "WEAPP",
                WEB: "WEB",
                RN: "RN",
                SWAN: "SWAN",
                ALIPAY: "ALIPAY",
                TT: "TT",
                QQ: "QQ",
                JD: "JD"
            }, b = null;
            function g() {
                return b || ("undefined" !== typeof jd && jd.getSystemInfo ? (b = v.JD, v.JD) : "undefined" !== typeof qq && qq.getSystemInfo ? (b = v.QQ, 
                v.QQ) : "undefined" !== typeof tt && tt.getSystemInfo ? (b = v.TT, v.TT) : "undefined" !== typeof wx && wx.getSystemInfo ? (b = v.WEAPP, 
                v.WEAPP) : "undefined" !== typeof swan && swan.getSystemInfo ? (b = v.SWAN, v.SWAN) : "undefined" !== typeof my && my.getSystemInfo ? (b = v.ALIPAY, 
                v.ALIPAY) : "undefined" !== typeof e && e.__fbGenNativeModule ? (b = v.RN, v.RN) : "undefined" !== typeof r ? (b = v.WEB, 
                v.WEB) : "Unknown environment");
            }
            var m = function() {
                function e(t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                    s()(this, e), this.index = r, this.requestParams = t, this.interceptors = n;
                }
                return d()(e, [ {
                    key: "proceed",
                    value: function(e) {
                        if (this.requestParams = e, this.index >= this.interceptors.length) throw new Error("chain 参数错误, 请勿直接修改 request.chain");
                        var t = this._getNextInterceptor(), n = this._getNextChain(), r = t(n), i = r.catch(function(e) {
                            return Promise.reject(e);
                        });
                        return "function" === typeof r.abort && (i.abort = r.abort), i;
                    }
                }, {
                    key: "_getNextInterceptor",
                    value: function() {
                        return this.interceptors[this.index];
                    }
                }, {
                    key: "_getNextChain",
                    value: function() {
                        return new e(this.requestParams, this.interceptors, this.index + 1);
                    }
                } ]), e;
            }(), y = function() {
                function e(t) {
                    s()(this, e), this.taroInterceptor = t, this.chain = new m();
                }
                return d()(e, [ {
                    key: "request",
                    value: function(e) {
                        var t = this;
                        return this.chain.interceptors = this.chain.interceptors.filter(function(e) {
                            return e !== t.taroInterceptor;
                        }), this.chain.interceptors.push(this.taroInterceptor), this.chain.proceed(c()({}, e));
                    }
                }, {
                    key: "addInterceptor",
                    value: function(e) {
                        this.chain.interceptors.push(e);
                    }
                }, {
                    key: "cleanInterceptors",
                    value: function() {
                        this.chain = new m();
                    }
                } ]), e;
            }();
            function O(e) {
                var t, n = e.requestParams, r = new Promise(function(r, i) {
                    var o = setTimeout(function() {
                        o = null, i(new Error("网络链接超时,请稍后再试！"));
                    }, n && n.timeout || 6e4);
                    t = e.proceed(n), t.then(function(e) {
                        o && (clearTimeout(o), r(e));
                    }).catch(function(e) {
                        o && clearTimeout(o), i(e);
                    });
                });
                return void 0 !== t && "function" === typeof t.abort && (r.abort = t.abort), r;
            }
            function w(e) {
                var t = e.requestParams, n = t.method, r = t.data, i = t.url;
                console.log("http ".concat(n || "GET", " --\x3e ").concat(i, " data: "), r);
                var o = e.proceed(t), a = o.then(function(e) {
                    return console.log("http <-- ".concat(i, " result:"), e), e;
                });
                return "function" === typeof o.abort && (a.abort = o.abort), a;
            }
            var j = Object.freeze({
                __proto__: null,
                timeoutInterceptor: O,
                logInterceptor: w
            });
            function k(e) {
                return e;
            }
            function E(e) {
                return function(t, n) {
                    "object" === o()(t) ? e.preloadData = t : void 0 !== t && void 0 !== n && (e.preloadData = h()({}, t, n));
                };
            }
            function T(e) {
                return function(t) {
                    var n = t.designWidth, r = void 0 === n ? 750 : n, i = t.deviceRatio, o = void 0 === i ? {
                        640: 1.17,
                        750: 1,
                        828: .905
                    } : i;
                    e.config = e.config || {}, e.config.designWidth = r, e.config.deviceRatio = o;
                };
            }
            function C(e) {
                return function(t) {
                    var n = e.config || {}, r = n.designWidth, i = void 0 === r ? 750 : r, o = n.deviceRatio, a = void 0 === o ? {
                        640: 1.17,
                        750: 1,
                        828: .905
                    } : o;
                    if (!(i in a)) throw new Error("deviceRatio 配置中不存在 ".concat(i, " 的设置！"));
                    return parseInt(t, 10) * a[i] + "rpx";
                };
            }
            var S = {
                Behavior: k,
                getEnv: g,
                ENV_TYPE: v,
                Link: y,
                interceptors: j,
                Current: p["Current"],
                getCurrentInstance: p["getCurrentInstance"],
                options: p["options"],
                nextTick: p["nextTick"],
                eventCenter: p["eventCenter"],
                Events: p["Events"],
                useDidShow: p["useDidShow"],
                useDidHide: p["useDidHide"],
                usePullDownRefresh: p["usePullDownRefresh"],
                useReachBottom: p["useReachBottom"],
                usePageScroll: p["usePageScroll"],
                useResize: p["useResize"],
                useShareAppMessage: p["useShareAppMessage"],
                useTabItemTap: p["useTabItemTap"],
                useTitleClick: p["useTitleClick"],
                useOptionMenuClick: p["useOptionMenuClick"],
                usePullIntercept: p["usePullIntercept"],
                useShareTimeline: p["useShareTimeline"],
                useAddToFavorites: p["useAddToFavorites"],
                useReady: p["useReady"],
                useRouter: p["useRouter"],
                getInitPxTransform: T
            };
            S.initPxTransform = T(S), S.preload = E(p["Current"]), S.pxTransform = C(S), t["default"] = S;
        }.call(this, n(27), n(7)["window"]);
    },
    170: function(e, t, n) {
        "use strict";
        var r = n(21);
        function i(e) {
            return e && "object" === r(e) && "default" in e ? e["default"] : e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o, a, c = i(n(50)), u = i(n(82)), s = i(n(171)), l = i(n(58)), d = i(n(59)), f = i(n(86)), h = i(n(175)), p = i(n(177)), v = i(n(179)), b = i(n(87)), g = i(n(21)), m = n(4), y = n(7);
        (function(e) {
            e["WillMount"] = "componentWillMount", e["DidMount"] = "componentDidMount", e["DidShow"] = "componentDidShow", 
            e["DidHide"] = "componentDidHide", e["WillUnmount"] = "componentWillUnmount";
        })(a || (a = {}));
        var O = (o = {}, c(o, a.WillMount, [ "created" ]), c(o, a.DidMount, [ "attached" ]), 
        c(o, a.DidShow, [ "onShow" ]), c(o, a.DidHide, [ "onHide" ]), c(o, a.WillUnmount, [ "detached", "onUnload" ]), 
        o), w = new Set([ "ready" ]);
        for (var j in O) {
            var k = O[j];
            k.forEach(function(e) {
                return w.add(e);
            });
        }
        var E = [ "onPullDownRefresh", "onReachBottom", "onShareAppMessage", "onShareTimeline", "onAddToFavorites", "onPageScroll", "onResize", "onTabItemTap" ], T = [ "onLaunch", "onShow", "onHide", "onError", "onPageNotFound", "onUnhandledRejection", "onThemeChange" ];
        function C(e, t) {
            if (!e) return !1;
            function n(n) {
                var r = arguments.length;
                return r ? r > 1 ? e.apply(t, arguments) : e.call(t, n) : e.call(t);
            }
            return n._length = e.length, n;
        }
        function S(e, t) {
            return JSON.stringify(e) === JSON.stringify(t);
        }
        function _(e, t, n) {
            if (!e) return n;
            var r, i;
            if (Array.isArray(t) && (r = t.slice(0)), "string" === typeof t && (r = t.replace(/\[(.+?)\]/g, ".$1"), 
            r = r.split(".")), "symbol" === g(t) && (r = [ t ]), !Array.isArray(r)) throw new Error("props arg must be an array, a string or a symbol");
            while (r.length) {
                if (i = r.shift(), !e) return n;
                if (e = e[i], void 0 === e) return n;
            }
            return e;
        }
        function P(e, t, n) {
            "string" === typeof t && (t = t.replace(/\[(.+?)\]/g, ".$1"), t = t.split(".")), 
            "symbol" === g(t) && (t = [ t ]);
            var r, i = t.pop();
            if (!i) return !1;
            while (r = t.shift()) if ("undefined" === typeof e[r] && (e[r] = {}), Array.isArray(e[r]) ? e[r] = u(e[r]) : "object" === g(e[r]) && (e[r] = Object.assign({}, e[r])), 
            e = e[r], !e || "object" !== g(e)) return !1;
            return e[i] = n, !0;
        }
        function x(e) {
            console.warn("[Taro Convert Warning] " + e);
        }
        var A = new Map([ [ "onError", "不支持 App 的 onError 生命周期方法。" ], [ "onPageNotFound", "不支持 App 的 onPageNotFound 生命周期方法。" ], [ "onUnhandledRejection", "不支持 App 的 onUnhandledRejection 生命周期方法。" ], [ "onThemeChange", "不支持 App 的 onThemeChange 生命周期方法。" ], [ "moved", "不支持自定义组件的 moved 生命周期。" ], [ "externalClasses", "不支持自定义组件的 externalClasses 功能。" ], [ "relations", "不支持自定义组件的 relations 功能。" ], [ "options", "不支持自定义组件的 options 功能。" ], [ "definitionFilter", "不支持自定义组件的 definitionFilter 功能。" ], [ "selectComponent", "selectComponent 方法产生不到目标效果，请使用 React 的 ref 进行重构。" ], [ "selectAllComponents", "selectAllComponents 方法产生不到目标效果，请使用 React 的 ref 进行重构。" ], [ "selectOwnerComponent", "selectOwnerComponent 方法产生不到目标效果，请使用 React 语法重构。" ], [ "groupSetData", "groupSetData 方法产生不到目标效果，请使用 React 语法重构。" ] ]);
        function I(e, t) {
            if ("string" === typeof e) return x("不支持使用内置 Behavior: [".concat(e, "]"));
            var n = e.behaviors;
            (null === n || void 0 === n ? void 0 : n.length) && n.forEach(function(e) {
                return I(e, t);
            }), Object.keys(e).forEach(function(n) {
                if (A.has(n)) {
                    var r = A.get(n);
                    return x(r);
                }
                if (t.has(n)) {
                    var i = t.get(n), o = e[n];
                    i.push(o);
                }
            });
        }
        var L = "[object Array]", N = "[object Object]", R = "[object Function]";
        function F(e, t) {
            var n = {};
            return M(e, t), B(e, t, "", n), n;
        }
        function M(e, t) {
            if (e !== t) {
                var n = U(e), r = U(t);
                if (n == N && r == N) for (var i in t) {
                    var o = e[i];
                    void 0 === o ? e[i] = null : M(o, t[i]);
                } else n == L && r == L && e.length >= t.length && t.forEach(function(t, n) {
                    M(e[n], t);
                });
            }
        }
        function B(e, t, n, r) {
            if (e !== t) {
                var i = U(e), o = U(t);
                if (i == N) if (o != N || Object.keys(e).length < Object.keys(t).length) D(r, n, e); else {
                    var a = function(i) {
                        var o = e[i], a = t[i], c = U(o), u = U(a);
                        if (c != L && c != N) o != t[i] && D(r, ("" == n ? "" : n + ".") + i, o); else if (c == L) u != L || o.length < a.length ? D(r, ("" == n ? "" : n + ".") + i, o) : o.forEach(function(e, t) {
                            B(e, a[t], ("" == n ? "" : n + ".") + i + "[" + t + "]", r);
                        }); else if (c == N) if (u != N || Object.keys(o).length < Object.keys(a).length) D(r, ("" == n ? "" : n + ".") + i, o); else for (var s in o) B(o[s], a[s], ("" == n ? "" : n + ".") + i + "." + s, r);
                    };
                    for (var c in e) a(c);
                } else i == L ? o != L || e.length < t.length ? D(r, n, e) : e.forEach(function(e, i) {
                    B(e, t[i], n + "[" + i + "]", r);
                }) : D(r, n, e);
            }
        }
        function D(e, t, n) {
            U(n) != R && (e[t] = n);
        }
        function U(e) {
            return Object.prototype.toString.call(e);
        }
        var H = JSON, $ = function(e) {
            return H.parse(q(e));
        }, W = Array.isArray || function(e) {
            return "[object Array]" === {}.toString.call(e);
        }, z = Object.keys || function(e) {
            var t = Object.prototype.hasOwnProperty || function() {
                return !0;
            }, n = [];
            for (var r in e) t.call(e, r) && n.push(r);
            return n;
        };
        function q(e, t) {
            t || (t = {}), "function" === typeof t && (t = {
                cmp: t
            });
            var n = t.space || "";
            "number" === typeof n && (n = Array(n + 1).join(" "));
            var r = "boolean" === typeof t.cycles && t.cycles, i = t.replacer || function(e, t) {
                return t;
            }, o = t.cmp && function(e) {
                return function(t) {
                    return function(n, r) {
                        var i = {
                            key: n,
                            value: t[n]
                        }, o = {
                            key: r,
                            value: t[r]
                        };
                        return e(i, o);
                    };
                };
            }(t.cmp), a = [];
            return function e(t, c, u, s) {
                var l = n ? "\n" + new Array(s + 1).join(n) : "", d = n ? ": " : ":";
                if (u && u.toJSON && "function" === typeof u.toJSON && (u = u.toJSON()), u = i.call(t, c, u), 
                void 0 !== u) {
                    if ("object" !== g(u) || null === u) return H.stringify(u);
                    if (W(u)) {
                        for (var f = [], h = 0; h < u.length; h++) {
                            var p = e(u, h, u[h], s + 1) || H.stringify(null);
                            f.push(l + n + p);
                        }
                        return "[" + f.join(",") + l + "]";
                    }
                    if (-1 !== a.indexOf(u)) {
                        if (r) return H.stringify("__cycle__");
                        throw new TypeError("Converting circular structure to JSON");
                    }
                    a.push(u);
                    for (var v = z(u).sort(o && o(u)), b = [], m = 0; m < v.length; m++) {
                        var y = v[m], O = e(u, y, u[y], s + 1);
                        if (O) {
                            var w = H.stringify(y) + d + O;
                            b.push(l + n + w);
                        }
                    }
                    return a.splice(a.indexOf(u), 1), "{" + b.join(",") + l + "}";
                }
            }({
                "": e
            }, "", e, 0);
        }
        function V(e, t) {
            var n = "undefined" !== typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = Q(e)) || t && e && "number" === typeof e.length) {
                    n && (e = n);
                    var r = 0, i = function() {};
                    return {
                        s: i,
                        n: function() {
                            return r >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[r++]
                            };
                        },
                        e: function(e) {
                            throw e;
                        },
                        f: i
                    };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            var o, a = !0, c = !1;
            return {
                s: function() {
                    n = n.call(e);
                },
                n: function() {
                    var e = n.next();
                    return a = e.done, e;
                },
                e: function(e) {
                    c = !0, o = e;
                },
                f: function() {
                    try {
                        a || null == n.return || n.return();
                    } finally {
                        if (c) throw o;
                    }
                }
            };
        }
        function Q(e, t) {
            if (e) {
                if ("string" === typeof e) return G(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? G(e, t) : void 0;
            }
        }
        function G(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }
        function J(e) {
            var t = Y();
            return function() {
                var n, r = b(e);
                if (t) {
                    var i = b(this).constructor;
                    n = Reflect.construct(r, arguments, i);
                } else n = r.apply(this, arguments);
                return v(this, n);
            };
        }
        function Y() {
            if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" === typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                !0;
            } catch (e) {
                return !1;
            }
        }
        function K(e, t, n) {
            Object.defineProperty(e, t, {
                enumerable: !0,
                configurable: !0,
                get: function() {
                    return "props" === n ? e.props : Object.assign(Object.assign({}, e.state), e.props);
                }
            });
        }
        function Z(e) {
            return "function" === typeof e;
        }
        function X(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return "object" === g(e) && 0 === Object.keys(e).length && x("withWeapp 请传入“App/页面/组件“的配置对象。如果原生写法使用了基类，请将基类组合后的配置对象传入，详情请参考文档。"), 
            function(n) {
                var r, i = new Map([ [ "properties", [] ], [ "data", [] ], [ "methods", [] ], [ "created", [] ], [ "attached", [] ], [ "ready", [] ], [ "detached", [] ] ]), o = {};
                if (null === (r = e.behaviors) || void 0 === r ? void 0 : r.length) {
                    var v = e.behaviors;
                    v.forEach(function(e) {
                        return I(e, i);
                    });
                    var j = i.get("properties");
                    j.length && (j.forEach(function(e) {
                        Object.assign(o, e);
                    }), Object.keys(o).forEach(function(t) {
                        var n = o[t];
                        e.properties || (e.properties = {}), e.properties.hasOwnProperty(t) || (n && "object" === g(n) && n.value && (n.value = $(n.value)), 
                        e.properties[t] = n);
                    }));
                }
                var k = function(r) {
                    p(v, r);
                    var c = J(v);
                    function v(t) {
                        var n;
                        return l(this, v), n = c.call(this, t), n._observeProps = [], n.willMounts = [], 
                        n.didMounts = [], n.didHides = [], n.didShows = [], n.willUnmounts = [], n.eventDistoryList = [], 
                        n.current = y.getCurrentInstance(), n.taroGlobalData = Object.create(null), n.safeExecute = function(e) {
                            for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) r[i - 1] = arguments[i];
                            Z(e) && e.apply(f(n), r);
                        }, n.setData = function(e, t) {
                            var r;
                            n.observers && Object.keys(Object.keys(n.observers)) && (r = $(n.state)), Object.keys(e).forEach(function(t) {
                                P(n.state, t, e[t]);
                            }), n.setState(n.state, function() {
                                n.triggerObservers(n.state, r), t && t.call(f(n));
                            });
                        }, n.triggerEvent = function(e, t, r) {
                            r && x("triggerEvent 不支持事件选项。");
                            var i = n.props, o = {};
                            for (var a in i) a.startsWith("data-") && (o[a.replace(/^data-/, "")] = i[a]);
                            var c = i["on".concat(e[0].toUpperCase()).concat(e.slice(1))];
                            Z(c) && c.call(f(n), {
                                type: e,
                                detail: t,
                                target: {
                                    id: i.id || "",
                                    dataset: o
                                },
                                currentTarget: {
                                    id: i.id || "",
                                    dataset: o
                                }
                            });
                        }, n.hasBehavior = n.componentMethodsProxy("hasBehavior"), n.createSelectorQuery = n.componentMethodsProxy("createSelectorQuery"), 
                        n.createIntersectionObserver = n.componentMethodsProxy("createIntersectionObserver"), 
                        n.createMediaQueryObserver = n.componentMethodsProxy("createMediaQueryObserver"), 
                        n.getRelationNodes = n.componentMethodsProxy("getRelationNodes"), n.getTabBar = n.componentMethodsProxy("getTabBar"), 
                        n.getPageId = n.componentMethodsProxy("getPageId"), n.animate = n.componentMethodsProxy("animate"), 
                        n.clearAnimation = n.componentMethodsProxy("clearAnimation"), n.setUpdatePerformanceListener = n.componentMethodsProxy("setUpdatePerformanceListener"), 
                        n.state = n.state || {}, n.init(e), K(f(n), "data", "state"), K(f(n), "properties", "props"), 
                        n;
                    }
                    return d(v, [ {
                        key: "initProps",
                        value: function(e) {
                            for (var t in e) if (e.hasOwnProperty(t)) {
                                var n = e[t];
                                n && !Z(n) && n.observer && this._observeProps.push({
                                    name: t,
                                    observer: n.observer
                                });
                            }
                        }
                    }, {
                        key: "init",
                        value: function(e) {
                            var r, a, c, l = this;
                            if (null === (r = e.behaviors) || void 0 === r ? void 0 : r.length) {
                                var d, f = V(i.entries());
                                try {
                                    var h = function() {
                                        var e = s(d.value, 2), t = e[0], n = e[1];
                                        switch (t) {
                                          case "created":
                                          case "attached":
                                          case "detached":
                                          case "ready":
                                            n.forEach(function(e) {
                                                return l.initLifeCycles(t, e);
                                            });
                                            break;
                                        }
                                    };
                                    for (f.s(); !(d = f.n()).done; ) h();
                                } catch (e) {
                                    f.e(e);
                                } finally {
                                    f.f();
                                }
                            }
                            for (var p in e) {
                                if (A.has(p)) {
                                    var v = A.get(p);
                                    x(v);
                                }
                                var b = e[p];
                                switch (p) {
                                  case "behaviors":
                                    break;

                                  case "data":
                                    t ? (this[p] = b, T.includes(p) || this.defineProperty(this.taroGlobalData, p, this)) : this.state = Object.assign(Object.assign({}, b), this.state);
                                    break;

                                  case "properties":
                                    this.initProps(Object.assign(o, b));
                                    break;

                                  case "methods":
                                    for (var m in b) {
                                        var y = b[m];
                                        this[m] = C(y, this);
                                    }
                                    break;

                                  case "lifetimes":
                                    for (var O in b) this.initLifeCycles(O, b[O]);
                                    break;

                                  case "pageLifetimes":
                                    for (var j in b) {
                                        var k = b[j];
                                        switch (j) {
                                          case "show":
                                            this.initLifeCycleListener("show", k);
                                            break;

                                          case "hide":
                                            this.initLifeCycleListener("hide", k);
                                            break;

                                          case "resize":
                                            x("不支持组件所在页面的生命周期 pageLifetimes.resize。");
                                            break;
                                        }
                                    }
                                    break;

                                  default:
                                    if (w.has(p)) {
                                        if (null === (a = e.lifetimes) || void 0 === a ? void 0 : a[p]) break;
                                        var S = e[p];
                                        this.initLifeCycles(p, S);
                                    } else Z(b) ? (this[p] = C(b, this), t && !T.includes(p) && this.defineProperty(this.taroGlobalData, p, this), 
                                    E.includes(p) && n.prototype[p] && x("生命周期 ".concat(p, " 已在原生部分进行定义，React 部分的定义将不会被执行。"))) : (this[p] = b, 
                                    t && !T.includes(p) && this.defineProperty(this.taroGlobalData, p, this));
                                    break;
                                }
                            }
                            (null === (c = e.behaviors) || void 0 === c ? void 0 : c.length) && function() {
                                var e, t = {}, n = {}, r = V(i.entries());
                                try {
                                    var o = function() {
                                        var r = s(e.value, 2), i = r[0], o = r[1];
                                        switch (i) {
                                          case "data":
                                            [].concat(u(o), [ l.state ]).forEach(function(e, n) {
                                                Object.keys(e).forEach(function(r) {
                                                    var i = e[r], a = t[r], c = g(i), u = g(a);
                                                    if ("object" === c) if (i) if ("object" !== u || !u || Array.isArray(i)) t[r] = n === o.length ? i : $(i); else {
                                                        var s = Object.assign({}, a, i);
                                                        t[r] = n === o.length ? s : $(s);
                                                    } else t[r] = i; else t[r] = i;
                                                });
                                            }), l.state = t;
                                            break;

                                          case "methods":
                                            o.forEach(function(e) {
                                                Object.assign(n, e);
                                            }), Object.keys(n).forEach(function(e) {
                                                if (!l[e]) {
                                                    var t = n[e];
                                                    l[e] = C(t, l);
                                                }
                                            });
                                            break;

                                          default:
                                            break;
                                        }
                                    };
                                    for (r.s(); !(e = r.n()).done; ) o();
                                } catch (e) {
                                    r.e(e);
                                } finally {
                                    r.f();
                                }
                            }();
                        }
                    }, {
                        key: "initLifeCycles",
                        value: function(e, t) {
                            if (A.has(e)) {
                                var n = A.get(e);
                                return x(n);
                            }
                            if ("ready" === e) this.current.page.onReady.called ? this.didMounts.push(function() {
                                for (var e = this, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                                m.nextTick(function() {
                                    Z(t) && t.apply(e, r);
                                });
                            }) : this.initLifeCycleListener("ready", t); else for (var r in O) {
                                var i = O[r];
                                if (-1 !== i.indexOf(e)) switch (r) {
                                  case a.DidHide:
                                    this.didHides.push(t);
                                    break;

                                  case a.DidMount:
                                    this.didMounts.push(t);
                                    break;

                                  case a.DidShow:
                                    this.didShows.push(t);
                                    break;

                                  case a.WillMount:
                                    this.willMounts.push(t);
                                    break;

                                  case a.WillUnmount:
                                    this.willUnmounts.push(t);
                                    break;
                                }
                            }
                            Z(this[e]) || (this[e] = t);
                        }
                    }, {
                        key: "initLifeCycleListener",
                        value: function(e, t) {
                            var n = this.current.router, r = "on".concat(e[0].toUpperCase()).concat(e.slice(1));
                            t = t.bind(this), (null === n || void 0 === n ? void 0 : n[r]) && m.eventCenter.on(n[r], t), 
                            this.eventDistoryList.push(function() {
                                return m.eventCenter.off(n[r], t);
                            });
                        }
                    }, {
                        key: "executeLifeCycles",
                        value: function(e) {
                            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                            for (var i = 0; i < e.length; i++) {
                                var o = e[i];
                                this.safeExecute.apply(this, [ o ].concat(n));
                            }
                        }
                    }, {
                        key: "triggerPropertiesObservers",
                        value: function(e, t) {
                            var n = this;
                            this._observeProps.forEach(function(r) {
                                var i = r.name, o = r.observer, a = null === e || void 0 === e ? void 0 : e[i], c = t[i];
                                if (!S(a, c)) if ("string" === typeof o) {
                                    var u = n[o];
                                    Z(u) && u.call(n, c, a, i);
                                } else Z(o) && o.call(n, c, a, i);
                            });
                        }
                    }, {
                        key: "triggerObservers",
                        value: function(e, t) {
                            var n = this.observers;
                            if (null != n && 0 !== Object.keys(n).length) {
                                var r = F(e, t), i = Object.keys(r);
                                if (0 !== i.length) for (var o in n) if (/\*\*/.test(o)) x("数据监听器 observers 不支持使用通配符 **。"); else {
                                    for (var a = o.split(",").map(function(e) {
                                        return e.trim();
                                    }), c = !1, u = 0; u < a.length; u++) for (var s = a[u], l = 0; l < i.length; l++) {
                                        var d = i[l];
                                        (d.startsWith(s) || s.startsWith(d) && s.endsWith("]")) && (c = !0);
                                    }
                                    c && n[o].apply(this, a.map(function(t) {
                                        return _(e, t);
                                    }));
                                }
                            }
                        }
                    }, {
                        key: "defineProperty",
                        value: function(e, t, n) {
                            Object.defineProperty(e, t, {
                                configurable: !0,
                                enumerable: !0,
                                set: function(e) {
                                    n[t] = e;
                                },
                                get: function() {
                                    return n[t];
                                }
                            });
                        }
                    }, {
                        key: "privateStopNoop",
                        value: function() {
                            var e, t;
                            2 === arguments.length ? (t = arguments.length <= 0 ? void 0 : arguments[0], e = arguments.length <= 1 ? void 0 : arguments[1]) : 1 === arguments.length && (e = arguments.length <= 0 ? void 0 : arguments[0]), 
                            "touchmove" === e.type && x("catchtouchmove 转换后只能停止回调函数的冒泡，不能阻止滚动穿透。如要阻止滚动穿透，可以手动给编译后的 View 组件加上 catchMove 属性"), 
                            e.stopPropagation(), Z(t) && t(e);
                        }
                    }, {
                        key: "componentWillMount",
                        value: function() {
                            this.safeExecute(h(b(v.prototype), "componentWillMount", this)), this.executeLifeCycles(this.willMounts, this.current.router || {}), 
                            this.triggerObservers(this.data, v.defaultProps), this.triggerPropertiesObservers(v.defaultProps, this.props);
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            this.safeExecute(h(b(v.prototype), "componentDidMount", this)), this.executeLifeCycles(this.didMounts);
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.eventDistoryList.forEach(function(e) {
                                return e();
                            }), this.safeExecute(h(b(v.prototype), "componentWillUnmount", this)), this.executeLifeCycles(this.willUnmounts);
                        }
                    }, {
                        key: "componentDidHide",
                        value: function() {
                            this.safeExecute(h(b(v.prototype), "componentDidHide", this)), this.executeLifeCycles(this.didHides);
                        }
                    }, {
                        key: "componentDidShow",
                        value: function() {
                            this.safeExecute(h(b(v.prototype), "componentDidShow", this), this.current.router || {}), 
                            this.executeLifeCycles(this.didShows, this.current.router || {});
                        }
                    }, {
                        key: "componentWillReceiveProps",
                        value: function(e) {
                            this.triggerObservers(e, this.props), this.triggerPropertiesObservers(this.props, e), 
                            this.safeExecute(h(b(v.prototype), "componentWillReceiveProps", this));
                        }
                    }, {
                        key: "is",
                        get: function() {
                            return this.current.page.is;
                        }
                    }, {
                        key: "id",
                        get: function() {
                            return this.current.page.id;
                        }
                    }, {
                        key: "dataset",
                        get: function() {
                            return this.current.page.dataset;
                        }
                    }, {
                        key: "componentMethodsProxy",
                        value: function(e) {
                            var t = this;
                            return function() {
                                var n = t.current.page;
                                if (null === n || void 0 === n ? void 0 : n[e]) return n[e].apply(n, arguments);
                                console.error("page 下没有 ".concat(e, " 方法"));
                            };
                        }
                    }, {
                        key: "selectComponent",
                        value: function() {
                            x(A.get("selectComponent"));
                        }
                    }, {
                        key: "selectAllComponents",
                        value: function() {
                            x(A.get("selectAllComponents"));
                        }
                    }, {
                        key: "selectOwnerComponent",
                        value: function() {
                            x(A.get("selectOwnerComponent"));
                        }
                    }, {
                        key: "groupSetData",
                        value: function() {
                            x(A.get("groupSetData"));
                        }
                    } ]), v;
                }(n), L = e.properties;
                if (L) for (var N in L) {
                    var R = L[N];
                    null == R || Z(R) || void 0 !== R.value && (k.defaultProps = Object.assign(c({}, N, R.value), k.defaultProps));
                }
                var M = [ "externalClasses", "relations", "options" ];
                return M.forEach(function(t) {
                    var n = e[t];
                    null != n && (k[t] = n);
                }), k;
            };
        }
        t.default = X;
    },
    295: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n(7);
        Component(Object(r["createRecursiveComponentConfig"])());
    },
    296: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = n(7);
        Component(r.createRecursiveComponentConfig("custom-wrapper"));
    },
    4: function(e, t, n) {
        var r = n(7), i = r.container, o = r.SERVICE_IDENTIFIER, a = n(168).default, c = i.get(o.Hooks);
        "function" === typeof c.initNativeApi && c.initNativeApi(a), e.exports = a, e.exports.default = e.exports;
    },
    6: function(e, t, n) {
        "use strict";
        var r = n(82), i = n(21);
        function o(e) {
            return "string" === typeof e;
        }
        function a(e) {
            return "undefined" === typeof e;
        }
        function c(e) {
            return null === e;
        }
        function u(e) {
            return null !== e && "object" === i(e);
        }
        function s(e) {
            return !0 === e || !1 === e;
        }
        function l(e) {
            return "function" === typeof e;
        }
        function d(e) {
            return "number" === typeof e;
        }
        function f(e) {
            return "true" === e || "false" === e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var h = Array.isArray;
        (function(e) {
            e["Container"] = "container", e["Childnodes"] = "cn", e["Text"] = "v", e["NodeType"] = "nt", 
            e["NodeName"] = "nn", e["Style"] = "st", e["Class"] = "cl", e["Src"] = "src";
        })(t.Shortcuts || (t.Shortcuts = {}));
        var p = {
            style: "i.".concat("st"),
            class: "i.".concat("cl")
        }, v = {
            bindtap: "eh"
        }, b = {
            bindTouchStart: "",
            bindTouchMove: "",
            bindTouchEnd: "",
            bindTouchCancel: "",
            bindLongTap: ""
        }, g = {
            bindAnimationStart: "",
            bindAnimationIteration: "",
            bindAnimationEnd: "",
            bindTransitionEnd: ""
        };
        function m(e) {
            return "'".concat(e, "'");
        }
        var y = Object.assign(Object.assign({
            "hover-class": m("none"),
            "hover-stop-propagation": "false",
            "hover-start-time": "50",
            "hover-stay-time": "400",
            animation: ""
        }, b), g), O = {
            type: "",
            size: "23",
            color: ""
        }, w = Object.assign({
            longitude: "",
            latitude: "",
            scale: "16",
            markers: "[]",
            covers: "",
            polyline: "[]",
            circles: "[]",
            controls: "[]",
            "include-points": "[]",
            "show-location": "",
            "layer-style": "1",
            bindMarkerTap: "",
            bindControlTap: "",
            bindCalloutTap: "",
            bindUpdated: ""
        }, b), j = {
            percent: "",
            "stroke-width": "6",
            color: m("#09BB07"),
            activeColor: m("#09BB07"),
            backgroundColor: m("#EBEBEB"),
            active: "false",
            "active-mode": m("backwards"),
            "show-info": "false"
        }, k = {
            nodes: "[]"
        }, E = {
            selectable: "false",
            space: "",
            decode: "false"
        }, T = {
            size: m("default"),
            type: "",
            plain: "false",
            disabled: "",
            loading: "false",
            "form-type": "",
            "open-type": "",
            "hover-class": m("button-hover"),
            "hover-stop-propagation": "false",
            "hover-start-time": "20",
            "hover-stay-time": "70",
            name: ""
        }, C = {
            value: "",
            disabled: "",
            checked: "false",
            color: m("#09BB07"),
            name: ""
        }, S = {
            bindChange: "",
            name: ""
        }, _ = {
            "report-submit": "false",
            bindSubmit: "",
            bindReset: "",
            name: ""
        }, P = {
            value: "",
            type: m(""),
            password: "false",
            placeholder: "",
            "placeholder-style": "",
            "placeholder-class": m("input-placeholder"),
            disabled: "",
            maxlength: "140",
            "cursor-spacing": "0",
            focus: "false",
            "confirm-type": m("done"),
            "confirm-hold": "false",
            cursor: "i.value.length",
            "selection-start": "-1",
            "selection-end": "-1",
            bindInput: "",
            bindFocus: "",
            bindBlur: "",
            bindConfirm: "",
            name: ""
        }, x = {
            for: "",
            name: ""
        }, A = {
            mode: m("selector"),
            disabled: "",
            range: "",
            "range-key": "",
            value: "",
            start: "",
            end: "",
            fields: m("day"),
            "custom-item": "",
            name: "",
            bindCancel: "",
            bindChange: "",
            bindColumnChange: ""
        }, I = {
            value: "",
            "indicator-style": "",
            "indicator-class": "",
            "mask-style": "",
            "mask-class": "",
            bindChange: "",
            name: ""
        }, L = {
            name: ""
        }, N = {
            value: "",
            checked: "false",
            disabled: "",
            color: m("#09BB07"),
            name: ""
        }, R = {
            bindChange: "",
            name: ""
        }, F = {
            min: "0",
            max: "100",
            step: "1",
            disabled: "",
            value: "0",
            activeColor: m("#1aad19"),
            backgroundColor: m("#e9e9e9"),
            "block-size": "28",
            "block-color": m("#ffffff"),
            "show-value": "false",
            bindChange: "",
            bindChanging: "",
            name: ""
        }, M = {
            checked: "false",
            disabled: "",
            type: m("switch"),
            color: m("#04BE02"),
            bindChange: "",
            name: ""
        }, B = {
            value: "",
            placeholder: "",
            "placeholder-style": "",
            "placeholder-class": m("textarea-placeholder"),
            disabled: "",
            maxlength: "140",
            "auto-focus": "false",
            focus: "false",
            "auto-height": "false",
            fixed: "false",
            "cursor-spacing": "0",
            cursor: "-1",
            "selection-start": "-1",
            "selection-end": "-1",
            bindFocus: "",
            bindBlur: "",
            bindLineChange: "",
            bindInput: "",
            bindConfirm: "",
            name: ""
        }, D = {
            src: "",
            bindLoad: "eh",
            bindError: "eh"
        }, U = Object.assign({
            "scroll-top": "false"
        }, b), H = {
            "scale-area": "false"
        }, $ = Object.assign(Object.assign({
            direction: "none",
            inertia: "false",
            "out-of-bounds": "false",
            x: "",
            y: "",
            damping: "20",
            friction: "2",
            disabled: "",
            scale: "false",
            "scale-min": "0.5",
            "scale-max": "10",
            "scale-value": "1",
            animation: "true",
            bindChange: "",
            bindScale: "",
            bindHTouchMove: "",
            bindVTouchMove: "",
            width: m("10px"),
            height: m("10px")
        }, b), g), W = Object.assign(Object.assign({
            "scroll-x": "false",
            "scroll-y": "false",
            "upper-threshold": "50",
            "lower-threshold": "50",
            "scroll-top": "",
            "scroll-left": "",
            "scroll-into-view": "",
            "scroll-with-animation": "false",
            "enable-back-to-top": "false",
            bindScrollToUpper: "",
            bindScrollToLower: "",
            bindScroll: ""
        }, b), g), z = Object.assign({
            "indicator-dots": "false",
            "indicator-color": m("rgba(0, 0, 0, .3)"),
            "indicator-active-color": m("#000000"),
            autoplay: "false",
            current: "0",
            interval: "5000",
            duration: "500",
            circular: "false",
            vertical: "false",
            "previous-margin": "'0px'",
            "next-margin": "'0px'",
            "display-multiple-items": "1",
            bindChange: "",
            bindTransition: "",
            bindAnimationFinish: ""
        }, b), q = {
            "item-id": ""
        }, V = {
            url: "",
            "open-type": m("navigate"),
            delta: "1",
            "hover-class": m("navigator-hover"),
            "hover-stop-propagation": "false",
            "hover-start-time": "50",
            "hover-stay-time": "600",
            bindSuccess: "",
            bindFail: "",
            bindComplete: ""
        }, Q = {
            id: "",
            src: "",
            loop: "false",
            controls: "false",
            poster: "",
            name: "",
            author: "",
            bindError: "",
            bindPlay: "",
            bindPause: "",
            bindTimeUpdate: "",
            bindEnded: ""
        }, G = {
            "device-position": m("back"),
            flash: m("auto"),
            bindStop: "",
            bindError: ""
        }, J = Object.assign({
            src: "",
            mode: m("scaleToFill"),
            "lazy-load": "false",
            bindError: "",
            bindLoad: ""
        }, b), Y = {
            src: "",
            autoplay: "false",
            muted: "false",
            orientation: m("vertical"),
            "object-fit": m("contain"),
            "background-mute": "false",
            "min-cache": "1",
            "max-cache": "3",
            animation: "",
            bindStateChange: "",
            bindFullScreenChange: "",
            bindNetStatus: ""
        }, K = {
            src: "",
            duration: "",
            controls: "true",
            "danmu-list": "",
            "danmu-btn": "",
            "enable-danmu": "",
            autoplay: "false",
            loop: "false",
            muted: "false",
            "initial-time": "0",
            "page-gesture": "false",
            direction: "",
            "show-progress": "true",
            "show-fullscreen-btn": "true",
            "show-play-btn": "true",
            "show-center-play-btn": "true",
            "enable-progress-gesture": "true",
            "object-fit": m("contain"),
            poster: "",
            "show-mute-btn": "false",
            animation: "",
            bindPlay: "",
            bindPause: "",
            bindEnded: "",
            bindTimeUpdate: "",
            bindFullScreenChange: "",
            bindWaiting: "",
            bindError: ""
        }, Z = Object.assign({
            "canvas-id": "",
            "disable-scroll": "false",
            bindError: ""
        }, b), X = {
            "unit-id": "",
            "ad-intervals": "",
            bindLoad: "",
            bindError: "",
            bindClose: ""
        }, ee = {
            src: "",
            bindMessage: "",
            bindLoad: "",
            bindError: ""
        }, te = {}, ne = {
            name: ""
        }, re = {
            name: ""
        }, ie = {
            View: y,
            Icon: O,
            Progress: j,
            RichText: k,
            Text: E,
            Button: T,
            Checkbox: C,
            CheckboxGroup: S,
            Form: _,
            Input: P,
            Label: x,
            Picker: A,
            PickerView: I,
            PickerViewColumn: L,
            Radio: N,
            RadioGroup: R,
            Slider: F,
            Switch: M,
            CoverImage: D,
            Textarea: B,
            CoverView: U,
            MovableArea: H,
            MovableView: $,
            ScrollView: W,
            Swiper: z,
            SwiperItem: q,
            Navigator: V,
            Audio: Q,
            Camera: G,
            Image: J,
            LivePlayer: Y,
            Video: K,
            Canvas: Z,
            Ad: X,
            WebView: ee,
            Block: te,
            Map: w,
            Slot: re,
            SlotView: ne
        }, oe = new Set([ "input", "checkbox", "picker", "picker-view", "radio", "slider", "switch", "textarea" ]), ae = new Set([ "input", "textarea" ]), ce = new Set([ "progress", "icon", "rich-text", "input", "textarea", "slider", "switch", "audio", "ad", "official-account", "open-data", "navigation-bar" ]), ue = new Map([ [ "view", -1 ], [ "catch-view", -1 ], [ "cover-view", -1 ], [ "static-view", -1 ], [ "pure-view", -1 ], [ "block", -1 ], [ "text", -1 ], [ "static-text", 6 ], [ "slot", 8 ], [ "slot-view", 8 ], [ "label", 6 ], [ "form", 4 ], [ "scroll-view", 4 ], [ "swiper", 4 ], [ "swiper-item", 4 ] ]), se = {}, le = [], de = function() {}, fe = Object.create(null), he = function(e) {
            return {
                v: e
            };
        }, pe = function(e) {
            return e.v;
        };
        function ve(e) {
            return e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
        }
        function be(e) {
            for (var t = "", n = !1, r = 0; r < e.length; r++) "-" !== e[r] ? (t += n ? e[r].toUpperCase() : e[r], 
            n = !1) : n = !0;
            return t;
        }
        var ge = function(e) {
            return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
        };
        function me(e) {
            return e.charAt(0).toUpperCase() + e.slice(1);
        }
        var ye = Object.prototype.hasOwnProperty, Oe = function(e, t) {
            return ye.call(e, t);
        }, we = "如有疑问，请提交 issue 至：https://github.com/nervjs/taro/issues";
        function je(e, t) {
            if (!e) throw new Error(t + "\n" + we);
        }
        function ke(e, t) {
            0;
        }
        function Ee(e) {
            for (var t, n, r, i = decodeURIComponent, o = e.split("&"), a = {}, c = 0, u = o.length; c < u; ++c) if (r = o[c], 
            r.length) {
                var s = r.indexOf("=");
                s < 0 ? (t = i(r), n = "") : (t = i(r.slice(0, s)), n = i(r.slice(s + 1))), "string" === typeof a[t] && (a[t] = [ a[t] ]), 
                Array.isArray(a[t]) ? a[t].push(n) : a[t] = n;
            }
            return a;
        }
        var Te = 1, Ce = new Date().getTime().toString();
        function Se() {
            return Ce + Te++;
        }
        var _e = {};
        function Pe(e, t) {
            _e[e] = t;
        }
        function xe(e, t) {
            var n = _e[e];
            return t && delete _e[e], n;
        }
        function Ae(e) {
            return e in _e;
        }
        function Ie(e) {
            Object.keys(e).forEach(function(t) {
                t in ie ? Object.assign(ie[t], e[t]) : ie[t] = e[t];
            });
        }
        function Le(e) {
            Object.keys(e).forEach(function(t) {
                var n = e[t], r = fe[t];
                r ? h(r) ? fe[t] = r.push(n) : fe[t] = [ r, n ] : fe[t] = n;
            });
        }
        function Ne(e) {
            return function() {
                console.warn("小程序暂不支持 ".concat(e));
            };
        }
        function Re(e, t) {
            var n = "__key_", r = [ "navigateTo", "redirectTo", "reLaunch", "switchTab" ];
            if (r.indexOf(e) > -1) {
                var i = t.url = t.url || "", o = i.indexOf("?") > -1, a = Se();
                t.url += (o ? "&" : "?") + "".concat(n, "=").concat(a);
            }
        }
        function Fe(e, t) {
            return e.split("\n").map(function(e, n) {
                var r = 0 === n ? "" : Array(t).fill(" ").join("");
                return r + e;
            }).join("\n");
        }
        var Me = new Set([ "addPhoneContact", "authorize", "canvasGetImageData", "canvasPutImageData", "canvasToTempFilePath", "checkSession", "chooseAddress", "chooseImage", "chooseInvoiceTitle", "chooseLocation", "chooseVideo", "clearStorage", "closeBLEConnection", "closeBluetoothAdapter", "closeSocket", "compressImage", "connectSocket", "createBLEConnection", "downloadFile", "getAvailableAudioSources", "getBLEDeviceCharacteristics", "getBLEDeviceServices", "getBatteryInfo", "getBeacons", "getBluetoothAdapterState", "getBluetoothDevices", "getClipboardData", "getConnectedBluetoothDevices", "getConnectedWifi", "getExtConfig", "getFileInfo", "getImageInfo", "getLocation", "getNetworkType", "getSavedFileInfo", "getSavedFileList", "getScreenBrightness", "getSetting", "getStorage", "getStorageInfo", "getSystemInfo", "getUserInfo", "getWifiList", "hideHomeButton", "hideShareMenu", "hideTabBar", "hideTabBarRedDot", "loadFontFace", "login", "makePhoneCall", "navigateBack", "navigateBackMiniProgram", "navigateTo", "navigateToBookshelf", "navigateToMiniProgram", "notifyBLECharacteristicValueChange", "hideKeyboard", "hideLoading", "hideNavigationBarLoading", "hideToast", "openBluetoothAdapter", "openDocument", "openLocation", "openSetting", "pageScrollTo", "previewImage", "queryBookshelf", "reLaunch", "readBLECharacteristicValue", "redirectTo", "removeSavedFile", "removeStorage", "removeTabBarBadge", "requestSubscribeMessage", "saveFile", "saveImageToPhotosAlbum", "saveVideoToPhotosAlbum", "scanCode", "sendSocketMessage", "setBackgroundColor", "setBackgroundTextStyle", "setClipboardData", "setEnableDebug", "setInnerAudioOption", "setKeepScreenOn", "setNavigationBarColor", "setNavigationBarTitle", "setScreenBrightness", "setStorage", "setTabBarBadge", "setTabBarItem", "setTabBarStyle", "showActionSheet", "showFavoriteGuide", "showLoading", "showModal", "showShareMenu", "showTabBar", "showTabBarRedDot", "showToast", "startBeaconDiscovery", "startBluetoothDevicesDiscovery", "startDeviceMotionListening", "startPullDownRefresh", "stopBeaconDiscovery", "stopBluetoothDevicesDiscovery", "stopCompass", "startCompass", "startAccelerometer", "stopAccelerometer", "showNavigationBarLoading", "stopDeviceMotionListening", "stopPullDownRefresh", "switchTab", "uploadFile", "vibrateLong", "vibrateShort", "writeBLECharacteristicValue" ]);
        function Be(e) {
            return function() {
                if ("function" !== typeof e.getSystemInfoSync) return console.error("不支持 API canIUseWebp"), 
                !1;
                var t = e.getSystemInfoSync(), n = t.platform, r = n.toLowerCase();
                return "android" === r || "devtools" === r;
            };
        }
        function De(e) {
            return function(t) {
                t = t || {}, "string" === typeof t && (t = {
                    url: t
                });
                var n, r = t.success, i = t.fail, o = t.complete, a = new Promise(function(a, c) {
                    t.success = function(e) {
                        r && r(e), a(e);
                    }, t.fail = function(e) {
                        i && i(e), c(e);
                    }, t.complete = function(e) {
                        o && o(e);
                    }, n = e.request(t);
                });
                return a.abort = function(e) {
                    return e && e(), n && n.abort(), a;
                }, a;
            };
        }
        function Ue(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, i = n.needPromiseApis || [], o = new Set([].concat(r(i), r(Me))), a = [ "getEnv", "interceptors", "Current", "getCurrentInstance", "options", "nextTick", "eventCenter", "Events", "preload", "webpackJsonp" ], c = new Set(Object.keys(t).filter(function(e) {
                return -1 === a.indexOf(e);
            }));
            n.modifyApis && n.modifyApis(c), c.forEach(function(r) {
                if (o.has(r)) {
                    var i = r;
                    e[i] = function() {
                        for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), a = 1; a < r; a++) o[a - 1] = arguments[a];
                        var c = i;
                        if ("string" === typeof e) return o.length ? t[c].apply(t, [ e ].concat(o)) : t[c](e);
                        if (n.transformMeta) {
                            var u = n.transformMeta(c, e);
                            if (c = u.key, e = u.options, !t.hasOwnProperty(c)) return Ne(c)();
                        }
                        var s = null, l = Object.assign({}, e);
                        Re(c, e);
                        var d = new Promise(function(r, i) {
                            l.success = function(t) {
                                var i, o;
                                null === (i = n.modifyAsyncResult) || void 0 === i || i.call(n, c, t), null === (o = e.success) || void 0 === o || o.call(e, t), 
                                r("connectSocket" === c ? Promise.resolve().then(function() {
                                    return s ? Object.assign(s, t) : t;
                                }) : t);
                            }, l.fail = function(t) {
                                var n;
                                null === (n = e.fail) || void 0 === n || n.call(e, t), i(t);
                            }, l.complete = function(t) {
                                var n;
                                null === (n = e.complete) || void 0 === n || n.call(e, t);
                            }, s = o.length ? t[c].apply(t, [ l ].concat(o)) : t[c](l);
                        });
                        return "uploadFile" !== c && "downloadFile" !== c || (d.progress = function(e) {
                            return null === s || void 0 === s || s.onProgressUpdate(e), d;
                        }, d.abort = function(e) {
                            return null === e || void 0 === e || e(), null === s || void 0 === s || s.abort(), 
                            d;
                        }), d;
                    };
                } else {
                    var a = r;
                    if (n.transformMeta && (a = n.transformMeta(r, {}).key), !t.hasOwnProperty(a)) return void (e[r] = Ne(r));
                    "function" === typeof t[r] ? e[r] = function() {
                        for (var e = arguments.length, i = new Array(e), o = 0; o < e; o++) i[o] = arguments[o];
                        return n.handleSyncApis ? n.handleSyncApis(r, t, i) : t[a].apply(t, i);
                    } : e[r] = t[a];
                }
            }), !n.isOnlyPromisify && He(e, t, n);
        }
        function He(e, t) {
            var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            e.canIUseWebp = Be(e), e.getCurrentPages = getCurrentPages || Ne("getCurrentPages"), 
            e.getApp = getApp || Ne("getApp"), e.env = t.env || {};
            try {
                e.requirePlugin = requirePlugin || Ne("requirePlugin");
            } catch (t) {
                e.requirePlugin = Ne("requirePlugin");
            }
            var r = n.request ? n.request : De(t);
            function i(e) {
                return r(e.requestParams);
            }
            var o = new e.Link(i);
            e.request = o.request.bind(o), e.addInterceptor = o.addInterceptor.bind(o), e.cleanInterceptors = o.cleanInterceptors.bind(o), 
            e.miniGlobal = e.options.miniGlobal = t;
        }
        t.EMPTY_ARR = le, t.EMPTY_OBJ = se, t.animationEvents = g, t.box = he, t.cacheDataGet = xe, 
        t.cacheDataHas = Ae, t.cacheDataSet = Pe, t.capitalize = me, t.controlledComponent = oe, 
        t.defaultReconciler = fe, t.ensure = je, t.events = v, t.focusComponents = ae, t.getUniqueKey = Se, 
        t.hasOwn = Oe, t.indent = Fe, t.internalComponents = ie, t.isArray = h, t.isBoolean = s, 
        t.isBooleanStringLiteral = f, t.isFunction = l, t.isNull = c, t.isNumber = d, t.isObject = u, 
        t.isString = o, t.isUndefined = a, t.mergeInternalComponents = Ie, t.mergeReconciler = Le, 
        t.nestElements = ue, t.noop = de, t.processApis = Ue, t.queryToJson = Ee, t.setUniqueKeyToRoute = Re, 
        t.singleQuote = m, t.styles = p, t.toCamelCase = be, t.toDashed = ve, t.toKebabCase = ge, 
        t.touchEvents = b, t.unbox = pe, t.unsupport = Ne, t.voidElements = ce, t.warn = ke;
    },
    7: function(e, t, n) {
        "use strict";
        n.r(t), function(e, r, i, o, a, c) {
            n.d(t, "Current", function() {
                return yi;
            }), n.d(t, "ElementNames", function() {
                return ke;
            }), n.d(t, "Events", function() {
                return wi;
            }), n.d(t, "FormElement", function() {
                return Qn;
            }), n.d(t, "SERVICE_IDENTIFIER", function() {
                return x;
            }), n.d(t, "Style", function() {
                return Ge;
            }), n.d(t, "TaroElement", function() {
                return Xe;
            }), n.d(t, "TaroEvent", function() {
                return Xr;
            }), n.d(t, "TaroNode", function() {
                return Ce;
            }), n.d(t, "TaroRootElement", function() {
                return Vn;
            }), n.d(t, "TaroText", function() {
                return Se;
            }), n.d(t, "cancelAnimationFrame", function() {
                return vi;
            }), n.d(t, "connectReactPage", function() {
                return zi;
            }), n.d(t, "connectVuePage", function() {
                return Zi;
            }), n.d(t, "container", function() {
                return Jr;
            }), n.d(t, "createComponentConfig", function() {
                return Mi;
            }), n.d(t, "createDocument", function() {
                return ai;
            }), n.d(t, "createEvent", function() {
                return ei;
            }), n.d(t, "createNativeComponentConfig", function() {
                return Ki;
            }), n.d(t, "createPageConfig", function() {
                return Fi;
            }), n.d(t, "createReactApp", function() {
                return Qi;
            }), n.d(t, "createRecursiveComponentConfig", function() {
                return Bi;
            }), n.d(t, "createVue3App", function() {
                return ro;
            }), n.d(t, "createVueApp", function() {
                return eo;
            }), n.d(t, "document", function() {
                return ui;
            }), n.d(t, "eventCenter", function() {
                return ki;
            }), n.d(t, "getComputedStyle", function() {
                return bi;
            }), n.d(t, "getCurrentInstance", function() {
                return Oi;
            }), n.d(t, "hydrate", function() {
                return je;
            }), n.d(t, "injectPageInstance", function() {
                return Si;
            }), n.d(t, "navigator", function() {
                return fi;
            }), n.d(t, "nextTick", function() {
                return ko;
            }), n.d(t, "now", function() {
                return ci;
            }), n.d(t, "options", function() {
                return $n;
            }), n.d(t, "processPluginHooks", function() {
                return Gr;
            }), n.d(t, "requestAnimationFrame", function() {
                return pi;
            }), n.d(t, "stringify", function() {
                return Ai;
            }), n.d(t, "useAddToFavorites", function() {
                return mo;
            }), n.d(t, "useDidHide", function() {
                return ao;
            }), n.d(t, "useDidShow", function() {
                return oo;
            }), n.d(t, "useOptionMenuClick", function() {
                return vo;
            }), n.d(t, "usePageScroll", function() {
                return so;
            }), n.d(t, "usePullDownRefresh", function() {
                return co;
            }), n.d(t, "usePullIntercept", function() {
                return bo;
            }), n.d(t, "useReachBottom", function() {
                return uo;
            }), n.d(t, "useReady", function() {
                return yo;
            }), n.d(t, "useResize", function() {
                return lo;
            }), n.d(t, "useRouter", function() {
                return Oo;
            }), n.d(t, "useScope", function() {
                return wo;
            }), n.d(t, "useShareAppMessage", function() {
                return fo;
            }), n.d(t, "useShareTimeline", function() {
                return go;
            }), n.d(t, "useTabItemTap", function() {
                return ho;
            }), n.d(t, "useTitleClick", function() {
                return po;
            }), n.d(t, "window", function() {
                return gi;
            });
            var u = n(3), s = n(41), l = n.n(s), d = n(54), f = n(105), h = n(28), p = n(26), v = n(19), b = n(130), g = n(106), m = n(29), y = n(23), O = n(24), w = n(12), j = n(17), k = n(18), E = n(11), T = n(8), C = n(6);
            function S(e, t, n, r) {
                var i, o = arguments.length, a = o < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r;
                if ("object" === ("undefined" === typeof Reflect ? "undefined" : Object(E["a"])(Reflect)) && "function" === typeof Reflect.decorate) a = Reflect.decorate(e, t, n, r); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (a = (o < 3 ? i(a) : o > 3 ? i(t, n, a) : i(t, n)) || a);
                return o > 3 && a && Object.defineProperty(t, n, a), a;
            }
            function _(e, t) {
                return function(n, r) {
                    t(n, r, e);
                };
            }
            function P(e, t) {
                if ("object" === ("undefined" === typeof Reflect ? "undefined" : Object(E["a"])(Reflect)) && "function" === typeof Reflect.metadata) return Reflect.metadata(e, t);
            }
            (function(t) {
                (function(e) {
                    var n = r(t);
                    function r(e, t) {
                        return function(n, r) {
                            "function" !== typeof e[n] && Object.defineProperty(e, n, {
                                configurable: !0,
                                writable: !0,
                                value: r
                            }), t && t(n, r);
                        };
                    }
                    e(n);
                })(function(t) {
                    var n = Object.prototype.hasOwnProperty, r = "function" === typeof Symbol, i = r && "undefined" !== typeof Symbol.toPrimitive ? Symbol.toPrimitive : "@@toPrimitive", o = r && "undefined" !== typeof Symbol.iterator ? Symbol.iterator : "@@iterator", a = "function" === typeof Object.create, c = {
                        __proto__: []
                    } instanceof Array, u = !a && !c, s = {
                        create: a ? function() {
                            return ae(Object.create(null));
                        } : c ? function() {
                            return ae({
                                __proto__: null
                            });
                        } : function() {
                            return ae({});
                        },
                        has: u ? function(e, t) {
                            return n.call(e, t);
                        } : function(e, t) {
                            return t in e;
                        },
                        get: u ? function(e, t) {
                            return n.call(e, t) ? e[t] : void 0;
                        } : function(e, t) {
                            return e[t];
                        }
                    }, l = Object.getPrototypeOf(Function), d = "object" === ("undefined" === typeof e ? "undefined" : Object(E["a"])(e)) && e.env && "true" === e.env["REFLECT_METADATA_USE_MAP_POLYFILL"], f = d || "function" !== typeof Map || "function" !== typeof Map.prototype.entries ? re() : Map, h = d || "function" !== typeof Set || "function" !== typeof Set.prototype.entries ? ie() : Set, p = d || "function" !== typeof WeakMap ? oe() : WeakMap, v = new p();
                    function b(e, t, n, r) {
                        if (B(n)) {
                            if (!Q(e)) throw new TypeError();
                            if (!J(t)) throw new TypeError();
                            return S(e, t);
                        }
                        if (!Q(e)) throw new TypeError();
                        if (!H(t)) throw new TypeError();
                        if (!H(r) && !B(r) && !D(r)) throw new TypeError();
                        return D(r) && (r = void 0), n = V(n), _(e, t, n, r);
                    }
                    function g(e, t) {
                        function n(n, r) {
                            if (!H(n)) throw new TypeError();
                            if (!B(r) && !Y(r)) throw new TypeError();
                            N(e, t, n, r);
                        }
                        return n;
                    }
                    function m(e, t, n, r) {
                        if (!H(n)) throw new TypeError();
                        return B(r) || (r = V(r)), N(e, t, n, r);
                    }
                    function y(e, t, n) {
                        if (!H(t)) throw new TypeError();
                        return B(n) || (n = V(n)), x(e, t, n);
                    }
                    function O(e, t, n) {
                        if (!H(t)) throw new TypeError();
                        return B(n) || (n = V(n)), A(e, t, n);
                    }
                    function w(e, t, n) {
                        if (!H(t)) throw new TypeError();
                        return B(n) || (n = V(n)), I(e, t, n);
                    }
                    function j(e, t, n) {
                        if (!H(t)) throw new TypeError();
                        return B(n) || (n = V(n)), L(e, t, n);
                    }
                    function k(e, t) {
                        if (!H(e)) throw new TypeError();
                        return B(t) || (t = V(t)), R(e, t);
                    }
                    function T(e, t) {
                        if (!H(e)) throw new TypeError();
                        return B(t) || (t = V(t)), F(e, t);
                    }
                    function C(e, t, n) {
                        if (!H(t)) throw new TypeError();
                        B(n) || (n = V(n));
                        var r = P(t, n, !1);
                        if (B(r)) return !1;
                        if (!r.delete(e)) return !1;
                        if (r.size > 0) return !0;
                        var i = v.get(t);
                        return i.delete(n), i.size > 0 || v.delete(t), !0;
                    }
                    function S(e, t) {
                        for (var n = e.length - 1; n >= 0; --n) {
                            var r = e[n], i = r(t);
                            if (!B(i) && !D(i)) {
                                if (!J(i)) throw new TypeError();
                                t = i;
                            }
                        }
                        return t;
                    }
                    function _(e, t, n, r) {
                        for (var i = e.length - 1; i >= 0; --i) {
                            var o = e[i], a = o(t, n, r);
                            if (!B(a) && !D(a)) {
                                if (!H(a)) throw new TypeError();
                                r = a;
                            }
                        }
                        return r;
                    }
                    function P(e, t, n) {
                        var r = v.get(e);
                        if (B(r)) {
                            if (!n) return;
                            r = new f(), v.set(e, r);
                        }
                        var i = r.get(t);
                        if (B(i)) {
                            if (!n) return;
                            i = new f(), r.set(t, i);
                        }
                        return i;
                    }
                    function x(e, t, n) {
                        var r = A(e, t, n);
                        if (r) return !0;
                        var i = ne(t);
                        return !D(i) && x(e, i, n);
                    }
                    function A(e, t, n) {
                        var r = P(t, n, !1);
                        return !B(r) && z(r.has(e));
                    }
                    function I(e, t, n) {
                        var r = A(e, t, n);
                        if (r) return L(e, t, n);
                        var i = ne(t);
                        return D(i) ? void 0 : I(e, i, n);
                    }
                    function L(e, t, n) {
                        var r = P(t, n, !1);
                        if (!B(r)) return r.get(e);
                    }
                    function N(e, t, n, r) {
                        var i = P(n, r, !0);
                        i.set(e, t);
                    }
                    function R(e, t) {
                        var n = F(e, t), r = ne(e);
                        if (null === r) return n;
                        var i = R(r, t);
                        if (i.length <= 0) return n;
                        if (n.length <= 0) return i;
                        for (var o = new h(), a = [], c = 0, u = n; c < u.length; c++) {
                            var s = u[c], l = o.has(s);
                            l || (o.add(s), a.push(s));
                        }
                        for (var d = 0, f = i; d < f.length; d++) {
                            s = f[d], l = o.has(s);
                            l || (o.add(s), a.push(s));
                        }
                        return a;
                    }
                    function F(e, t) {
                        var n = [], r = P(e, t, !1);
                        if (B(r)) return n;
                        var i = r.keys(), o = Z(i), a = 0;
                        while (1) {
                            var c = ee(o);
                            if (!c) return n.length = a, n;
                            var u = X(c);
                            try {
                                n[a] = u;
                            } catch (e) {
                                try {
                                    te(o);
                                } finally {
                                    throw e;
                                }
                            }
                            a++;
                        }
                    }
                    function M(e) {
                        if (null === e) return 1;
                        switch (Object(E["a"])(e)) {
                          case "undefined":
                            return 0;

                          case "boolean":
                            return 2;

                          case "string":
                            return 3;

                          case "symbol":
                            return 4;

                          case "number":
                            return 5;

                          case "object":
                            return null === e ? 1 : 6;

                          default:
                            return 6;
                        }
                    }
                    function B(e) {
                        return void 0 === e;
                    }
                    function D(e) {
                        return null === e;
                    }
                    function U(e) {
                        return "symbol" === Object(E["a"])(e);
                    }
                    function H(e) {
                        return "object" === Object(E["a"])(e) ? null !== e : "function" === typeof e;
                    }
                    function $(e, t) {
                        switch (M(e)) {
                          case 0:
                            return e;

                          case 1:
                            return e;

                          case 2:
                            return e;

                          case 3:
                            return e;

                          case 4:
                            return e;

                          case 5:
                            return e;
                        }
                        var n = 3 === t ? "string" : 5 === t ? "number" : "default", r = K(e, i);
                        if (void 0 !== r) {
                            var o = r.call(e, n);
                            if (H(o)) throw new TypeError();
                            return o;
                        }
                        return W(e, "default" === n ? "number" : n);
                    }
                    function W(e, t) {
                        if ("string" === t) {
                            var n = e.toString;
                            if (G(n)) {
                                var r = n.call(e);
                                if (!H(r)) return r;
                            }
                            var i = e.valueOf;
                            if (G(i)) {
                                r = i.call(e);
                                if (!H(r)) return r;
                            }
                        } else {
                            i = e.valueOf;
                            if (G(i)) {
                                r = i.call(e);
                                if (!H(r)) return r;
                            }
                            var o = e.toString;
                            if (G(o)) {
                                r = o.call(e);
                                if (!H(r)) return r;
                            }
                        }
                        throw new TypeError();
                    }
                    function z(e) {
                        return !!e;
                    }
                    function q(e) {
                        return "" + e;
                    }
                    function V(e) {
                        var t = $(e, 3);
                        return U(t) ? t : q(t);
                    }
                    function Q(e) {
                        return Array.isArray ? Array.isArray(e) : e instanceof Object ? e instanceof Array : "[object Array]" === Object.prototype.toString.call(e);
                    }
                    function G(e) {
                        return "function" === typeof e;
                    }
                    function J(e) {
                        return "function" === typeof e;
                    }
                    function Y(e) {
                        switch (M(e)) {
                          case 3:
                            return !0;

                          case 4:
                            return !0;

                          default:
                            return !1;
                        }
                    }
                    function K(e, t) {
                        var n = e[t];
                        if (void 0 !== n && null !== n) {
                            if (!G(n)) throw new TypeError();
                            return n;
                        }
                    }
                    function Z(e) {
                        var t = K(e, o);
                        if (!G(t)) throw new TypeError();
                        var n = t.call(e);
                        if (!H(n)) throw new TypeError();
                        return n;
                    }
                    function X(e) {
                        return e.value;
                    }
                    function ee(e) {
                        var t = e.next();
                        return !t.done && t;
                    }
                    function te(e) {
                        var t = e["return"];
                        t && t.call(e);
                    }
                    function ne(e) {
                        var t = Object.getPrototypeOf(e);
                        if ("function" !== typeof e || e === l) return t;
                        if (t !== l) return t;
                        var n = e.prototype, r = n && Object.getPrototypeOf(n);
                        if (null == r || r === Object.prototype) return t;
                        var i = r.constructor;
                        return "function" !== typeof i || i === e ? t : i;
                    }
                    function re() {
                        var e = {}, t = [], n = function() {
                            function e(e, t, n) {
                                this._index = 0, this._keys = e, this._values = t, this._selector = n;
                            }
                            return e.prototype["@@iterator"] = function() {
                                return this;
                            }, e.prototype[o] = function() {
                                return this;
                            }, e.prototype.next = function() {
                                var e = this._index;
                                if (e >= 0 && e < this._keys.length) {
                                    var n = this._selector(this._keys[e], this._values[e]);
                                    return e + 1 >= this._keys.length ? (this._index = -1, this._keys = t, this._values = t) : this._index++, 
                                    {
                                        value: n,
                                        done: !1
                                    };
                                }
                                return {
                                    value: void 0,
                                    done: !0
                                };
                            }, e.prototype.throw = function(e) {
                                throw this._index >= 0 && (this._index = -1, this._keys = t, this._values = t), 
                                e;
                            }, e.prototype.return = function(e) {
                                return this._index >= 0 && (this._index = -1, this._keys = t, this._values = t), 
                                {
                                    value: e,
                                    done: !0
                                };
                            }, e;
                        }();
                        return function() {
                            function t() {
                                this._keys = [], this._values = [], this._cacheKey = e, this._cacheIndex = -2;
                            }
                            return Object.defineProperty(t.prototype, "size", {
                                get: function() {
                                    return this._keys.length;
                                },
                                enumerable: !0,
                                configurable: !0
                            }), t.prototype.has = function(e) {
                                return this._find(e, !1) >= 0;
                            }, t.prototype.get = function(e) {
                                var t = this._find(e, !1);
                                return t >= 0 ? this._values[t] : void 0;
                            }, t.prototype.set = function(e, t) {
                                var n = this._find(e, !0);
                                return this._values[n] = t, this;
                            }, t.prototype.delete = function(t) {
                                var n = this._find(t, !1);
                                if (n >= 0) {
                                    for (var r = this._keys.length, i = n + 1; i < r; i++) this._keys[i - 1] = this._keys[i], 
                                    this._values[i - 1] = this._values[i];
                                    return this._keys.length--, this._values.length--, t === this._cacheKey && (this._cacheKey = e, 
                                    this._cacheIndex = -2), !0;
                                }
                                return !1;
                            }, t.prototype.clear = function() {
                                this._keys.length = 0, this._values.length = 0, this._cacheKey = e, this._cacheIndex = -2;
                            }, t.prototype.keys = function() {
                                return new n(this._keys, this._values, r);
                            }, t.prototype.values = function() {
                                return new n(this._keys, this._values, i);
                            }, t.prototype.entries = function() {
                                return new n(this._keys, this._values, a);
                            }, t.prototype["@@iterator"] = function() {
                                return this.entries();
                            }, t.prototype[o] = function() {
                                return this.entries();
                            }, t.prototype._find = function(e, t) {
                                return this._cacheKey !== e && (this._cacheIndex = this._keys.indexOf(this._cacheKey = e)), 
                                this._cacheIndex < 0 && t && (this._cacheIndex = this._keys.length, this._keys.push(e), 
                                this._values.push(void 0)), this._cacheIndex;
                            }, t;
                        }();
                        function r(e, t) {
                            return e;
                        }
                        function i(e, t) {
                            return t;
                        }
                        function a(e, t) {
                            return [ e, t ];
                        }
                    }
                    function ie() {
                        return function() {
                            function e() {
                                this._map = new f();
                            }
                            return Object.defineProperty(e.prototype, "size", {
                                get: function() {
                                    return this._map.size;
                                },
                                enumerable: !0,
                                configurable: !0
                            }), e.prototype.has = function(e) {
                                return this._map.has(e);
                            }, e.prototype.add = function(e) {
                                return this._map.set(e, e), this;
                            }, e.prototype.delete = function(e) {
                                return this._map.delete(e);
                            }, e.prototype.clear = function() {
                                this._map.clear();
                            }, e.prototype.keys = function() {
                                return this._map.keys();
                            }, e.prototype.values = function() {
                                return this._map.values();
                            }, e.prototype.entries = function() {
                                return this._map.entries();
                            }, e.prototype["@@iterator"] = function() {
                                return this.keys();
                            }, e.prototype[o] = function() {
                                return this.keys();
                            }, e;
                        }();
                    }
                    function oe() {
                        var e = 16, t = s.create(), r = i();
                        return function() {
                            function e() {
                                this._key = i();
                            }
                            return e.prototype.has = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t && s.has(t, this._key);
                            }, e.prototype.get = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t ? s.get(t, this._key) : void 0;
                            }, e.prototype.set = function(e, t) {
                                var n = o(e, !0);
                                return n[this._key] = t, this;
                            }, e.prototype.delete = function(e) {
                                var t = o(e, !1);
                                return void 0 !== t && delete t[this._key];
                            }, e.prototype.clear = function() {
                                this._key = i();
                            }, e;
                        }();
                        function i() {
                            var e;
                            do {
                                e = "@@WeakMap@@" + u();
                            } while (s.has(t, e));
                            return t[e] = !0, e;
                        }
                        function o(e, t) {
                            if (!n.call(e, r)) {
                                if (!t) return;
                                Object.defineProperty(e, r, {
                                    value: s.create()
                                });
                            }
                            return e[r];
                        }
                        function a(e, t) {
                            for (var n = 0; n < t; ++n) e[n] = 255 * Math.random() | 0;
                            return e;
                        }
                        function c(e) {
                            return "function" === typeof Uint8Array ? "undefined" !== typeof crypto ? crypto.getRandomValues(new Uint8Array(e)) : "undefined" !== typeof msCrypto ? msCrypto.getRandomValues(new Uint8Array(e)) : a(new Uint8Array(e), e) : a(new Array(e), e);
                        }
                        function u() {
                            var t = c(e);
                            t[6] = 79 & t[6] | 64, t[8] = 191 & t[8] | 128;
                            for (var n = "", r = 0; r < e; ++r) {
                                var i = t[r];
                                4 !== r && 6 !== r && 8 !== r || (n += "-"), i < 16 && (n += "0"), n += i.toString(16).toLowerCase();
                            }
                            return n;
                        }
                    }
                    function ae(e) {
                        return e.__ = void 0, delete e.__, e;
                    }
                    t("decorate", b), t("metadata", g), t("defineMetadata", m), t("hasMetadata", y), 
                    t("hasOwnMetadata", O), t("getMetadata", w), t("getOwnMetadata", j), t("getMetadataKeys", k), 
                    t("getOwnMetadataKeys", T), t("deleteMetadata", C);
                });
            })(Reflect || (Reflect = {}));
            var x = {
                TaroElement: "TaroElement",
                TaroElementFactory: "Factory<TaroElement>",
                TaroText: "TaroText",
                TaroTextFactory: "Factory<TaroText>",
                TaroNodeImpl: "TaroNodeImpl",
                TaroElementImpl: "TaroElementImpl",
                InnerHTMLImpl: "InnerHTMLImpl",
                insertAdjacentHTMLImpl: "insertAdjacentHTMLImpl",
                getBoundingClientRectImpl: "getBoundingClientRectImpl",
                Hooks: "hooks",
                onRemoveAttribute: "onRemoveAttribute",
                getLifecycle: "getLifecycle",
                getPathIndex: "getPathIndex",
                getEventCenter: "getEventCenter",
                isBubbleEvents: "isBubbleEvents",
                getSpecialNodes: "getSpecialNodes",
                eventCenter: "eventCenter",
                modifyMpEvent: "modifyMpEvent",
                modifyTaroEvent: "modifyTaroEvent",
                batchedEventUpdates: "batchedEventUpdates",
                mergePageInstance: "mergePageInstance",
                createPullDownComponent: "createPullDownComponent",
                getDOMNode: "getDOMNode",
                initNativeApi: "initNativeApi",
                modifyHydrateData: "modifyHydrateData",
                modifySetAttrPayload: "modifySetAttrPayload",
                modifyRmAttrPayload: "modifyRmAttrPayload",
                onAddEvent: "onAddEvent",
                patchElement: "patchElement"
            }, A = "taro-app", I = "小程序 setData", L = "页面初始化", N = "root", R = "html", F = "head", M = "body", B = "app", D = "container", U = "#document", H = "id", $ = "uid", W = "class", z = "style", q = "focus", V = "view", Q = "static-view", G = "pure-view", J = "props", Y = "dataset", K = "object", Z = "value", X = "input", ee = "change", te = "custom-wrapper", ne = "target", re = "currentTarget", ie = "type", oe = "confirm", ae = "timeStamp", ce = "keyCode", ue = "touchmove", se = "Date", le = "setTimeout", de = "catchMove", fe = "catch-view", he = "comment", pe = function() {
                var e = 0;
                return function() {
                    return (e++).toString();
                };
            };
            function ve(e) {
                return 1 === e.nodeType;
            }
            function be(e) {
                return 3 === e.nodeType;
            }
            function ge(e) {
                return e.nodeName === he;
            }
            function me(e) {
                var t = Object.keys(e.props).find(function(e) {
                    return !(/^(class|style|id)$/.test(e) || e.startsWith("data-"));
                });
                return Boolean(t);
            }
            function ye(e, t) {
                var n, r = !1;
                while ((null === e || void 0 === e ? void 0 : e.parentElement) && e.parentElement._path !== N) {
                    if (null === (n = e.parentElement.__handlers[t]) || void 0 === n ? void 0 : n.length) {
                        r = !0;
                        break;
                    }
                    e = e.parentElement;
                }
                return r;
            }
            function Oe(e) {
                switch (e) {
                  case z:
                    return "st";

                  case H:
                    return $;

                  case W:
                    return "cl";

                  default:
                    return e;
                }
            }
            var we = function() {
                function e(t) {
                    Object(j["a"])(this, e), this.__handlers = {}, this.hooks = t;
                }
                return Object(k["a"])(e, [ {
                    key: "addEventListener",
                    value: function(e, t, n) {
                        var r, i;
                        if (null === (i = (r = this.hooks).onAddEvent) || void 0 === i || i.call(r, e, t, n, this), 
                        "regionchange" === e) return this.addEventListener("begin", t, n), void this.addEventListener("end", t, n);
                        e = e.toLowerCase();
                        var o = this.__handlers[e], a = (Boolean(n), !1);
                        if (Object(C["isObject"])(n) && (Boolean(n.capture), a = Boolean(n.once)), a) {
                            var c = function n() {
                                t.apply(this, arguments), this.removeEventListener(e, n);
                            };
                            this.addEventListener(e, c, Object.assign(Object.assign({}, n), {
                                once: !1
                            }));
                        } else Object(C["isArray"])(o) ? o.push(t) : this.__handlers[e] = [ t ];
                    }
                }, {
                    key: "removeEventListener",
                    value: function(e, t) {
                        if (e = e.toLowerCase(), null != t) {
                            var n = this.__handlers[e];
                            if (Object(C["isArray"])(n)) {
                                var r = n.indexOf(t);
                                n.splice(r, 1);
                            }
                        }
                    }
                }, {
                    key: "isAnyEventBinded",
                    value: function() {
                        var e = this.__handlers, t = Object.keys(e).find(function(t) {
                            return e[t].length;
                        });
                        return Boolean(t);
                    }
                } ]), e;
            }();
            function je(e) {
                var t, n, r, i, o = e.nodeName;
                if (be(e)) return i = {}, Object(w["a"])(i, "v", e.nodeValue), Object(w["a"])(i, "nn", o), 
                i;
                var a = (t = {}, Object(w["a"])(t, "nn", o), Object(w["a"])(t, "uid", e.uid), t), c = e.props, u = e.hooks.getSpecialNodes();
                for (var s in !e.isAnyEventBinded() && u.indexOf(o) > -1 && (a["nn"] = "static-".concat(o), 
                o !== V || me(e) || (a["nn"] = G)), c) {
                    var l = Object(C["toCamelCase"])(s);
                    s.startsWith("data-") || s === W || s === z || s === H || l === de || (a[l] = c[s]), 
                    o === V && l === de && !1 !== c[s] && (a["nn"] = fe);
                }
                var d = e.childNodes;
                return d = d.filter(function(e) {
                    return !ge(e);
                }), d.length > 0 ? a["cn"] = d.map(je) : a["cn"] = [], "" !== e.className && (a["cl"] = e.className), 
                "" !== e.cssText && "swiper-item" !== o && (a["st"] = e.cssText), null === (r = (n = e.hooks).modifyHydrateData) || void 0 === r || r.call(n, a), 
                a;
            }
            we = S([ Object(T["d"])(), _(0, Object(T["c"])(x.Hooks)), P("design:paramtypes", [ Object ]) ], we);
            var ke, Ee = new Map();
            (function(e) {
                e["Element"] = "Element", e["Document"] = "Document", e["RootElement"] = "RootElement", 
                e["FormElement"] = "FormElement";
            })(ke || (ke = {}));
            var Te = pe(), Ce = function(e) {
                Object(y["a"])(n, e);
                var t = Object(O["a"])(n);
                function n(e, r, i) {
                    var o;
                    return Object(j["a"])(this, n), o = t.call(this, i), o.parentNode = null, o.childNodes = [], 
                    o.hydrate = function(e) {
                        return function() {
                            return je(e);
                        };
                    }, e.bind(Object(m["a"])(o)), o._getElement = r, o.uid = "_n_".concat(Te()), Ee.set(o.uid, Object(m["a"])(o)), 
                    o;
                }
                return Object(k["a"])(n, [ {
                    key: "_empty",
                    value: function() {
                        while (this.childNodes.length > 0) {
                            var e = this.childNodes[0];
                            e.parentNode = null, Ee.delete(e.uid), this.childNodes.shift();
                        }
                    }
                }, {
                    key: "_root",
                    get: function() {
                        var e;
                        return (null === (e = this.parentNode) || void 0 === e ? void 0 : e._root) || null;
                    }
                }, {
                    key: "findIndex",
                    value: function(e) {
                        var t = this.childNodes.indexOf(e);
                        return Object(C["ensure"])(-1 !== t, "The node to be replaced is not a child of this node."), 
                        t;
                    }
                }, {
                    key: "_path",
                    get: function() {
                        var e = this.parentNode;
                        if (e) {
                            var t = e.childNodes.filter(function(e) {
                                return !ge(e);
                            }), n = t.indexOf(this), r = this.hooks.getPathIndex(n);
                            return "".concat(e._path, ".", "cn", ".").concat(r);
                        }
                        return "";
                    }
                }, {
                    key: "nextSibling",
                    get: function() {
                        var e = this.parentNode;
                        return (null === e || void 0 === e ? void 0 : e.childNodes[e.findIndex(this) + 1]) || null;
                    }
                }, {
                    key: "previousSibling",
                    get: function() {
                        var e = this.parentNode;
                        return (null === e || void 0 === e ? void 0 : e.childNodes[e.findIndex(this) - 1]) || null;
                    }
                }, {
                    key: "parentElement",
                    get: function() {
                        var e = this.parentNode;
                        return 1 === (null === e || void 0 === e ? void 0 : e.nodeType) ? e : null;
                    }
                }, {
                    key: "firstChild",
                    get: function() {
                        return this.childNodes[0] || null;
                    }
                }, {
                    key: "lastChild",
                    get: function() {
                        var e = this.childNodes;
                        return e[e.length - 1] || null;
                    }
                }, {
                    key: "textContent",
                    set: function(e) {
                        if (this._empty(), "" === e) this.enqueueUpdate({
                            path: "".concat(this._path, ".", "cn"),
                            value: function() {
                                return [];
                            }
                        }); else {
                            var t = this._getElement(ke.Document)();
                            this.appendChild(t.createTextNode(e));
                        }
                    }
                }, {
                    key: "insertBefore",
                    value: function(e, t, n) {
                        var r, i = this;
                        if (e.remove(), e.parentNode = this, t) {
                            var o = this.findIndex(t);
                            this.childNodes.splice(o, 0, e), r = n ? {
                                path: e._path,
                                value: this.hydrate(e)
                            } : {
                                path: "".concat(this._path, ".", "cn"),
                                value: function() {
                                    var e = i.childNodes.filter(function(e) {
                                        return !ge(e);
                                    });
                                    return e.map(je);
                                }
                            };
                        } else this.childNodes.push(e), r = {
                            path: e._path,
                            value: this.hydrate(e)
                        };
                        return this.enqueueUpdate(r), Ee.has(e.uid) || Ee.set(e.uid, e), e;
                    }
                }, {
                    key: "appendChild",
                    value: function(e) {
                        this.insertBefore(e);
                    }
                }, {
                    key: "replaceChild",
                    value: function(e, t) {
                        if (t.parentNode === this) return this.insertBefore(e, t, !0), t.remove(!0), t;
                    }
                }, {
                    key: "removeChild",
                    value: function(e, t) {
                        var n = this, r = this.findIndex(e);
                        return this.childNodes.splice(r, 1), t || this.enqueueUpdate({
                            path: "".concat(this._path, ".", "cn"),
                            value: function() {
                                var e = n.childNodes.filter(function(e) {
                                    return !ge(e);
                                });
                                return e.map(je);
                            }
                        }), e.parentNode = null, Ee.delete(e.uid), e;
                    }
                }, {
                    key: "remove",
                    value: function(e) {
                        var t;
                        null === (t = this.parentNode) || void 0 === t || t.removeChild(this, e);
                    }
                }, {
                    key: "hasChildNodes",
                    value: function() {
                        return this.childNodes.length > 0;
                    }
                }, {
                    key: "enqueueUpdate",
                    value: function(e) {
                        var t;
                        null === (t = this._root) || void 0 === t || t.enqueueUpdate(e);
                    }
                }, {
                    key: "cloneNode",
                    value: function() {
                        var e, t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this._getElement(ke.Document)();
                        for (var r in 1 === this.nodeType ? e = n.createElement(this.nodeName) : 3 === this.nodeType && (e = n.createTextNode("")), 
                        this) {
                            var i = this[r];
                            [ J, Y ].includes(r) && Object(E["a"])(i) === K ? e[r] = Object.assign({}, i) : "_value" === r ? e[r] = i : r === z && (e.style._value = Object.assign({}, i._value), 
                            e.style._usedStyleProp = new Set(Array.from(i._usedStyleProp)));
                        }
                        return t && (e.childNodes = this.childNodes.map(function(e) {
                            return e.cloneNode(!0);
                        })), e;
                    }
                }, {
                    key: "contains",
                    value: function(e) {
                        var t = !1;
                        return this.childNodes.some(function(n) {
                            var r = n.uid;
                            if (r === e.uid || r === e.id || n.contains(e)) return t = !0, !0;
                        }), t;
                    }
                }, {
                    key: "ownerDocument",
                    get: function() {
                        var e = this._getElement(ke.Document)();
                        return e;
                    }
                } ]), n;
            }(we);
            Ce = S([ Object(T["d"])(), _(0, Object(T["c"])(x.TaroNodeImpl)), _(1, Object(T["c"])(x.TaroElementFactory)), _(2, Object(T["c"])(x.Hooks)), P("design:paramtypes", [ Function, Function, Function ]) ], Ce);
            var Se = function(e) {
                Object(y["a"])(n, e);
                var t = Object(O["a"])(n);
                function n(e, r, i) {
                    var o;
                    return Object(j["a"])(this, n), o = t.call(this, e, r, i), o.nodeType = 3, o.nodeName = "#text", 
                    o;
                }
                return Object(k["a"])(n, [ {
                    key: "textContent",
                    get: function() {
                        return this._value;
                    },
                    set: function(e) {
                        this._value = e, this.enqueueUpdate({
                            path: "".concat(this._path, ".", "v"),
                            value: e
                        });
                    }
                }, {
                    key: "nodeValue",
                    get: function() {
                        return this._value;
                    },
                    set: function(e) {
                        this.textContent = e;
                    }
                } ]), n;
            }(Ce);
            Se = S([ Object(T["d"])(), _(0, Object(T["c"])(x.TaroNodeImpl)), _(1, Object(T["c"])(x.TaroElementFactory)), _(2, Object(T["c"])(x.Hooks)), P("design:paramtypes", [ Function, Function, Function ]) ], Se);
            var _e = [ "all", "appearance", "blockOverflow", "blockSize", "bottom", "clear", "contain", "content", "continue", "cursor", "direction", "display", "filter", "float", "gap", "height", "inset", "isolation", "left", "letterSpacing", "lightingColor", "markerSide", "mixBlendMode", "opacity", "order", "position", "quotes", "resize", "right", "rowGap", "tabSize", "tableLayout", "top", "userSelect", "verticalAlign", "visibility", "voiceFamily", "volume", "whiteSpace", "widows", "width", "zIndex" ];
            function Pe(e, t, n) {
                !n && _e.push(e), t.forEach(function(t) {
                    _e.push(e + t);
                });
            }
            var xe = "Color", Ae = "Style", Ie = "Width", Le = "Image", Ne = "Size", Re = [ xe, Ae, Ie ], Fe = [ "FitLength", "FitWidth", Le ], Me = [].concat(Fe, [ "Radius" ]), Be = [].concat(Re, Fe), De = [ "EndRadius", "StartRadius" ], Ue = [ "Bottom", "Left", "Right", "Top" ], He = [ "End", "Start" ], $e = [ "Content", "Items", "Self" ], We = [ "BlockSize", "Height", "InlineSize", Ie ], ze = [ "After", "Before" ];
            function qe(e, t) {
                var n = this[t];
                e && this._usedStyleProp.add(t), n !== e && (this._value[t] = e, this._element.enqueueUpdate({
                    path: "".concat(this._element._path, ".", "st"),
                    value: this.cssText
                }));
            }
            function Ve(e) {
                for (var t = {}, n = function(e) {
                    var n = _e[e];
                    t[n] = {
                        get: function() {
                            return this._value[n] || "";
                        },
                        set: function(e) {
                            qe.call(this, e, n);
                        }
                    };
                }, r = 0; r < _e.length; r++) n(r);
                Object.defineProperties(e.prototype, t);
            }
            function Qe(e) {
                return /^--/.test(e);
            }
            Pe("borderBlock", Re), Pe("borderBlockEnd", Re), Pe("borderBlockStart", Re), Pe("outline", [].concat(Re, [ "Offset" ])), 
            Pe("border", [].concat(Re, [ "Boundary", "Break", "Collapse", "Radius", "Spacing" ])), 
            Pe("borderFit", [ "Length", Ie ]), Pe("borderInline", Re), Pe("borderInlineEnd", Re), 
            Pe("borderInlineStart", Re), Pe("borderLeft", Be), Pe("borderRight", Be), Pe("borderTop", Be), 
            Pe("borderBottom", Be), Pe("textDecoration", [ xe, Ae, "Line" ]), Pe("textEmphasis", [ xe, Ae, "Position" ]), 
            Pe("scrollMargin", Ue), Pe("scrollPadding", Ue), Pe("padding", Ue), Pe("margin", [].concat(Ue, [ "Trim" ])), 
            Pe("scrollMarginBlock", He), Pe("scrollMarginInline", He), Pe("scrollPaddingBlock", He), 
            Pe("scrollPaddingInline", He), Pe("gridColumn", He), Pe("gridRow", He), Pe("insetBlock", He), 
            Pe("insetInline", He), Pe("marginBlock", He), Pe("marginInline", He), Pe("paddingBlock", He), 
            Pe("paddingInline", He), Pe("pause", ze), Pe("cue", ze), Pe("mask", [ "Clip", "Composite", Le, "Mode", "Origin", "Position", "Repeat", Ne, "Type" ]), 
            Pe("borderImage", [ "Outset", "Repeat", "Slice", "Source", "Transform", Ie ]), Pe("maskBorder", [ "Mode", "Outset", "Repeat", "Slice", "Source", Ie ]), 
            Pe("font", [ "Family", "FeatureSettings", "Kerning", "LanguageOverride", "MaxSize", "MinSize", "OpticalSizing", "Palette", Ne, "SizeAdjust", "Stretch", Ae, "Weight", "VariationSettings" ]), 
            Pe("fontSynthesis", [ "SmallCaps", Ae, "Weight" ]), Pe("transform", [ "Box", "Origin", Ae ]), 
            Pe("background", [ xe, Le, "Attachment", "BlendMode", "Clip", "Origin", "Position", "Repeat", Ne ]), 
            Pe("listStyle", [ Le, "Position", "Type" ]), Pe("scrollSnap", [ "Align", "Stop", "Type" ]), 
            Pe("grid", [ "Area", "AutoColumns", "AutoFlow", "AutoRows" ]), Pe("gridTemplate", [ "Areas", "Columns", "Rows" ]), 
            Pe("overflow", [ "Block", "Inline", "Wrap", "X", "Y" ]), Pe("transition", [ "Delay", "Duration", "Property", "TimingFunction" ]), 
            Pe("lineStacking", [ "Ruby", "Shift", "Strategy" ]), Pe("color", [ "Adjust", "InterpolationFilters", "Scheme" ]), 
            Pe("textAlign", [ "All", "Last" ]), Pe("page", [ "BreakAfter", "BreakBefore", "BreakInside" ]), 
            Pe("speak", [ "Header", "Numeral", "Punctuation" ]), Pe("animation", [ "Delay", "Direction", "Duration", "FillMode", "IterationCount", "Name", "PlayState", "TimingFunction" ]), 
            Pe("flex", [ "Basis", "Direction", "Flow", "Grow", "Shrink", "Wrap" ]), Pe("offset", [].concat(ze, He, [ "Anchor", "Distance", "Path", "Position", "Rotate" ])), 
            Pe("fontVariant", [ "Alternates", "Caps", "EastAsian", "Emoji", "Ligatures", "Numeric", "Position" ]), 
            Pe("perspective", [ "Origin" ]), Pe("pitch", [ "Range" ]), Pe("clip", [ "Path", "Rule" ]), 
            Pe("flow", [ "From", "Into" ]), Pe("align", [ "Content", "Items", "Self" ], !0), 
            Pe("alignment", [ "Adjust", "Baseline" ], !0), Pe("bookmark", [ "Label", "Level", "State" ], !0), 
            Pe("borderStart", De, !0), Pe("borderEnd", De, !0), Pe("borderCorner", [ "Fit", Le, "ImageTransform" ], !0), 
            Pe("borderTopLeft", Me, !0), Pe("borderTopRight", Me, !0), Pe("borderBottomLeft", Me, !0), 
            Pe("borderBottomRight", Me, !0), Pe("column", [ "s", "Count", "Fill", "Gap", "Rule", "RuleColor", "RuleStyle", "RuleWidth", "Span", Ie ], !0), 
            Pe("break", [].concat(ze, [ "Inside" ]), !0), Pe("wrap", [].concat(ze, [ "Flow", "Inside", "Through" ]), !0), 
            Pe("justify", $e, !0), Pe("place", $e, !0), Pe("max", [].concat(We, [ "Lines" ]), !0), 
            Pe("min", We, !0), Pe("line", [ "Break", "Clamp", "Grid", "Height", "Padding", "Snap" ], !0), 
            Pe("inline", [ "BoxAlign", Ne, "Sizing" ], !0), Pe("text", [ "CombineUpright", "GroupAlign", "Height", "Indent", "Justify", "Orientation", "Overflow", "Shadow", "SpaceCollapse", "SpaceTrim", "Spacing", "Transform", "UnderlinePosition", "Wrap" ], !0), 
            Pe("shape", [ "ImageThreshold", "Inside", "Margin", "Outside" ], !0), Pe("word", [ "Break", "Spacing", "Wrap" ], !0), 
            Pe("nav", [ "Down", "Left", "Right", "Up" ], !0), Pe("object", [ "Fit", "Position" ], !0), 
            Pe("box", [ "DecorationBreak", "Shadow", "Sizing", "Snap" ], !0);
            var Ge = function() {
                function e(t) {
                    Object(j["a"])(this, e), this._element = t, this._usedStyleProp = new Set(), this._value = {};
                }
                return Object(k["a"])(e, [ {
                    key: "setCssVariables",
                    value: function(e) {
                        var t = this;
                        this.hasOwnProperty(e) || Object.defineProperty(this, e, {
                            enumerable: !0,
                            configurable: !0,
                            get: function() {
                                return t._value[e] || "";
                            },
                            set: function(n) {
                                qe.call(t, n, e);
                            }
                        });
                    }
                }, {
                    key: "cssText",
                    get: function() {
                        var e = this, t = "";
                        return this._usedStyleProp.forEach(function(n) {
                            var r = e[n];
                            if (r) {
                                var i = Qe(n) ? n : Object(C["toDashed"])(n);
                                t += "".concat(i, ": ").concat(r, ";");
                            }
                        }), t;
                    },
                    set: function(e) {
                        var t = this;
                        if (null == e && (e = ""), this._usedStyleProp.forEach(function(e) {
                            t.removeProperty(e);
                        }), "" !== e) for (var n = e.split(";"), r = 0; r < n.length; r++) {
                            var i = n[r].trim();
                            if ("" !== i) {
                                var o = i.split(":"), a = Object(g["a"])(o), c = a[0], u = a.slice(1), s = u.join(":");
                                Object(C["isUndefined"])(s) || this.setProperty(c.trim(), s.trim());
                            }
                        }
                    }
                }, {
                    key: "setProperty",
                    value: function(e, t) {
                        "-" === e[0] ? this.setCssVariables(e) : e = Object(C["toCamelCase"])(e), Object(C["isUndefined"])(t) || (null === t || "" === t ? this.removeProperty(e) : this[e] = t);
                    }
                }, {
                    key: "removeProperty",
                    value: function(e) {
                        if (e = Object(C["toCamelCase"])(e), !this._usedStyleProp.has(e)) return "";
                        var t = this[e];
                        return this[e] = "", this._usedStyleProp.delete(e), t;
                    }
                }, {
                    key: "getPropertyValue",
                    value: function(e) {
                        e = Object(C["toCamelCase"])(e);
                        var t = this[e];
                        return t || "";
                    }
                } ]), e;
            }();
            function Je() {
                return !0;
            }
            function Ye(e, t) {
                var n = [], r = null !== t && void 0 !== t ? t : Je, i = e;
                while (i) 1 === i.nodeType && r(i) && n.push(i), i = Ke(i, e);
                return n;
            }
            function Ke(e, t) {
                var n = e.firstChild;
                if (n) return n;
                var r = e;
                do {
                    if (r === t) return null;
                    var i = r.nextSibling;
                    if (i) return i;
                    r = r.parentElement;
                } while (r);
                return null;
            }
            Ve(Ge);
            var Ze = function(e) {
                Object(y["a"])(n, e);
                var t = Object(O["a"])(n);
                function n(e, r) {
                    var i, o;
                    return Object(j["a"])(this, n), o = t.call(this), e.trim().split(/\s+/).forEach(Object(p["a"])((i = Object(m["a"])(o), 
                    Object(v["a"])(n.prototype)), "add", i).bind(Object(m["a"])(o))), o.el = r, o;
                }
                return Object(k["a"])(n, [ {
                    key: "value",
                    get: function() {
                        return Object(h["a"])(this).join(" ");
                    }
                }, {
                    key: "add",
                    value: function(e) {
                        return Object(p["a"])(Object(v["a"])(n.prototype), "add", this).call(this, e), this._update(), 
                        this;
                    }
                }, {
                    key: "length",
                    get: function() {
                        return this.size;
                    }
                }, {
                    key: "remove",
                    value: function(e) {
                        Object(p["a"])(Object(v["a"])(n.prototype), "delete", this).call(this, e), this._update();
                    }
                }, {
                    key: "toggle",
                    value: function(e) {
                        Object(p["a"])(Object(v["a"])(n.prototype), "has", this).call(this, e) ? Object(p["a"])(Object(v["a"])(n.prototype), "delete", this).call(this, e) : Object(p["a"])(Object(v["a"])(n.prototype), "add", this).call(this, e), 
                        this._update();
                    }
                }, {
                    key: "replace",
                    value: function(e, t) {
                        Object(p["a"])(Object(v["a"])(n.prototype), "delete", this).call(this, e), Object(p["a"])(Object(v["a"])(n.prototype), "add", this).call(this, t), 
                        this._update();
                    }
                }, {
                    key: "contains",
                    value: function(e) {
                        return Object(p["a"])(Object(v["a"])(n.prototype), "has", this).call(this, e);
                    }
                }, {
                    key: "toString",
                    value: function() {
                        return this.value;
                    }
                }, {
                    key: "_update",
                    value: function() {
                        this.el.className = this.value;
                    }
                } ]), n;
            }(Object(b["a"])(Set)), Xe = function(e) {
                Object(y["a"])(n, e);
                var t = Object(O["a"])(n);
                function n(e, r, i, o) {
                    var a;
                    return Object(j["a"])(this, n), a = t.call(this, e, r, i), a.props = {}, a.dataset = C["EMPTY_OBJ"], 
                    o.bind(Object(m["a"])(a)), a.nodeType = 1, a.style = new Ge(Object(m["a"])(a)), 
                    i.patchElement(Object(m["a"])(a)), a;
                }
                return Object(k["a"])(n, [ {
                    key: "_stopPropagation",
                    value: function(e) {
                        var t = this;
                        while (t = t.parentNode) {
                            var n = t.__handlers[e.type];
                            if (Object(C["isArray"])(n)) for (var r = n.length; r--; ) {
                                var i = n[r];
                                i._stop = !0;
                            }
                        }
                    }
                }, {
                    key: "id",
                    get: function() {
                        return this.getAttribute(H);
                    },
                    set: function(e) {
                        this.setAttribute(H, e);
                    }
                }, {
                    key: "className",
                    get: function() {
                        return this.getAttribute(W) || "";
                    },
                    set: function(e) {
                        this.setAttribute(W, e);
                    }
                }, {
                    key: "cssText",
                    get: function() {
                        return this.getAttribute(z) || "";
                    }
                }, {
                    key: "classList",
                    get: function() {
                        return new Ze(this.className, this);
                    }
                }, {
                    key: "children",
                    get: function() {
                        return this.childNodes.filter(ve);
                    }
                }, {
                    key: "attributes",
                    get: function() {
                        var e = this.props, t = Object.keys(e), n = this.style.cssText, r = t.map(function(t) {
                            return {
                                name: t,
                                value: e[t]
                            };
                        });
                        return r.concat(n ? {
                            name: z,
                            value: n
                        } : []);
                    }
                }, {
                    key: "textContent",
                    get: function() {
                        for (var e = "", t = this.childNodes, n = 0; n < t.length; n++) e += t[n].textContent;
                        return e;
                    },
                    set: function(e) {
                        Object(f["a"])(Object(v["a"])(n.prototype), "textContent", e, this, !0);
                    }
                }, {
                    key: "hasAttribute",
                    value: function(e) {
                        return !Object(C["isUndefined"])(this.props[e]);
                    }
                }, {
                    key: "hasAttributes",
                    value: function() {
                        return this.attributes.length > 0;
                    }
                }, {
                    key: "focus",
                    value: function() {
                        this.setAttribute(q, !0);
                    }
                }, {
                    key: "blur",
                    value: function() {
                        this.setAttribute(q, !1);
                    }
                }, {
                    key: "setAttribute",
                    value: function(e, t) {
                        var n, r, i = this.nodeName === V && !me(this) && !this.isAnyEventBinded();
                        switch (e) {
                          case z:
                            this.style.cssText = t;
                            break;

                          case H:
                            Ee.delete(this.uid), t = String(t), this.props[e] = this.uid = t, Ee.set(t, this);
                            break;

                          default:
                            this.props[e] = t, e.startsWith("data-") && (this.dataset === C["EMPTY_OBJ"] && (this.dataset = Object.create(null)), 
                            this.dataset[Object(C["toCamelCase"])(e.replace(/^data-/, ""))] = t);
                            break;
                        }
                        e = Oe(e);
                        var o = {
                            path: "".concat(this._path, ".").concat(Object(C["toCamelCase"])(e)),
                            value: t
                        };
                        null === (r = (n = this.hooks).modifySetAttrPayload) || void 0 === r || r.call(n, this, e, o), 
                        this.enqueueUpdate(o), this.nodeName === V && (Object(C["toCamelCase"])(e) === de ? this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: t ? fe : this.isAnyEventBinded() ? V : Q
                        }) : i && me(this) && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: Q
                        }));
                    }
                }, {
                    key: "removeAttribute",
                    value: function(e) {
                        var t, n, r, i, o = this.nodeName === V && me(this) && !this.isAnyEventBinded();
                        if (e === z) this.style.cssText = ""; else {
                            var a = null === (n = (t = this.hooks).onRemoveAttribute) || void 0 === n ? void 0 : n.call(t, this, e);
                            if (a) return;
                            if (!this.props.hasOwnProperty(e)) return;
                            delete this.props[e];
                        }
                        e = Oe(e);
                        var c = {
                            path: "".concat(this._path, ".").concat(Object(C["toCamelCase"])(e)),
                            value: ""
                        };
                        null === (i = (r = this.hooks).modifyRmAttrPayload) || void 0 === i || i.call(r, this, e, c), 
                        this.enqueueUpdate(c), this.nodeName === V && (Object(C["toCamelCase"])(e) === de ? this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: this.isAnyEventBinded() ? V : me(this) ? Q : G
                        }) : o && !me(this) && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: G
                        }));
                    }
                }, {
                    key: "getAttribute",
                    value: function(e) {
                        var t = e === z ? this.style.cssText : this.props[e];
                        return null !== t && void 0 !== t ? t : "";
                    }
                }, {
                    key: "getElementsByTagName",
                    value: function(e) {
                        var t = this;
                        return Ye(this, function(n) {
                            return n.nodeName === e || "*" === e && t !== n;
                        });
                    }
                }, {
                    key: "getElementsByClassName",
                    value: function(e) {
                        return Ye(this, function(t) {
                            var n = t.classList, r = e.trim().split(/\s+/);
                            return r.every(function(e) {
                                return n.has(e);
                            });
                        });
                    }
                }, {
                    key: "dispatchEvent",
                    value: function(e) {
                        var t = e.cancelable, n = this.__handlers[e.type];
                        if (!Object(C["isArray"])(n)) return !1;
                        for (var r = n.length; r--; ) {
                            var i = n[r], o = void 0;
                            if (i._stop ? i._stop = !1 : o = i.call(this, e), (!1 === o || e._end) && t && (e.defaultPrevented = !0), 
                            e._end && e._stop) break;
                        }
                        return e._stop ? this._stopPropagation(e) : e._stop = !0, null != n;
                    }
                }, {
                    key: "addEventListener",
                    value: function(e, t, r) {
                        var i = this.nodeName, o = this.hooks.getSpecialNodes();
                        !this.isAnyEventBinded() && o.indexOf(i) > -1 && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: i
                        }), Object(p["a"])(Object(v["a"])(n.prototype), "addEventListener", this).call(this, e, t, r);
                    }
                }, {
                    key: "removeEventListener",
                    value: function(e, t) {
                        Object(p["a"])(Object(v["a"])(n.prototype), "removeEventListener", this).call(this, e, t);
                        var r = this.nodeName, i = this.hooks.getSpecialNodes();
                        !this.isAnyEventBinded() && i.indexOf(r) > -1 && this.enqueueUpdate({
                            path: "".concat(this._path, ".", "nn"),
                            value: me(this) ? "static-".concat(r) : "pure-".concat(r)
                        });
                    }
                } ]), n;
            }(Ce);
            Xe = S([ Object(T["d"])(), _(0, Object(T["c"])(x.TaroNodeImpl)), _(1, Object(T["c"])(x.TaroElementFactory)), _(2, Object(T["c"])(x.Hooks)), _(3, Object(T["c"])(x.TaroElementImpl)), P("design:paramtypes", [ Function, Function, Function, Function ]) ], Xe);
            var et = Array.isArray, tt = "object" == ("undefined" === typeof r ? "undefined" : Object(E["a"])(r)) && r && r.Object === Object && r, nt = "object" == ("undefined" === typeof self ? "undefined" : Object(E["a"])(self)) && self && self.Object === Object && self, rt = tt || nt || Function("return this")(), it = rt.Symbol, ot = Object.prototype, at = ot.hasOwnProperty, ct = ot.toString, ut = it ? it.toStringTag : void 0;
            function st(e) {
                var t = at.call(e, ut), n = e[ut];
                try {
                    e[ut] = void 0;
                    var r = !0;
                } catch (e) {}
                var i = ct.call(e);
                return r && (t ? e[ut] = n : delete e[ut]), i;
            }
            var lt = Object.prototype, dt = lt.toString;
            function ft(e) {
                return dt.call(e);
            }
            var ht = "[object Null]", pt = "[object Undefined]", vt = it ? it.toStringTag : void 0;
            function bt(e) {
                return null == e ? void 0 === e ? pt : ht : vt && vt in Object(e) ? st(e) : ft(e);
            }
            function gt(e) {
                return null != e && "object" == Object(E["a"])(e);
            }
            var mt = "[object Symbol]";
            function yt(e) {
                return "symbol" == Object(E["a"])(e) || gt(e) && bt(e) == mt;
            }
            var Ot = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, wt = /^\w*$/;
            function jt(e, t) {
                if (et(e)) return !1;
                var n = Object(E["a"])(e);
                return !("number" != n && "symbol" != n && "boolean" != n && null != e && !yt(e)) || (wt.test(e) || !Ot.test(e) || null != t && e in Object(t));
            }
            function kt(e) {
                var t = Object(E["a"])(e);
                return null != e && ("object" == t || "function" == t);
            }
            var Et = "[object AsyncFunction]", Tt = "[object Function]", Ct = "[object GeneratorFunction]", St = "[object Proxy]";
            function _t(e) {
                if (!kt(e)) return !1;
                var t = bt(e);
                return t == Tt || t == Ct || t == Et || t == St;
            }
            var Pt = rt["__core-js_shared__"], xt = function() {
                var e = /[^.]+$/.exec(Pt && Pt.keys && Pt.keys.IE_PROTO || "");
                return e ? "Symbol(src)_1." + e : "";
            }();
            function At(e) {
                return !!xt && xt in e;
            }
            var It = Function.prototype, Lt = It.toString;
            function Nt(e) {
                if (null != e) {
                    try {
                        return Lt.call(e);
                    } catch (e) {}
                    try {
                        return e + "";
                    } catch (e) {}
                }
                return "";
            }
            var Rt = /[\\^$.*+?()[\]{}|]/g, Ft = /^\[object .+?Constructor\]$/, Mt = Function.prototype, Bt = Object.prototype, Dt = Mt.toString, Ut = Bt.hasOwnProperty, Ht = RegExp("^" + Dt.call(Ut).replace(Rt, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
            function $t(e) {
                if (!kt(e) || At(e)) return !1;
                var t = _t(e) ? Ht : Ft;
                return t.test(Nt(e));
            }
            function Wt(e, t) {
                return null == e ? void 0 : e[t];
            }
            function zt(e, t) {
                var n = Wt(e, t);
                return $t(n) ? n : void 0;
            }
            var qt = zt(Object, "create");
            function Vt() {
                this.__data__ = qt ? qt(null) : {}, this.size = 0;
            }
            function Qt(e) {
                var t = this.has(e) && delete this.__data__[e];
                return this.size -= t ? 1 : 0, t;
            }
            var Gt = "__lodash_hash_undefined__", Jt = Object.prototype, Yt = Jt.hasOwnProperty;
            function Kt(e) {
                var t = this.__data__;
                if (qt) {
                    var n = t[e];
                    return n === Gt ? void 0 : n;
                }
                return Yt.call(t, e) ? t[e] : void 0;
            }
            var Zt = Object.prototype, Xt = Zt.hasOwnProperty;
            function en(e) {
                var t = this.__data__;
                return qt ? void 0 !== t[e] : Xt.call(t, e);
            }
            var tn = "__lodash_hash_undefined__";
            function nn(e, t) {
                var n = this.__data__;
                return this.size += this.has(e) ? 0 : 1, n[e] = qt && void 0 === t ? tn : t, this;
            }
            function rn(e) {
                var t = -1, n = null == e ? 0 : e.length;
                this.clear();
                while (++t < n) {
                    var r = e[t];
                    this.set(r[0], r[1]);
                }
            }
            function on() {
                this.__data__ = [], this.size = 0;
            }
            function an(e, t) {
                return e === t || e !== e && t !== t;
            }
            function cn(e, t) {
                var n = e.length;
                while (n--) if (an(e[n][0], t)) return n;
                return -1;
            }
            rn.prototype.clear = Vt, rn.prototype["delete"] = Qt, rn.prototype.get = Kt, rn.prototype.has = en, 
            rn.prototype.set = nn;
            var un = Array.prototype, sn = un.splice;
            function ln(e) {
                var t = this.__data__, n = cn(t, e);
                if (n < 0) return !1;
                var r = t.length - 1;
                return n == r ? t.pop() : sn.call(t, n, 1), --this.size, !0;
            }
            function dn(e) {
                var t = this.__data__, n = cn(t, e);
                return n < 0 ? void 0 : t[n][1];
            }
            function fn(e) {
                return cn(this.__data__, e) > -1;
            }
            function hn(e, t) {
                var n = this.__data__, r = cn(n, e);
                return r < 0 ? (++this.size, n.push([ e, t ])) : n[r][1] = t, this;
            }
            function pn(e) {
                var t = -1, n = null == e ? 0 : e.length;
                this.clear();
                while (++t < n) {
                    var r = e[t];
                    this.set(r[0], r[1]);
                }
            }
            pn.prototype.clear = on, pn.prototype["delete"] = ln, pn.prototype.get = dn, pn.prototype.has = fn, 
            pn.prototype.set = hn;
            var vn = zt(rt, "Map");
            function bn() {
                this.size = 0, this.__data__ = {
                    hash: new rn(),
                    map: new (vn || pn)(),
                    string: new rn()
                };
            }
            function gn(e) {
                var t = Object(E["a"])(e);
                return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e;
            }
            function mn(e, t) {
                var n = e.__data__;
                return gn(t) ? n["string" == typeof t ? "string" : "hash"] : n.map;
            }
            function yn(e) {
                var t = mn(this, e)["delete"](e);
                return this.size -= t ? 1 : 0, t;
            }
            function On(e) {
                return mn(this, e).get(e);
            }
            function wn(e) {
                return mn(this, e).has(e);
            }
            function jn(e, t) {
                var n = mn(this, e), r = n.size;
                return n.set(e, t), this.size += n.size == r ? 0 : 1, this;
            }
            function kn(e) {
                var t = -1, n = null == e ? 0 : e.length;
                this.clear();
                while (++t < n) {
                    var r = e[t];
                    this.set(r[0], r[1]);
                }
            }
            kn.prototype.clear = bn, kn.prototype["delete"] = yn, kn.prototype.get = On, kn.prototype.has = wn, 
            kn.prototype.set = jn;
            var En = "Expected a function";
            function Tn(e, t) {
                if ("function" != typeof e || null != t && "function" != typeof t) throw new TypeError(En);
                var n = function n() {
                    var r = arguments, i = t ? t.apply(this, r) : r[0], o = n.cache;
                    if (o.has(i)) return o.get(i);
                    var a = e.apply(this, r);
                    return n.cache = o.set(i, a) || o, a;
                };
                return n.cache = new (Tn.Cache || kn)(), n;
            }
            Tn.Cache = kn;
            var Cn = 500;
            function Sn(e) {
                var t = Tn(e, function(e) {
                    return n.size === Cn && n.clear(), e;
                }), n = t.cache;
                return t;
            }
            var _n = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, Pn = /\\(\\)?/g, xn = Sn(function(e) {
                var t = [];
                return 46 === e.charCodeAt(0) && t.push(""), e.replace(_n, function(e, n, r, i) {
                    t.push(r ? i.replace(Pn, "$1") : n || e);
                }), t;
            });
            function An(e, t) {
                var n = -1, r = null == e ? 0 : e.length, i = Array(r);
                while (++n < r) i[n] = t(e[n], n, e);
                return i;
            }
            var In = 1 / 0, Ln = it ? it.prototype : void 0, Nn = Ln ? Ln.toString : void 0;
            function Rn(e) {
                if ("string" == typeof e) return e;
                if (et(e)) return An(e, Rn) + "";
                if (yt(e)) return Nn ? Nn.call(e) : "";
                var t = e + "";
                return "0" == t && 1 / e == -In ? "-0" : t;
            }
            function Fn(e) {
                return null == e ? "" : Rn(e);
            }
            function Mn(e, t) {
                return et(e) ? e : jt(e, t) ? [ e ] : xn(Fn(e));
            }
            var Bn = 1 / 0;
            function Dn(e) {
                if ("string" == typeof e || yt(e)) return e;
                var t = e + "";
                return "0" == t && 1 / e == -Bn ? "-0" : t;
            }
            function Un(e, t) {
                t = Mn(t, e);
                var n = 0, r = t.length;
                while (null != e && n < r) e = e[Dn(t[n++])];
                return n && n == r ? e : void 0;
            }
            function Hn(e, t, n) {
                var r = null == e ? void 0 : Un(e, t);
                return void 0 === r ? n : r;
            }
            var $n = {
                prerender: !0,
                debug: !1
            }, Wn = function() {
                function e() {
                    Object(j["a"])(this, e), this.recorder = new Map();
                }
                return Object(k["a"])(e, [ {
                    key: "start",
                    value: function(e) {
                        $n.debug && this.recorder.set(e, Date.now());
                    }
                }, {
                    key: "stop",
                    value: function(e) {
                        if ($n.debug) {
                            var t = Date.now(), n = this.recorder.get(e), r = t - n;
                            console.log("".concat(e, " 时长： ").concat(r, "ms"));
                        }
                    }
                } ]), e;
            }(), zn = new Wn(), qn = pe(), Vn = function(e) {
                Object(y["a"])(n, e);
                var t = Object(O["a"])(n);
                function n(e, r, i, o, a) {
                    var c;
                    return Object(j["a"])(this, n), c = t.call(this, e, r, i, o), c.pendingUpdate = !1, 
                    c.pendingFlush = !1, c.updatePayloads = [], c.updateCallbacks = [], c.ctx = null, 
                    c.nodeName = N, c.eventCenter = a, c;
                }
                return Object(k["a"])(n, [ {
                    key: "_path",
                    get: function() {
                        return N;
                    }
                }, {
                    key: "_root",
                    get: function() {
                        return this;
                    }
                }, {
                    key: "enqueueUpdate",
                    value: function(e) {
                        this.updatePayloads.push(e), this.pendingUpdate || null === this.ctx || this.performUpdate();
                    }
                }, {
                    key: "performUpdate",
                    value: function() {
                        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = arguments.length > 1 ? arguments[1] : void 0;
                        this.pendingUpdate = !0;
                        var r = this.ctx;
                        setTimeout(function() {
                            zn.start(I);
                            var i = Object.create(null), o = new Set(t ? [ "root.cn.[0]", "root.cn[0]" ] : []);
                            while (e.updatePayloads.length > 0) {
                                var a = e.updatePayloads.shift(), c = a.path, u = a.value;
                                c.endsWith("cn") && o.add(c), i[c] = u;
                            }
                            var s = function(e) {
                                o.forEach(function(t) {
                                    e.includes(t) && e !== t && delete i[e];
                                });
                                var t = i[e];
                                Object(C["isFunction"])(t) && (i[e] = t());
                            };
                            for (var l in i) s(l);
                            if (Object(C["isFunction"])(n)) n(i); else {
                                e.pendingUpdate = !1;
                                var d = [], f = {};
                                if (!t) for (var h in i) {
                                    for (var p = h.split("."), v = !1, b = p.length; b > 0; b--) {
                                        var g = p.slice(0, b).join("."), m = Hn(r.__data__ || r.data, g);
                                        if (m && m.nn && m.nn === te) {
                                            var y = m.uid, O = r.selectComponent("#".concat(y)), j = p.slice(b).join(".");
                                            O && (v = !0, d.push({
                                                ctx: r.selectComponent("#".concat(y)),
                                                data: Object(w["a"])({}, "i.".concat(j), i[h])
                                            }));
                                            break;
                                        }
                                    }
                                    v || (f[h] = i[h]);
                                }
                                var k = d.length;
                                if (k) {
                                    var E = "".concat(e._path, "_update_").concat(qn()), T = e.eventCenter, S = 0;
                                    T.once(E, function() {
                                        S++, S === k + 1 && (zn.stop(I), e.pendingFlush || e.flushUpdateCallback(), t && zn.stop(L));
                                    }, T), d.forEach(function(e) {
                                        e.ctx.setData(e.data, function() {
                                            T.trigger(E);
                                        });
                                    }), Object.keys(f).length && r.setData(f, function() {
                                        T.trigger(E);
                                    });
                                } else r.setData(i, function() {
                                    zn.stop(I), e.pendingFlush || e.flushUpdateCallback(), t && zn.stop(L);
                                });
                            }
                        }, 0);
                    }
                }, {
                    key: "enqueueUpdateCallback",
                    value: function(e, t) {
                        this.updateCallbacks.push(function() {
                            t ? e.call(t) : e();
                        });
                    }
                }, {
                    key: "flushUpdateCallback",
                    value: function() {
                        this.pendingFlush = !1;
                        var e = this.updateCallbacks.slice(0);
                        this.updateCallbacks.length = 0;
                        for (var t = 0; t < e.length; t++) e[t]();
                    }
                } ]), n;
            }(Xe);
            Vn = S([ Object(T["d"])(), _(0, Object(T["c"])(x.TaroNodeImpl)), _(1, Object(T["c"])(x.TaroElementFactory)), _(2, Object(T["c"])(x.Hooks)), _(3, Object(T["c"])(x.TaroElementImpl)), _(4, Object(T["c"])(x.eventCenter)), P("design:paramtypes", [ Function, Function, Function, Function, Function ]) ], Vn);
            var Qn = function(e) {
                Object(y["a"])(n, e);
                var t = Object(O["a"])(n);
                function n() {
                    return Object(j["a"])(this, n), t.apply(this, arguments);
                }
                return Object(k["a"])(n, [ {
                    key: "value",
                    get: function() {
                        var e = this.props[Z];
                        return null == e ? "" : e;
                    },
                    set: function(e) {
                        this.setAttribute(Z, e);
                    }
                }, {
                    key: "dispatchEvent",
                    value: function(e) {
                        if (e.mpEvent) {
                            var t = e.mpEvent.detail.value;
                            e.type === ee ? this.props.value = t : e.type === X && (this.value = t);
                        }
                        return Object(p["a"])(Object(v["a"])(n.prototype), "dispatchEvent", this).call(this, e);
                    }
                } ]), n;
            }(Xe), Gn = function() {
                function e(t, n, r) {
                    Object(j["a"])(this, e), this.getDoc = function() {
                        return t(ke.Document)();
                    }, this.innerHTMLImpl = n, this.adjacentImpl = r;
                }
                return Object(k["a"])(e, [ {
                    key: "bind",
                    value: function(e) {
                        this.ctx = e, this.bindInnerHTML(), this.bindAdjacentHTML();
                    }
                }, {
                    key: "bindInnerHTML",
                    value: function() {
                        var e = this.ctx, t = this.innerHTMLImpl, n = this.getDoc;
                        Object.defineProperty(e, "innerHTML", {
                            configurable: !0,
                            enumerable: !0,
                            set: function(r) {
                                Object(C["isFunction"])(t) && t.call(e, e, r, n);
                            },
                            get: function() {
                                return "";
                            }
                        });
                    }
                }, {
                    key: "bindAdjacentHTML",
                    value: function() {
                        var e = this.ctx, t = this.adjacentImpl, n = this.getDoc;
                        e.insertAdjacentHTML = function(r, i) {
                            Object(C["isFunction"])(t) && t.call(e, r, i, n);
                        };
                    }
                } ]), e;
            }();
            Gn = S([ Object(T["d"])(), _(0, Object(T["c"])(x.TaroElementFactory)), _(1, Object(T["c"])(x.InnerHTMLImpl)), _(1, Object(T["f"])()), _(2, Object(T["c"])(x.insertAdjacentHTMLImpl)), _(2, Object(T["f"])()), P("design:paramtypes", [ Function, Function, Function ]) ], Gn);
            var Jn = function() {
                function e(t) {
                    Object(j["a"])(this, e), this.rectImpl = t;
                }
                return Object(k["a"])(e, [ {
                    key: "bind",
                    value: function(e) {
                        this.bindRect(e);
                    }
                }, {
                    key: "bindRect",
                    value: function(e) {
                        var t = this.rectImpl;
                        e.getBoundingClientRect = Object(d["a"])(l.a.mark(function n() {
                            var r, i, o, a = arguments;
                            return l.a.wrap(function(n) {
                                while (1) switch (n.prev = n.next) {
                                  case 0:
                                    if (!Object(C["isFunction"])(t)) {
                                        n.next = 5;
                                        break;
                                    }
                                    for (r = a.length, i = new Array(r), o = 0; o < r; o++) i[o] = a[o];
                                    return n.next = 4, t.apply(e, i);

                                  case 4:
                                    return n.abrupt("return", n.sent);

                                  case 5:
                                    return n.abrupt("return", Promise.resolve(null));

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }));
                    }
                } ]), e;
            }();
            Jn = S([ Object(T["d"])(), _(0, Object(T["c"])(x.getBoundingClientRectImpl)), _(0, Object(T["f"])()), P("design:paramtypes", [ Object ]) ], Jn);
            var Yn = function(e) {
                Object(y["a"])(n, e);
                var t = Object(O["a"])(n);
                function n(e, r, i, o, a) {
                    var c;
                    return Object(j["a"])(this, n), c = t.call(this, e, r, i, o), c._getText = a, c.nodeType = 9, 
                    c.nodeName = U, c;
                }
                return Object(k["a"])(n, [ {
                    key: "createElement",
                    value: function(e) {
                        return e === N ? this._getElement(ke.RootElement)() : C["controlledComponent"].has(e) ? this._getElement(ke.FormElement)(e) : this._getElement(ke.Element)(e);
                    }
                }, {
                    key: "createElementNS",
                    value: function(e, t) {
                        return this.createElement(t);
                    }
                }, {
                    key: "createTextNode",
                    value: function(e) {
                        return this._getText(e);
                    }
                }, {
                    key: "getElementById",
                    value: function(e) {
                        var t = Ee.get(e);
                        return Object(C["isUndefined"])(t) ? null : t;
                    }
                }, {
                    key: "querySelector",
                    value: function(e) {
                        return /^#/.test(e) ? this.getElementById(e.slice(1)) : null;
                    }
                }, {
                    key: "querySelectorAll",
                    value: function() {
                        return [];
                    }
                }, {
                    key: "createComment",
                    value: function() {
                        var e = this._getText("");
                        return e.nodeName = he, e;
                    }
                } ]), n;
            }(Xe);
            function Kn() {
                return {
                    index: 0,
                    column: 0,
                    line: 0
                };
            }
            function Zn(e, t, n) {
                for (var r = e.index, i = e.index = r + n, o = r; o < i; o++) {
                    var a = t.charAt(o);
                    "\n" === a ? (e.line++, e.column = 0) : e.column++;
                }
            }
            function Xn(e, t, n) {
                var r = n - e.index;
                return Zn(e, t, r);
            }
            function er(e) {
                return {
                    index: e.index,
                    line: e.line,
                    column: e.column
                };
            }
            Yn = S([ Object(T["d"])(), _(0, Object(T["c"])(x.TaroNodeImpl)), _(1, Object(T["c"])(x.TaroElementFactory)), _(2, Object(T["c"])(x.Hooks)), _(3, Object(T["c"])(x.TaroElementImpl)), _(4, Object(T["c"])(x.TaroTextFactory)), P("design:paramtypes", [ Function, Function, Function, Function, Function ]) ], Yn);
            var tr = /\s/;
            function nr(e) {
                return tr.test(e);
            }
            var rr = /=/;
            function ir(e) {
                return rr.test(e);
            }
            function or(e) {
                var t = e.toLowerCase();
                return !!$n.html.skipElements.has(t);
            }
            var ar = /[A-Za-z0-9]/;
            function cr(e, t) {
                while (1) {
                    var n = e.indexOf("<", t);
                    if (-1 === n) return n;
                    var r = e.charAt(n + 1);
                    if ("/" === r || "!" === r || ar.test(r)) return n;
                    t = n + 1;
                }
            }
            function ur(e, t, n) {
                if (!nr(n.charAt(e))) return !1;
                for (var r = n.length, i = e - 1; i > t; i--) {
                    var o = n.charAt(i);
                    if (!nr(o)) {
                        if (ir(o)) return !1;
                        break;
                    }
                }
                for (var a = e + 1; a < r; a++) {
                    var c = n.charAt(a);
                    if (!nr(c)) return !ir(c);
                }
            }
            var sr = function() {
                function e(t) {
                    Object(j["a"])(this, e), this.tokens = [], this.position = Kn(), this.html = t;
                }
                return Object(k["a"])(e, [ {
                    key: "scan",
                    value: function() {
                        var e = this.html, t = this.position, n = e.length;
                        while (t.index < n) {
                            var r = t.index;
                            if (this.scanText(), t.index === r) {
                                var i = e.startsWith("!--", r + 1);
                                if (i) this.scanComment(); else {
                                    var o = this.scanTag();
                                    or(o) && this.scanSkipTag(o);
                                }
                            }
                        }
                        return this.tokens;
                    }
                }, {
                    key: "scanText",
                    value: function() {
                        var e = "text", t = this.html, n = this.position, r = cr(t, n.index);
                        if (r !== n.index) {
                            -1 === r && (r = t.length);
                            var i = er(n), o = t.slice(n.index, r);
                            Xn(n, t, r);
                            var a = er(n);
                            this.tokens.push({
                                type: e,
                                content: o,
                                position: {
                                    start: i,
                                    end: a
                                }
                            });
                        }
                    }
                }, {
                    key: "scanComment",
                    value: function() {
                        var e = "comment", t = this.html, n = this.position, r = er(n);
                        Zn(n, t, 4);
                        var i = t.indexOf("--\x3e", n.index), o = i + 3;
                        -1 === i && (i = o = t.length);
                        var a = t.slice(n.index, i);
                        Xn(n, t, o), this.tokens.push({
                            type: e,
                            content: a,
                            position: {
                                start: r,
                                end: er(n)
                            }
                        });
                    }
                }, {
                    key: "scanTag",
                    value: function() {
                        this.scanTagStart();
                        var e = this.scanTagName();
                        return this.scanAttrs(), this.scanTagEnd(), e;
                    }
                }, {
                    key: "scanTagStart",
                    value: function() {
                        var e = "tag-start", t = this.html, n = this.position, r = t.charAt(n.index + 1), i = "/" === r, o = er(n);
                        Zn(n, t, i ? 2 : 1), this.tokens.push({
                            type: e,
                            close: i,
                            position: {
                                start: o
                            }
                        });
                    }
                }, {
                    key: "scanTagEnd",
                    value: function() {
                        var e = "tag-end", t = this.html, n = this.position, r = t.charAt(n.index), i = "/" === r;
                        Zn(n, t, i ? 2 : 1);
                        var o = er(n);
                        this.tokens.push({
                            type: e,
                            close: i,
                            position: {
                                end: o
                            }
                        });
                    }
                }, {
                    key: "scanTagName",
                    value: function() {
                        var e = "tag", t = this.html, n = this.position, r = t.length, i = n.index;
                        while (i < r) {
                            var o = t.charAt(i), a = !(nr(o) || "/" === o || ">" === o);
                            if (a) break;
                            i++;
                        }
                        var c = i + 1;
                        while (c < r) {
                            var u = t.charAt(c), s = !(nr(u) || "/" === u || ">" === u);
                            if (!s) break;
                            c++;
                        }
                        Xn(n, t, c);
                        var l = t.slice(i, c);
                        return this.tokens.push({
                            type: e,
                            content: l
                        }), l;
                    }
                }, {
                    key: "scanAttrs",
                    value: function() {
                        var e = this.html, t = this.position, n = this.tokens, r = t.index, i = null, o = r, a = [], c = e.length;
                        while (r < c) {
                            var u = e.charAt(r);
                            if (i) {
                                var s = u === i;
                                s && (i = null), r++;
                            } else {
                                var l = "/" === u || ">" === u;
                                if (l) {
                                    r !== o && a.push(e.slice(o, r));
                                    break;
                                }
                                if (ur(r, o, e)) r !== o && a.push(e.slice(o, r)), o = r + 1, r++; else {
                                    var d = "'" === u || '"' === u;
                                    d ? (i = u, r++) : r++;
                                }
                            }
                        }
                        Xn(t, e, r);
                        for (var f = a.length, h = "attribute", p = 0; p < f; p++) {
                            var v = a[p], b = v.includes("=");
                            if (b) {
                                var g = a[p + 1];
                                if (g && g.startsWith("=")) {
                                    if (g.length > 1) {
                                        var m = v + g;
                                        n.push({
                                            type: h,
                                            content: m
                                        }), p += 1;
                                        continue;
                                    }
                                    var y = a[p + 2];
                                    if (p += 1, y) {
                                        var O = v + "=" + y;
                                        n.push({
                                            type: h,
                                            content: O
                                        }), p += 1;
                                        continue;
                                    }
                                }
                            }
                            if (v.endsWith("=")) {
                                var w = a[p + 1];
                                if (w && !w.includes("=")) {
                                    var j = v + w;
                                    n.push({
                                        type: h,
                                        content: j
                                    }), p += 1;
                                    continue;
                                }
                                var k = v.slice(0, -1);
                                n.push({
                                    type: h,
                                    content: k
                                });
                            } else n.push({
                                type: h,
                                content: v
                            });
                        }
                    }
                }, {
                    key: "scanSkipTag",
                    value: function(e) {
                        var t = this.html, n = this.position, r = e.toLowerCase(), i = t.length;
                        while (n.index < i) {
                            var o = t.indexOf("</", n.index);
                            if (-1 === o) {
                                this.scanText();
                                break;
                            }
                            Xn(n, t, o);
                            var a = this.scanTag();
                            if (r === a.toLowerCase()) break;
                        }
                    }
                } ]), e;
            }();
            function lr(e, t) {
                for (var n = Object.create(null), r = e.split(","), i = 0; i < r.length; i++) n[r[i]] = !0;
                return t ? function(e) {
                    return !!n[e.toLowerCase()];
                } : function(e) {
                    return !!n[e];
                };
            }
            var dr = {
                img: "image",
                iframe: "web-view"
            }, fr = Object.keys(C["internalComponents"]).map(function(e) {
                return e.toLowerCase();
            }).join(","), hr = lr(fr, !0), pr = lr("a,i,abbr,iframe,select,acronym,slot,small,span,bdi,kbd,strong,big,map,sub,sup,br,mark,mark,meter,template,canvas,textarea,cite,object,time,code,output,u,data,picture,tt,datalist,var,dfn,del,q,em,s,embed,samp,b", !0), vr = lr("address,fieldset,li,article,figcaption,main,aside,figure,nav,blockquote,footer,ol,details,form,p,dialog,h1,h2,h3,h4,h5,h6,pre,dd,header,section,div,hgroup,table,dl,hr,ul,dt", !0);
            function br(e) {
                var t = e.charAt(0), n = e.length - 1, r = '"' === t || "'" === t;
                return r && t === e.charAt(n) ? e.slice(1, n) : e;
            }
            var gr = "{", mr = "}", yr = ".", Or = "#", wr = ">", jr = "~", kr = "+", Er = function() {
                function e() {
                    Object(j["a"])(this, e), this.styles = [];
                }
                return Object(k["a"])(e, [ {
                    key: "extractStyle",
                    value: function(e) {
                        var t = this, n = /<style\s?[^>]*>((.|\n|\s)+?)<\/style>/g, r = e;
                        return r = r.replace(n, function(e, n) {
                            var r = n.trim();
                            return t.stringToSelector(r), "";
                        }), r.trim();
                    }
                }, {
                    key: "stringToSelector",
                    value: function(e) {
                        var t = this, n = e.indexOf(gr), r = function() {
                            var r = e.indexOf(mr), i = e.slice(0, n).trim(), o = e.slice(n + 1, r);
                            o = o.replace(/:(.*);/g, function(e, t) {
                                var n = t.trim().replace(/ +/g, "+++");
                                return ":".concat(n, ";");
                            }), o = o.replace(/ /g, ""), o = o.replace(/\+\+\+/g, " "), /;$/.test(o) || (o += ";"), 
                            i.split(",").forEach(function(e) {
                                var n = t.parseSelector(e);
                                t.styles.push({
                                    content: o,
                                    selectorList: n
                                });
                            }), e = e.slice(r + 1), n = e.indexOf(gr);
                        };
                        while (n > -1) r();
                    }
                }, {
                    key: "parseSelector",
                    value: function(e) {
                        var t = e.trim().replace(/ *([>~+]) */g, " $1").replace(/ +/g, " ").split(" "), n = t.map(function(e) {
                            var t = e.charAt(0), n = {
                                isChild: t === wr,
                                isGeneralSibling: t === jr,
                                isAdjacentSibling: t === kr,
                                tag: null,
                                id: null,
                                class: [],
                                attrs: []
                            };
                            return e = e.replace(/^[>~+]/, ""), e = e.replace(/\[(.+?)\]/g, function(e, t) {
                                var r = t.split("="), i = Object(u["a"])(r, 2), o = i[0], a = i[1], c = -1 === t.indexOf("="), s = {
                                    all: c,
                                    key: o,
                                    value: c ? null : a
                                };
                                return n.attrs.push(s), "";
                            }), e = e.replace(/([.#][A-Za-z0-9-_]+)/g, function(e, t) {
                                return t[0] === Or ? n.id = t.substr(1) : t[0] === yr && n.class.push(t.substr(1)), 
                                "";
                            }), "" !== e && (n.tag = e), n;
                        });
                        return n;
                    }
                }, {
                    key: "matchStyle",
                    value: function(e, t, n) {
                        var r = this, i = Cr(this.styles).reduce(function(i, o, a) {
                            var c = o.content, u = o.selectorList, s = n[a], l = u[s], d = u[s + 1];
                            ((null === d || void 0 === d ? void 0 : d.isGeneralSibling) || (null === d || void 0 === d ? void 0 : d.isAdjacentSibling)) && (l = d, 
                            s += 1, n[a] += 1);
                            var f = r.matchCurrent(e, t, l);
                            if (f && l.isGeneralSibling) {
                                var h = Tr(t);
                                while (h) {
                                    if (h.h5tagName && r.matchCurrent(h.h5tagName, h, u[s - 1])) {
                                        f = !0;
                                        break;
                                    }
                                    h = Tr(h), f = !1;
                                }
                            }
                            if (f && l.isAdjacentSibling) {
                                var p = Tr(t);
                                if (p && p.h5tagName) {
                                    var v = r.matchCurrent(p.h5tagName, p, u[s - 1]);
                                    v || (f = !1);
                                } else f = !1;
                            }
                            if (f) {
                                if (s === u.length - 1) return i + c;
                                s < u.length - 1 && (n[a] += 1);
                            } else l.isChild && s > 0 && (n[a] -= 1, r.matchCurrent(e, t, u[n[a]]) && (n[a] += 1));
                            return i;
                        }, "");
                        return i;
                    }
                }, {
                    key: "matchCurrent",
                    value: function(e, t, n) {
                        if (n.tag && n.tag !== e) return !1;
                        if (n.id && n.id !== t.id) return !1;
                        if (n.class.length) for (var r = t.className.split(" "), i = 0; i < n.class.length; i++) {
                            var o = n.class[i];
                            if (-1 === r.indexOf(o)) return !1;
                        }
                        if (n.attrs.length) for (var a = 0; a < n.attrs.length; a++) {
                            var c = n.attrs[a], u = c.all, s = c.key, l = c.value;
                            if (u && !t.hasAttribute(s)) return !1;
                            var d = t.getAttribute(s);
                            if (d !== br(l || "")) return !1;
                        }
                        return !0;
                    }
                } ]), e;
            }();
            function Tr(e) {
                var t = e.parentElement;
                if (!t) return null;
                var n = e.previousSibling;
                return n ? 1 === n.nodeType ? n : Tr(n) : null;
            }
            function Cr(e) {
                return e.sort(function(e, t) {
                    var n = Sr(e.selectorList), r = Sr(t.selectorList);
                    if (n !== r) return n - r;
                    var i = _r(e.selectorList), o = _r(t.selectorList);
                    if (i !== o) return i - o;
                    var a = Pr(e.selectorList), c = Pr(t.selectorList);
                    return a - c;
                });
            }
            function Sr(e) {
                return e.reduce(function(e, t) {
                    return e + (t.id ? 1 : 0);
                }, 0);
            }
            function _r(e) {
                return e.reduce(function(e, t) {
                    return e + t.class.length + t.attrs.length;
                }, 0);
            }
            function Pr(e) {
                return e.reduce(function(e, t) {
                    return e + (t.tag ? 1 : 0);
                }, 0);
            }
            var xr = {
                li: [ "ul", "ol", "menu" ],
                dt: [ "dl" ],
                dd: [ "dl" ],
                tbody: [ "table" ],
                thead: [ "table" ],
                tfoot: [ "table" ],
                tr: [ "table" ],
                td: [ "table" ]
            };
            function Ar(e, t) {
                var n = xr[e];
                if (n) {
                    var r = t.length - 1;
                    while (r >= 0) {
                        var i = t[r].tagName;
                        if (i === e) break;
                        if (n && n.includes(i)) return !0;
                        r--;
                    }
                }
                return !1;
            }
            function Ir(e) {
                return $n.html.renderHTMLTag ? e : dr[e] ? dr[e] : hr(e) ? e : vr(e) ? "view" : pr(e) ? "text" : "view";
            }
            function Lr(e) {
                var t = "=", n = e.indexOf(t);
                if (-1 === n) return [ e ];
                var r = e.slice(0, n).trim(), i = e.slice(n + t.length).trim();
                return [ r, i ];
            }
            function Nr(e, t, n, r) {
                return e.filter(function(e) {
                    return "comment" !== e.type && ("text" !== e.type || "" !== e.content);
                }).map(function(e) {
                    if ("text" === e.type) {
                        var i = t.createTextNode(e.content);
                        return Object(C["isFunction"])($n.html.transformText) ? $n.html.transformText(i, e) : (null === r || void 0 === r || r.appendChild(i), 
                        i);
                    }
                    var o = t.createElement(Ir(e.tagName));
                    o.h5tagName = e.tagName, null === r || void 0 === r || r.appendChild(o), $n.html.renderHTMLTag || (o.className = "h5-".concat(e.tagName));
                    for (var a = 0; a < e.attributes.length; a++) {
                        var c = e.attributes[a], s = Lr(c), l = Object(u["a"])(s, 2), d = l[0], f = l[1];
                        if ("class" === d) o.className += " " + br(f); else {
                            if ("o" === d[0] && "n" === d[1]) continue;
                            o.setAttribute(d, null == f || br(f));
                        }
                    }
                    var h = n.styleTagParser, p = n.descendantList, v = p.slice(), b = h.matchStyle(e.tagName, o, v);
                    return o.setAttribute("style", b + o.style.cssText), Nr(e.children, t, {
                        styleTagParser: h,
                        descendantList: v
                    }, o), Object(C["isFunction"])($n.html.transformElement) ? $n.html.transformElement(o, e) : o;
                });
            }
            function Rr(e, t) {
                var n = new Er();
                e = n.extractStyle(e);
                var r = new sr(e).scan(), i = {
                    tagName: "",
                    children: [],
                    type: "element",
                    attributes: []
                }, o = {
                    tokens: r,
                    options: $n,
                    cursor: 0,
                    stack: [ i ]
                };
                return Fr(o), Nr(i.children, t, {
                    styleTagParser: n,
                    descendantList: Array(n.styles.length).fill(0)
                });
            }
            function Fr(e) {
                var t = e.tokens, n = e.stack, r = e.cursor, i = t.length, o = n[n.length - 1].children;
                while (r < i) {
                    var a = t[r];
                    if ("tag-start" === a.type) {
                        var c = t[++r];
                        r++;
                        var u = c.content.toLowerCase();
                        if (a.close) {
                            var s = n.length, l = !1;
                            while (--s > -1) if (n[s].tagName === u) {
                                l = !0;
                                break;
                            }
                            while (r < i) {
                                var d = t[r];
                                if ("tag-end" !== d.type) break;
                                r++;
                            }
                            if (l) {
                                n.splice(s);
                                break;
                            }
                        } else {
                            var f = $n.html.closingElements.has(u), h = f;
                            if (h && (h = !Ar(u, n)), h) {
                                var p = n.length - 1;
                                while (p > 0) {
                                    if (u === n[p].tagName) {
                                        n.splice(p);
                                        var v = p - 1;
                                        o = n[v].children;
                                        break;
                                    }
                                    p -= 1;
                                }
                            }
                            var b = [], g = void 0;
                            while (r < i) {
                                if (g = t[r], "tag-end" === g.type) break;
                                b.push(g.content), r++;
                            }
                            r++;
                            var m = [], y = {
                                type: "element",
                                tagName: c.content,
                                attributes: b,
                                children: m
                            };
                            o.push(y);
                            var O = !(g.close || $n.html.voidElements.has(u));
                            if (O) {
                                n.push({
                                    tagName: u,
                                    children: m
                                });
                                var w = {
                                    tokens: t,
                                    cursor: r,
                                    stack: n
                                };
                                Fr(w), r = w.cursor;
                            }
                        }
                    } else o.push(a), r++;
                }
                e.cursor = r;
            }
            function Mr(e, t, n) {
                e.childNodes.forEach(function(t) {
                    e.removeChild(t);
                });
                for (var r = Rr(t, n()), i = 0; i < r.length; i++) e.appendChild(r[i]);
            }
            function Br(e, t, n) {
                for (var r, i, o = Rr(t, n()), a = 0; a < o.length; a++) {
                    var c = o[a];
                    switch (e) {
                      case "beforebegin":
                        null === (r = this.parentNode) || void 0 === r || r.insertBefore(c, this);
                        break;

                      case "afterbegin":
                        this.hasChildNodes() ? this.insertBefore(c, this.childNodes[0]) : this.appendChild(c);
                        break;

                      case "beforeend":
                        this.appendChild(c);
                        break;

                      case "afterend":
                        null === (i = this.parentNode) || void 0 === i || i.appendChild(c);
                        break;
                    }
                }
            }
            $n.html = {
                skipElements: new Set([ "style", "script" ]),
                voidElements: new Set([ "!doctype", "area", "base", "br", "col", "command", "embed", "hr", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr" ]),
                closingElements: new Set([ "html", "head", "body", "p", "dt", "dd", "li", "option", "thead", "th", "tbody", "tr", "td", "tfoot", "colgroup" ]),
                renderHTMLTag: !1
            };
            var Dr = new T["b"](function(e) {
                e(x.InnerHTMLImpl).toFunction(Mr), e(x.insertAdjacentHTMLImpl).toFunction(Br);
            }), Ur = function() {
                function e() {
                    Object(j["a"])(this, e);
                }
                return Object(k["a"])(e, [ {
                    key: "modifyMpEvent",
                    value: function(e) {
                        var t;
                        null === (t = this.modifyMpEventImpls) || void 0 === t || t.forEach(function(t) {
                            return t(e);
                        });
                    }
                }, {
                    key: "modifyTaroEvent",
                    value: function(e, t) {
                        var n;
                        null === (n = this.modifyTaroEventImpls) || void 0 === n || n.forEach(function(n) {
                            return n(e, t);
                        });
                    }
                }, {
                    key: "initNativeApi",
                    value: function(e) {
                        var t;
                        null === (t = this.initNativeApiImpls) || void 0 === t || t.forEach(function(t) {
                            return t(e);
                        });
                    }
                }, {
                    key: "patchElement",
                    value: function(e) {
                        var t;
                        null === (t = this.patchElementImpls) || void 0 === t || t.forEach(function(t) {
                            return t(e);
                        });
                    }
                } ]), e;
            }();
            S([ Object(T["c"])(x.getLifecycle), P("design:type", Function) ], Ur.prototype, "getLifecycle", void 0), 
            S([ Object(T["c"])(x.getPathIndex), P("design:type", Function) ], Ur.prototype, "getPathIndex", void 0), 
            S([ Object(T["c"])(x.getEventCenter), P("design:type", Function) ], Ur.prototype, "getEventCenter", void 0), 
            S([ Object(T["c"])(x.isBubbleEvents), P("design:type", Function) ], Ur.prototype, "isBubbleEvents", void 0), 
            S([ Object(T["c"])(x.getSpecialNodes), P("design:type", Function) ], Ur.prototype, "getSpecialNodes", void 0), 
            S([ Object(T["c"])(x.onRemoveAttribute), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "onRemoveAttribute", void 0), 
            S([ Object(T["c"])(x.batchedEventUpdates), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "batchedEventUpdates", void 0), 
            S([ Object(T["c"])(x.mergePageInstance), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "mergePageInstance", void 0), 
            S([ Object(T["c"])(x.createPullDownComponent), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "createPullDownComponent", void 0), 
            S([ Object(T["c"])(x.getDOMNode), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "getDOMNode", void 0), 
            S([ Object(T["c"])(x.modifyHydrateData), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "modifyHydrateData", void 0), 
            S([ Object(T["c"])(x.modifySetAttrPayload), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "modifySetAttrPayload", void 0), 
            S([ Object(T["c"])(x.modifyRmAttrPayload), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "modifyRmAttrPayload", void 0), 
            S([ Object(T["c"])(x.onAddEvent), Object(T["f"])(), P("design:type", Function) ], Ur.prototype, "onAddEvent", void 0), 
            S([ Object(T["e"])(x.modifyMpEvent), Object(T["f"])(), P("design:type", Array) ], Ur.prototype, "modifyMpEventImpls", void 0), 
            S([ Object(T["e"])(x.modifyTaroEvent), Object(T["f"])(), P("design:type", Array) ], Ur.prototype, "modifyTaroEventImpls", void 0), 
            S([ Object(T["e"])(x.initNativeApi), Object(T["f"])(), P("design:type", Array) ], Ur.prototype, "initNativeApiImpls", void 0), 
            S([ Object(T["e"])(x.patchElement), Object(T["f"])(), P("design:type", Array) ], Ur.prototype, "patchElementImpls", void 0), 
            Ur = S([ Object(T["d"])() ], Ur);
            var Hr = new Set([ "touchstart", "touchmove", "touchcancel", "touchend", "touchforcechange", "tap", "longpress", "longtap", "transitionend", "animationstart", "animationiteration", "animationend" ]), $r = function(e, t) {
                return e[t];
            }, Wr = function(e) {
                return "[".concat(e, "]");
            }, zr = function(e) {
                return new e();
            }, qr = function(e) {
                return Hr.has(e);
            }, Vr = function() {
                return [ "view", "text", "image" ];
            }, Qr = new T["b"](function(e) {
                e(x.getLifecycle).toFunction($r), e(x.getPathIndex).toFunction(Wr), e(x.getEventCenter).toFunction(zr), 
                e(x.isBubbleEvents).toFunction(qr), e(x.getSpecialNodes).toFunction(Vr);
            });
            function Gr(e) {
                var t = Object.keys(C["defaultReconciler"]);
                t.forEach(function(t) {
                    if (t in x) {
                        var n = x[t], r = C["defaultReconciler"][t];
                        Object(C["isArray"])(r) ? r.forEach(function(t) {
                            return e.bind(n).toFunction(t);
                        }) : e.isBound(n) ? e.rebind(n).toFunction(r) : e.bind(n).toFunction(r);
                    }
                });
            }
            var Jr = new T["a"]();
            Jr.bind(x.TaroElement).to(Xe).whenTargetNamed(ke.Element), Jr.bind(x.TaroElement).to(Yn).inSingletonScope().whenTargetNamed(ke.Document), 
            Jr.bind(x.TaroElement).to(Vn).whenTargetNamed(ke.RootElement), Jr.bind(x.TaroElement).to(Qn).whenTargetNamed(ke.FormElement), 
            Jr.bind(x.TaroElementFactory).toFactory(function(e) {
                return function(t) {
                    return function(n) {
                        var r = e.container.getNamed(x.TaroElement, t);
                        return n && (r.nodeName = n), r.tagName = r.nodeName.toUpperCase(), r;
                    };
                };
            }), Jr.bind(x.TaroText).to(Se), Jr.bind(x.TaroTextFactory).toFactory(function(e) {
                return function(t) {
                    var n = e.container.get(x.TaroText);
                    return n._value = t, n;
                };
            }), Jr.bind(x.TaroNodeImpl).to(Gn).inSingletonScope(), Jr.bind(x.TaroElementImpl).to(Jn).inSingletonScope(), 
            Jr.bind(x.Hooks).to(Ur).inSingletonScope(), Jr.load(Dr, Qr), Gr(Jr);
            var Yr = Jr.get(x.Hooks), Kr = Jr.get(x.TaroElementFactory), Zr = Kr(ke.Document)(), Xr = function() {
                function e(t, n, r) {
                    Object(j["a"])(this, e), this._stop = !1, this._end = !1, this.defaultPrevented = !1, 
                    this.timeStamp = Date.now(), this.type = t.toLowerCase(), this.mpEvent = r, this.bubbles = Boolean(n && n.bubbles), 
                    this.cancelable = Boolean(n && n.cancelable);
                }
                return Object(k["a"])(e, [ {
                    key: "stopPropagation",
                    value: function() {
                        this._stop = !0;
                    }
                }, {
                    key: "stopImmediatePropagation",
                    value: function() {
                        this._end = this._stop = !0;
                    }
                }, {
                    key: "preventDefault",
                    value: function() {
                        this.defaultPrevented = !0;
                    }
                }, {
                    key: "target",
                    get: function() {
                        var e, t, n, r = Zr.getElementById(null === (e = this.mpEvent) || void 0 === e ? void 0 : e.target.id);
                        return Object.assign(Object.assign(Object.assign({}, null === (t = this.mpEvent) || void 0 === t ? void 0 : t.target), null === (n = this.mpEvent) || void 0 === n ? void 0 : n.detail), {
                            dataset: null !== r ? r.dataset : C["EMPTY_OBJ"]
                        });
                    }
                }, {
                    key: "currentTarget",
                    get: function() {
                        var e, t, n, r = Zr.getElementById(null === (e = this.mpEvent) || void 0 === e ? void 0 : e.currentTarget.id);
                        return null === r ? this.target : Object.assign(Object.assign(Object.assign({}, null === (t = this.mpEvent) || void 0 === t ? void 0 : t.currentTarget), null === (n = this.mpEvent) || void 0 === n ? void 0 : n.detail), {
                            dataset: r.dataset
                        });
                    }
                } ]), e;
            }();
            function ei(e, t) {
                if ("string" === typeof e) return new Xr(e, {
                    bubbles: !0,
                    cancelable: !0
                });
                var n = new Xr(e.type, {
                    bubbles: !0,
                    cancelable: !0
                }, e);
                for (var r in e) r !== re && r !== ne && r !== ie && r !== ae && (n[r] = e[r]);
                return n.type === oe && (null === t || void 0 === t ? void 0 : t.nodeName) === X && (n[ce] = 13), 
                n;
            }
            var ti = {};
            function ni(e) {
                var t;
                null === (t = Yr.modifyMpEvent) || void 0 === t || t.call(Yr, e), null == e.currentTarget && (e.currentTarget = e.target);
                var n = Zr.getElementById(e.currentTarget.id);
                if (n) {
                    var r = function() {
                        var t, r = ei(e, n);
                        null === (t = Yr.modifyTaroEvent) || void 0 === t || t.call(Yr, r, n), n.dispatchEvent(r);
                    };
                    if ("function" === typeof Yr.batchedEventUpdates) {
                        var i = e.type;
                        !Yr.isBubbleEvents(i) || !ye(n, i) || i === ue && n.props.catchMove ? Yr.batchedEventUpdates(function() {
                            ti[i] && (ti[i].forEach(function(e) {
                                return e();
                            }), delete ti[i]), r();
                        }) : (ti[i] || (ti[i] = [])).push(r);
                    } else r();
                }
            }
            var ri = "undefined" !== typeof i && !!i.scripts, ii = ri ? i : C["EMPTY_OBJ"], oi = ri ? o : C["EMPTY_OBJ"];
            function ai() {
                var e = Jr.get(x.TaroElementFactory), t = e(ke.Document)(), n = t.createElement.bind(t), r = n(R), i = n(F), o = n(M), a = n(B);
                a.id = B;
                var c = n(D);
                return t.appendChild(r), r.appendChild(i), r.appendChild(o), o.appendChild(c), c.appendChild(a), 
                t.documentElement = r, t.head = i, t.body = o, t.createEvent = ei, t;
            }
            var ci, ui = ri ? ii : ai(), si = "Macintosh", li = "Intel Mac OS X 10_14_5", di = "AppleWebKit/534.36 (KHTML, like Gecko) NodeJS/v4.1.0 Chrome/76.0.3809.132 Safari/534.36", fi = ri ? oi.navigator : {
                appCodeName: "Mozilla",
                appName: "Netscape",
                appVersion: "5.0 (" + si + "; " + li + ") " + di,
                cookieEnabled: !0,
                mimeTypes: [],
                onLine: !0,
                platform: "MacIntel",
                plugins: [],
                product: "Taro",
                productSub: "20030107",
                userAgent: "Mozilla/5.0 (" + si + "; " + li + ") " + di,
                vendor: "Joyent",
                vendorSub: ""
            };
            (function() {
                var e;
                "undefined" !== typeof performance && null !== performance && performance.now ? ci = function() {
                    return performance.now();
                } : Date.now ? (ci = function() {
                    return Date.now() - e;
                }, e = Date.now()) : (ci = function() {
                    return new Date().getTime() - e;
                }, e = new Date().getTime());
            })();
            var hi = 0, pi = "undefined" !== typeof a && null !== a ? a : function(e) {
                var t = ci(), n = Math.max(hi + 16, t);
                return setTimeout(function() {
                    e(hi = n);
                }, n - t);
            }, vi = "undefined" !== typeof c && null !== c ? c : clearTimeout;
            function bi(e) {
                return e.style;
            }
            "undefined" !== typeof r && (pi = pi.bind(r), vi = vi.bind(r));
            var gi = ri ? oi : {
                navigator: fi,
                document: ui
            };
            if (!ri) {
                var mi = [].concat(Object(h["a"])(Object.getOwnPropertyNames(r || oi)), Object(h["a"])(Object.getOwnPropertySymbols(r || oi)));
                mi.forEach(function(e) {
                    "atob" !== e && (Object.prototype.hasOwnProperty.call(gi, e) || (gi[e] = r[e]));
                }), ui.defaultView = gi;
            }
            gi.requestAnimationFrame = pi, gi.cancelAnimationFrame = vi, gi.getComputedStyle = bi, 
            gi.addEventListener = function() {}, gi.removeEventListener = function() {}, se in gi || (gi.Date = Date), 
            le in gi || (gi.setTimeout = setTimeout);
            var yi = {
                app: null,
                router: null,
                page: null
            }, Oi = function() {
                return yi;
            }, wi = function() {
                function e(t) {
                    Object(j["a"])(this, e), "undefined" !== typeof t && t.callbacks ? this.callbacks = t.callbacks : this.callbacks = {};
                }
                return Object(k["a"])(e, [ {
                    key: "on",
                    value: function(t, n, r) {
                        var i, o, a, c;
                        if (!n) return this;
                        t = t.split(e.eventSplitter), this.callbacks || (this.callbacks = {});
                        var u = this.callbacks;
                        while (i = t.shift()) c = u[i], o = c ? c.tail : {}, o.next = a = {}, o.context = r, 
                        o.callback = n, u[i] = {
                            tail: a,
                            next: c ? c.next : o
                        };
                        return this;
                    }
                }, {
                    key: "once",
                    value: function(e, t, n) {
                        var r = this, i = function i() {
                            for (var o = arguments.length, a = new Array(o), c = 0; c < o; c++) a[c] = arguments[c];
                            t.apply(r, a), r.off(e, i, n);
                        };
                        return this.on(e, i, n), this;
                    }
                }, {
                    key: "off",
                    value: function(t, n, r) {
                        var i, o, a, c, u, s;
                        if (!(o = this.callbacks)) return this;
                        if (!(t || n || r)) return delete this.callbacks, this;
                        t = t ? t.split(e.eventSplitter) : Object.keys(o);
                        while (i = t.shift()) if (a = o[i], delete o[i], a && (n || r)) {
                            c = a.tail;
                            while ((a = a.next) !== c) u = a.callback, s = a.context, (n && u !== n || r && s !== r) && this.on(i, u, s);
                        }
                        return this;
                    }
                }, {
                    key: "trigger",
                    value: function(t) {
                        var n, r, i, o;
                        if (!(i = this.callbacks)) return this;
                        t = t.split(e.eventSplitter);
                        var a = [].slice.call(arguments, 1);
                        while (n = t.shift()) if (r = i[n]) {
                            o = r.tail;
                            while ((r = r.next) !== o) r.callback.apply(r.context || this, a);
                        }
                        return this;
                    }
                } ]), e;
            }();
            wi.eventSplitter = /\s+/;
            var ji = Jr.get(x.Hooks), ki = ji.getEventCenter(wi);
            Jr.bind(x.eventCenter).toConstantValue(ki);
            var Ei = new Map(), Ti = pe(), Ci = Jr.get(x.Hooks);
            function Si(e, t) {
                var n;
                null === (n = Ci.mergePageInstance) || void 0 === n || n.call(Ci, Ei.get(t), e), 
                Ei.set(t, e);
            }
            function _i(e) {
                return Ei.get(e);
            }
            function Pi(e) {
                return null == e ? "" : "/" === e.charAt(0) ? e : "/" + e;
            }
            function xi(e, t) {
                for (var n = arguments.length, r = new Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) r[i - 2] = arguments[i];
                var o = Ei.get(e);
                if (null != o) {
                    var a = Ci.getLifecycle(o, t);
                    if (Object(C["isArray"])(a)) {
                        var c = a.map(function(e) {
                            return e.apply(o, r);
                        });
                        return c[0];
                    }
                    if (Object(C["isFunction"])(a)) return a.apply(o, r);
                }
            }
            function Ai(e) {
                if (null == e) return "";
                var t = Object.keys(e).map(function(t) {
                    return t + "=" + e[t];
                }).join("&");
                return "" === t ? t : "?" + t;
            }
            function Ii(e, t) {
                var n = e;
                return ri || (n = e + Ai(t)), n;
            }
            function Li(e) {
                return e + ".onReady";
            }
            function Ni(e) {
                return e + ".onShow";
            }
            function Ri(e) {
                return e + ".onHide";
            }
            function Fi(e, t, n, r) {
                var i, o, a = null !== t && void 0 !== t ? t : "taro_page_".concat(Ti()), c = null, u = !1, s = [], l = {
                    onLoad: function(t, n) {
                        var i = this;
                        zn.start(L), yi.page = this, this.config = r || {}, t.$taroTimestamp = Date.now(), 
                        this.$taroPath = Ii(a, t), null == this.$taroParams && (this.$taroParams = Object.assign({}, t));
                        var o = ri ? this.$taroPath : this.route || this.__route__;
                        yi.router = {
                            params: this.$taroParams,
                            path: Pi(o),
                            onReady: Li(a),
                            onShow: Ni(a),
                            onHide: Ri(a)
                        };
                        var l = function() {
                            yi.app.mount(e, i.$taroPath, function() {
                                c = ui.getElementById(i.$taroPath), Object(C["ensure"])(null !== c, "没有找到页面实例。"), 
                                xi(i.$taroPath, "onLoad", i.$taroParams), ri || (c.ctx = i, c.performUpdate(!0, n));
                            });
                        };
                        u ? s.push(l) : l();
                    },
                    onReady: function() {
                        pi(function() {
                            ki.trigger(Li(a));
                        }), xi(this.$taroPath, "onReady"), this.onReady.called = !0;
                    },
                    onUnload: function() {
                        var e = this;
                        u = !0, yi.app.unmount(this.$taroPath, function() {
                            u = !1, Ei.delete(e.$taroPath), c && (c.ctx = null), s.length && (s.forEach(function(e) {
                                return e();
                            }), s = []);
                        });
                    },
                    onShow: function() {
                        yi.page = this, this.config = r || {};
                        var e = ri ? this.$taroPath : this.route || this.__route__;
                        yi.router = {
                            params: this.$taroParams,
                            path: Pi(e),
                            onReady: Li(a),
                            onShow: Ni(a),
                            onHide: Ri(a)
                        }, pi(function() {
                            ki.trigger(Ni(a));
                        }), xi(this.$taroPath, "onShow");
                    },
                    onHide: function() {
                        yi.page = null, yi.router = null, xi(this.$taroPath, "onHide"), ki.trigger(Ri(a));
                    },
                    onPullDownRefresh: function() {
                        return xi(this.$taroPath, "onPullDownRefresh");
                    },
                    onReachBottom: function() {
                        return xi(this.$taroPath, "onReachBottom");
                    },
                    onPageScroll: function(e) {
                        return xi(this.$taroPath, "onPageScroll", e);
                    },
                    onResize: function(e) {
                        return xi(this.$taroPath, "onResize", e);
                    },
                    onTabItemTap: function(e) {
                        return xi(this.$taroPath, "onTabItemTap", e);
                    },
                    onTitleClick: function() {
                        return xi(this.$taroPath, "onTitleClick");
                    },
                    onOptionMenuClick: function() {
                        return xi(this.$taroPath, "onOptionMenuClick");
                    },
                    onPopMenuClick: function() {
                        return xi(this.$taroPath, "onPopMenuClick");
                    },
                    onPullIntercept: function() {
                        return xi(this.$taroPath, "onPullIntercept");
                    },
                    onAddToFavorites: function() {
                        return xi(this.$taroPath, "onAddToFavorites");
                    }
                };
                return (e.onShareAppMessage || (null === (i = e.prototype) || void 0 === i ? void 0 : i.onShareAppMessage) || e.enableShareAppMessage) && (l.onShareAppMessage = function(e) {
                    var t = null === e || void 0 === e ? void 0 : e.target;
                    if (null != t) {
                        var n = t.id, r = ui.getElementById(n);
                        null != r && (e.target.dataset = r.dataset);
                    }
                    return xi(this.$taroPath, "onShareAppMessage", e);
                }), (e.onShareTimeline || (null === (o = e.prototype) || void 0 === o ? void 0 : o.onShareTimeline) || e.enableShareTimeline) && (l.onShareTimeline = function() {
                    return xi(this.$taroPath, "onShareTimeline");
                }), l.eh = ni, Object(C["isUndefined"])(n) || (l.data = n), ri && (l.path = a), 
                l;
            }
            function Mi(e, t, n) {
                var r, i, o, a = null !== t && void 0 !== t ? t : "taro_component_".concat(Ti()), c = null, u = {
                    attached: function() {
                        var t, n = this;
                        zn.start(L);
                        var r = Ii(a, {
                            id: (null === (t = this.getPageId) || void 0 === t ? void 0 : t.call(this)) || Ti()
                        });
                        yi.app.mount(e, r, function() {
                            c = ui.getElementById(r), Object(C["ensure"])(null !== c, "没有找到组件实例。"), xi(r, "onLoad"), 
                            ri || (c.ctx = n, c.performUpdate(!0));
                        });
                    },
                    detached: function() {
                        var e = Ii(a, {
                            id: this.getPageId()
                        });
                        yi.app.unmount(e, function() {
                            Ei.delete(e), c && (c.ctx = null);
                        });
                    },
                    methods: {
                        eh: ni
                    }
                };
                return Object(C["isUndefined"])(n) || (u.data = n), u["options"] = null !== (r = null === e || void 0 === e ? void 0 : e["options"]) && void 0 !== r ? r : C["EMPTY_OBJ"], 
                u["externalClasses"] = null !== (i = null === e || void 0 === e ? void 0 : e["externalClasses"]) && void 0 !== i ? i : C["EMPTY_OBJ"], 
                u["behaviors"] = null !== (o = null === e || void 0 === e ? void 0 : e["behaviors"]) && void 0 !== o ? o : C["EMPTY_OBJ"], 
                u;
            }
            function Bi(e) {
                return {
                    properties: {
                        i: {
                            type: Object,
                            value: Object(w["a"])({}, "nn", "view")
                        },
                        l: {
                            type: String,
                            value: ""
                        }
                    },
                    options: {
                        addGlobalClass: !0,
                        virtualHost: "custom-wrapper" !== e
                    },
                    methods: {
                        eh: ni
                    }
                };
            }
            var Di = Jr.get(x.Hooks);
            function Ui(e, t) {
                var n;
                return Object(C["isFunction"])(t.render) || !!(null === (n = t.prototype) || void 0 === n ? void 0 : n.isReactComponent) || t.prototype instanceof e.Component;
            }
            var Hi, $i = C["EMPTY_OBJ"], Wi = C["EMPTY_OBJ"];
            function zi(e, t) {
                var n = e.createElement;
                return function(r) {
                    var i = Ui(e, r), o = function(e) {
                        return e && Si(e, t);
                    }, a = i ? {
                        ref: o
                    } : {
                        forwardedRef: o,
                        reactReduxForwardedRef: o
                    };
                    return Wi === C["EMPTY_OBJ"] && (Wi = e.createContext("")), function(e) {
                        Object(y["a"])(o, e);
                        var i = Object(O["a"])(o);
                        function o() {
                            var e;
                            return Object(j["a"])(this, o), e = i.apply(this, arguments), e.state = {
                                hasError: !1
                            }, e;
                        }
                        return Object(k["a"])(o, [ {
                            key: "componentDidCatch",
                            value: function(e, t) {}
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.state.hasError ? [] : n(Wi.Provider, {
                                    value: t
                                }, n(r, Object.assign(Object.assign({}, this.props), a)));
                                return ri ? n("div", {
                                    id: t,
                                    className: "taro_page"
                                }, e) : n("root", {
                                    id: t
                                }, e);
                            }
                        } ], [ {
                            key: "getDerivedStateFromError",
                            value: function(e) {
                                return {
                                    hasError: !0
                                };
                            }
                        } ]), o;
                    }(e.Component);
                };
            }
            function qi() {
                var e = function(e, t) {
                    return t = t.replace(/^on(Show|Hide)$/, "componentDid$1"), e[t];
                }, t = function(e) {
                    e.type = e.type.replace(/-/g, "");
                }, n = function(e) {
                    Hi.unstable_batchedUpdates(e);
                }, r = function(e, t) {
                    e && t && ("constructor" in e || Object.keys(e).forEach(function(n) {
                        Object(C["isFunction"])(t[n]) ? t[n] = [ t[n] ].concat(Object(h["a"])(e[n])) : t[n] = [].concat(Object(h["a"])(t[n] || []), Object(h["a"])(e[n]));
                    }));
                };
                Di.getLifecycle = e, Di.modifyMpEvent = t, Di.batchedEventUpdates = n, Di.mergePageInstance = r;
            }
            var Vi = pe();
            function Qi(e, t, n, r) {
                $i = t, Hi = n, Object(C["ensure"])(!!Hi, "构建 React/Nerv 项目请把 process.env.FRAMEWORK 设置为 'react'/'nerv' ");
                var i = $i.createRef(), o = Ui($i, e);
                qi();
                var a, c = function(t) {
                    Object(y["a"])(r, t);
                    var n = Object(O["a"])(r);
                    function r() {
                        var e;
                        return Object(j["a"])(this, r), e = n.apply(this, arguments), e.pages = [], e.elements = [], 
                        e;
                    }
                    return Object(k["a"])(r, [ {
                        key: "mount",
                        value: function(e, t, n) {
                            var r = t + Vi(), i = function() {
                                return $i.createElement(e, {
                                    key: r,
                                    tid: t
                                });
                            };
                            this.pages.push(i), this.forceUpdate(n);
                        }
                    }, {
                        key: "unmount",
                        value: function(e, t) {
                            for (var n = 0; n < this.elements.length; n++) {
                                var r = this.elements[n];
                                if (r.props.tid === e) {
                                    this.elements.splice(n, 1);
                                    break;
                                }
                            }
                            this.forceUpdate(t);
                        }
                    }, {
                        key: "render",
                        value: function() {
                            while (this.pages.length > 0) {
                                var t = this.pages.pop();
                                this.elements.push(t());
                            }
                            var n = null;
                            return o && (n = {
                                ref: i
                            }), $i.createElement(e, n, ri ? $i.createElement("div", null, this.elements.slice()) : this.elements.slice());
                        }
                    } ]), r;
                }($i.Component);
                ri || (a = Hi.render($i.createElement(c), ui.getElementById("app")));
                var u = Object.create({
                    render: function(e) {
                        a.forceUpdate(e);
                    },
                    mount: function(e, t, n) {
                        var r = zi($i, t)(e);
                        a.mount(r, t, n);
                    },
                    unmount: function(e, t) {
                        a.unmount(e, t);
                    }
                }, {
                    config: {
                        writable: !0,
                        enumerable: !0,
                        configurable: !0,
                        value: r
                    },
                    onLaunch: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = this;
                            yi.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), ri && (a = Hi.render($i.createElement(c), ui.getElementById("app")));
                            var n = i.current;
                            if (null === n || void 0 === n ? void 0 : n.taroGlobalData) {
                                var r = n.taroGlobalData, o = Object.keys(r), u = Object.getOwnPropertyDescriptors(r);
                                o.forEach(function(e) {
                                    Object.defineProperty(t, e, {
                                        configurable: !0,
                                        enumerable: !0,
                                        get: function() {
                                            return r[e];
                                        },
                                        set: function(t) {
                                            r[e] = t;
                                        }
                                    });
                                }), Object.defineProperties(this, u);
                            }
                            this.$app = n, null != n && Object(C["isFunction"])(n.onLaunch) && n.onLaunch(e);
                        }
                    },
                    onShow: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = i.current;
                            yi.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), null != t && Object(C["isFunction"])(t.componentDidShow) && t.componentDidShow(e), 
                            s("onShow");
                        }
                    },
                    onHide: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = i.current;
                            null != t && Object(C["isFunction"])(t.componentDidHide) && t.componentDidHide(e), 
                            s("onHide");
                        }
                    },
                    onPageNotFound: {
                        enumerable: !0,
                        writable: !0,
                        value: function(e) {
                            var t = i.current;
                            null != t && Object(C["isFunction"])(t.onPageNotFound) && t.onPageNotFound(e);
                        }
                    }
                });
                function s(e) {
                    var t = _i(A);
                    if (t) {
                        var n = i.current, r = Di.getLifecycle(t, e);
                        Array.isArray(r) && r.forEach(function(e) {
                            return e.apply(n);
                        });
                    }
                }
                return yi.app = u, yi.app;
            }
            var Gi, Ji = pe();
            function Yi(e, t) {
                var n = function(t) {
                    Object(y["a"])(r, t);
                    var n = Object(O["a"])(r);
                    function r() {
                        var t;
                        return Object(j["a"])(this, r), t = n.apply(this, arguments), t.root = e.createRef(), 
                        t.ctx = t.props.getCtx(), t;
                    }
                    return Object(k["a"])(r, [ {
                        key: "componentDidMount",
                        value: function() {
                            this.ctx.component = this;
                            var e = this.root.current;
                            e.ctx = this.ctx, e.performUpdate(!0);
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return e.createElement("root", {
                                ref: this.root
                            }, this.props.renderComponent(this.ctx));
                        }
                    } ]), r;
                }(e.Component), r = function(t) {
                    Object(y["a"])(i, t);
                    var r = Object(O["a"])(i);
                    function i() {
                        var e;
                        return Object(j["a"])(this, i), e = r.apply(this, arguments), e.state = {
                            components: []
                        }, e;
                    }
                    return Object(k["a"])(i, [ {
                        key: "componentDidMount",
                        value: function() {
                            yi.app = this;
                        }
                    }, {
                        key: "mount",
                        value: function(t, r, i) {
                            var o = Ui(e, t), a = function(e) {
                                return e && Si(e, r);
                            }, c = o ? {
                                ref: a
                            } : {
                                forwardedRef: a,
                                reactReduxForwardedRef: a
                            }, u = {
                                compId: r,
                                element: e.createElement(n, {
                                    key: r,
                                    getCtx: i,
                                    renderComponent: function(n) {
                                        return e.createElement(t, Object.assign(Object.assign({}, (n.data || (n.data = {})).props), c));
                                    }
                                })
                            };
                            this.setState({
                                components: [].concat(Object(h["a"])(this.state.components), [ u ])
                            });
                        }
                    }, {
                        key: "unmount",
                        value: function(e) {
                            var t = this.state.components, n = t.findIndex(function(t) {
                                return t.compId === e;
                            }), r = [].concat(Object(h["a"])(t.slice(0, n)), Object(h["a"])(t.slice(n + 1)));
                            this.setState({
                                components: r
                            });
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.state.components;
                            return e.map(function(e) {
                                var t = e.element;
                                return t;
                            });
                        }
                    } ]), i;
                }(e.Component);
                qi();
                var i = ui.getElementById("app");
                t.render(e.createElement(r, {}), i);
            }
            function Ki(e, t, n, r) {
                $i = t, Hi = n, qi();
                var i = {
                    properties: {
                        props: {
                            type: null,
                            value: null,
                            observer: function(e, t) {
                                t && this.component.forceUpdate();
                            }
                        }
                    },
                    created: function() {
                        yi.app || Yi($i, Hi);
                    },
                    attached: function() {
                        var t = this;
                        o(), this.compId = Ji(), this.config = r, yi.app.mount(e, this.compId, function() {
                            return t;
                        });
                    },
                    ready: function() {
                        xi(this.compId, "onReady");
                    },
                    detached: function() {
                        yi.app.unmount(this.compId);
                    },
                    pageLifetimes: {
                        show: function() {
                            xi(this.compId, "onShow");
                        },
                        hide: function() {
                            xi(this.compId, "onHide");
                        }
                    },
                    methods: {
                        eh: ni
                    }
                };
                function o() {
                    var e = getCurrentPages(), t = e[e.length - 1];
                    if (yi.page !== t) {
                        yi.page = t;
                        var n = t.route || t.__route__, r = {
                            params: t.options || {},
                            path: Pi(n),
                            onReady: "",
                            onHide: "",
                            onShow: ""
                        };
                        yi.router = r, t.options || Object.defineProperty(t, "options", {
                            enumerable: !0,
                            configurable: !0,
                            get: function() {
                                return this._optionsValue;
                            },
                            set: function(e) {
                                r.params = e, this._optionsValue = e;
                            }
                        });
                    }
                }
                return i;
            }
            function Zi(e, t) {
                return function(n) {
                    var r = e.extend({
                        props: {
                            tid: String
                        },
                        mixins: [ n, {
                            created: function() {
                                Si(this, t);
                            }
                        } ]
                    }), i = {
                        render: function(e) {
                            return e(ri ? "div" : "root", {
                                attrs: {
                                    id: t,
                                    class: ri ? "taro_page" : ""
                                }
                            }, [ e(r, {
                                props: {
                                    tid: t
                                }
                            }) ]);
                        }
                    };
                    return i;
                };
            }
            function Xi() {
                var e = Jr.get(x.Hooks), t = function(e, t) {
                    var n = e.props;
                    if (!n.hasOwnProperty(t) || Object(C["isBoolean"])(n[t])) return e.setAttribute(t, !1), 
                    !0;
                }, n = function(e, t) {
                    return e.$options[t];
                };
                e.onRemoveAttribute = t, e.getLifecycle = n;
            }
            function eo(e, t, n) {
                Gi = t, Object(C["ensure"])(!!Gi, "构建 Vue 项目请把 process.env.FRAMEWORK 设置为 'vue'"), 
                Xi(), Gi.config.getTagNamespace = C["noop"];
                var r, i = [], o = [], a = new Gi({
                    render: function(t) {
                        while (o.length > 0) {
                            var n = o.pop();
                            i.push(n(t));
                        }
                        return t(e, {
                            ref: "app"
                        }, i.slice());
                    },
                    methods: {
                        mount: function(e, t, n) {
                            o.push(function(n) {
                                return n(e, {
                                    key: t
                                });
                            }), this.updateSync(n);
                        },
                        updateSync: function(e) {
                            this._update(this._render(), !1), this.$children.forEach(function(e) {
                                return e._update(e._render(), !1);
                            }), e();
                        },
                        unmount: function(e, t) {
                            for (var n = 0; n < i.length; n++) {
                                var r = i[n];
                                if (r.key === e) {
                                    i.splice(n, 1);
                                    break;
                                }
                            }
                            this.updateSync(t);
                        }
                    }
                });
                ri || a.$mount(ui.getElementById("app"));
                var c = Object.create({
                    mount: function(e, t, n) {
                        var r = Zi(Gi, t)(e);
                        a.mount(r, t, n);
                    },
                    unmount: function(e, t) {
                        a.unmount(e, t);
                    }
                }, {
                    config: {
                        writable: !0,
                        enumerable: !0,
                        configurable: !0,
                        value: n
                    },
                    onLaunch: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            yi.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), ri && a.$mount(ui.getElementById("app")), r = a.$refs.app, null != r && Object(C["isFunction"])(r.$options.onLaunch) && r.$options.onLaunch.call(r, e);
                        }
                    },
                    onShow: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            yi.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e), null != r && Object(C["isFunction"])(r.$options.onShow) && r.$options.onShow.call(r, e);
                        }
                    },
                    onHide: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            null != r && Object(C["isFunction"])(r.$options.onHide) && r.$options.onHide.call(r, e);
                        }
                    }
                });
                return yi.app = c, yi.app;
            }
            function to(e, t) {
                return function(n) {
                    var r, i = {
                        props: {
                            tid: String
                        },
                        created: function() {
                            Si(this, t), this.$nextTick(function() {
                                xi(t, "onShow");
                            });
                        }
                    };
                    if (Object(C["isArray"])(n.mixins)) {
                        var o = n.mixins, a = o.length - 1;
                        (null === (r = o[a].props) || void 0 === r ? void 0 : r.tid) ? n.mixins[a] = i : n.mixins.push(i);
                    } else n.mixins = [ i ];
                    return e(ri ? "div" : "root", {
                        key: t,
                        id: t,
                        class: ri ? "taro_page" : ""
                    }, [ e(Object.assign({}, n), {
                        tid: t
                    }) ]);
                };
            }
            function no() {
                var e = Jr.get(x.Hooks), t = function(e, t) {
                    return e.$options[t];
                }, n = function(e) {
                    e.type = e.type.replace(/-/g, "");
                };
                e.getLifecycle = t, e.modifyMpEvent = n;
            }
            function ro(e, t, n) {
                var r, i = [];
                Object(C["ensure"])(!Object(C["isFunction"])(e._component), "入口组件不支持使用函数式组件"), no(), 
                e._component.render = function() {
                    return i.slice();
                }, ri || (r = e.mount("#app"));
                var o = Object.create({
                    mount: function(e, n, r) {
                        var o = to(t, n)(e);
                        i.push(o), this.updateAppInstance(r);
                    },
                    unmount: function(e, t) {
                        i = i.filter(function(t) {
                            return t.key !== e;
                        }), this.updateAppInstance(t);
                    },
                    updateAppInstance: function(e) {
                        r.$forceUpdate(), r.$nextTick(e);
                    }
                }, {
                    config: {
                        writable: !0,
                        enumerable: !0,
                        configurable: !0,
                        value: n
                    },
                    onLaunch: {
                        writable: !0,
                        enumerable: !0,
                        value: function(t) {
                            var n;
                            yi.router = Object.assign({
                                params: null === t || void 0 === t ? void 0 : t.query
                            }, t), ri && (r = e.mount("#app"));
                            var i = null === (n = null === r || void 0 === r ? void 0 : r.$options) || void 0 === n ? void 0 : n.onLaunch;
                            Object(C["isFunction"])(i) && i.call(r, t);
                        }
                    },
                    onShow: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            var t;
                            yi.router = Object.assign({
                                params: null === e || void 0 === e ? void 0 : e.query
                            }, e);
                            var n = null === (t = null === r || void 0 === r ? void 0 : r.$options) || void 0 === t ? void 0 : t.onShow;
                            Object(C["isFunction"])(n) && n.call(r, e);
                        }
                    },
                    onHide: {
                        writable: !0,
                        enumerable: !0,
                        value: function(e) {
                            var t, n = null === (t = null === r || void 0 === r ? void 0 : r.$options) || void 0 === t ? void 0 : t.onHide;
                            Object(C["isFunction"])(n) && n.call(r, e);
                        }
                    }
                });
                return yi.app = o, yi.app;
            }
            var io = function(e) {
                return function(t) {
                    var n = $i.useContext(Wi) || A, r = $i.useRef(t);
                    r.current !== t && (r.current = t), $i.useLayoutEffect(function() {
                        var t = _i(n), i = !1;
                        null == t && (i = !0, t = Object.create(null)), t = t;
                        var o = function() {
                            return r.current.apply(r, arguments);
                        };
                        return Object(C["isFunction"])(t[e]) ? t[e] = [ t[e], o ] : t[e] = [].concat(Object(h["a"])(t[e] || []), [ o ]), 
                        i && Si(t, n), function() {
                            var t = _i(n), r = t[e];
                            r === o ? t[e] = void 0 : Object(C["isArray"])(r) && (t[e] = r.filter(function(e) {
                                return e !== o;
                            }));
                        };
                    }, []);
                };
            }, oo = io("componentDidShow"), ao = io("componentDidHide"), co = io("onPullDownRefresh"), uo = io("onReachBottom"), so = io("onPageScroll"), lo = io("onResize"), fo = io("onShareAppMessage"), ho = io("onTabItemTap"), po = io("onTitleClick"), vo = io("onOptionMenuClick"), bo = io("onPullIntercept"), go = io("onShareTimeline"), mo = io("onAddToFavorites"), yo = io("onReady"), Oo = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                return e ? yi.router : $i.useMemo(function() {
                    return yi.router;
                }, []);
            }, wo = function() {};
            function jo(e) {
                return null == e ? "" : "/" === e.charAt(0) ? e.slice(1) : e;
            }
            var ko = function(e, t) {
                var n, r, i, o = yi.router, a = function() {
                    setTimeout(function() {
                        t ? e.call(t) : e();
                    }, 1);
                };
                if (null !== o) {
                    var c = null, u = Ii(jo(o.path), o.params);
                    c = ui.getElementById(u), null !== c ? ri ? null !== (i = null === (r = null === (n = c.firstChild) || void 0 === n ? void 0 : n["componentOnReady"]) || void 0 === r ? void 0 : r.call(n).then(function() {
                        a();
                    })) && void 0 !== i || a() : c.enqueueUpdateCallback(e, t) : a();
                } else a();
            };
        }.call(this, n(22), n(27), n(7)["document"], n(7)["window"], n(7)["requestAnimationFrame"], n(7)["cancelAnimationFrame"]);
    }
} ]);