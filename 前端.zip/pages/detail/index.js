(wx["webpackJsonp"] = wx["webpackJsonp"] || []).push([ [ 26 ], {
    243: function(e, t, a) {},
    290: function(e, t, a) {
        "use strict";
        a.r(t);
        var c = a(7), n = a(3), s = a(2), i = a(4), o = a.n(i), r = a(1), u = a(15), l = a(35), b = a(9), j = a(30), O = a(64), h = a(34), d = (a(243), 
        a(5)), p = a(61), g = a(0), f = null, x = function() {
            var e = Object(s["useState"])({}), t = Object(n["a"])(e, 2), a = t[0], c = t[1], x = Object(s["useState"])({}), m = Object(n["a"])(x, 2), w = m[0], S = m[1], _ = Object(s["useState"])(!1), v = Object(n["a"])(_, 2), N = v[0], y = v[1], C = Object(s["useState"])(9), M = Object(n["a"])(C, 2), V = M[0], T = M[1], A = Object(s["useState"])(3), I = Object(n["a"])(A, 2), k = I[0], P = I[1], B = Object(s["useState"])(!1), F = Object(n["a"])(B, 2), R = F[0], D = F[1], J = Object(s["useState"])([ [] ]), L = Object(n["a"])(J, 2), q = L[0], z = L[1], E = Object(s["useState"])(!1), H = Object(n["a"])(E, 2), U = H[0], G = H[1], K = Object(s["useState"])(!1), Q = Object(n["a"])(K, 2), W = Q[0], X = Q[1], Y = Object(s["useState"])({}), Z = Object(n["a"])(Y, 2), $ = Z[0], ee = Z[1], te = Object(s["useState"])({}), ae = Object(n["a"])(te, 2), ce = ae[0], ne = ae[1], se = Object(s["useState"])({}), ie = Object(n["a"])(se, 2), oe = ie[0], re = ie[1], ue = Object(s["useState"])({}), le = Object(n["a"])(ue, 2), be = le[0], je = le[1], Oe = Object(s["useState"])({}), he = Object(n["a"])(Oe, 2), de = he[0], pe = he[1], ge = Object(s["useState"])({}), fe = Object(n["a"])(ge, 2), xe = fe[0], me = fe[1], we = Object(s["useState"])(!1), Se = Object(n["a"])(we, 2), _e = Se[0], ve = Se[1], Ne = Object(s["useState"])(!0), ye = Object(n["a"])(Ne, 2), Ce = ye[0], Me = ye[1];
            Object(i["useShareAppMessage"])(function() {
                var e = o.a.getStorageSync("userInfo"), t = e.uid;
                return {
                    title: oe.share_title ? oe.share_title : w.share_title,
                    path: "/pages/index/index?fuid=".concat(t),
                    imageUrl: "".concat(w.attachurl).concat(oe.share_image ? oe.share_image : w.share_image)
                };
            }), Object(i["useDidHide"])(function() {
                Te();
            });
            var Ve = function(e, t) {
                if (!o.a.getStorageSync("autoCloseMusic")) {
                    var a = "".concat(e.attachurl).concat(t);
                    o.a.downloadFile({
                        url: a
                    }).then(function(e) {
                        var t = e.tempFilePath;
                        f = o.a.createInnerAudioContext(), f.src = t, f.loop = !0, f.play(), f.onPause(function() {
                            Me(!0);
                        }), f.onPlay(function() {
                            Me(!1);
                        });
                    });
                }
            }, Te = function() {
                f && f.paused ? f.play() : f.pause();
            }, Ae = Object(s["useState"])(!1), Ie = Object(n["a"])(Ae, 2), ke = Ie[0], Pe = Ie[1], Be = Object(s["useState"])(""), Fe = Object(n["a"])(Be, 2), Re = Fe[0], De = Fe[1], Je = function(e) {
                De(e), Pe(!0);
            }, Le = Object(i["useRouter"])();
            Object(s["useEffect"])(function() {
                return Object(u["b"])("scope.userInfo", ve), Object(d["f"])(function(e) {
                    qe(e), S(e);
                }), c(Object(u["a"])()), function() {
                    f && f.stop() && f.destroy();
                };
            }, []);
            var qe = function(e) {
                Object(d["d"])({
                    url: "entry/wxapp/details",
                    data: {
                        id: ze()
                    },
                    success: function(t) {
                        t.id;
                        var a = t.base, c = t.page, n = t.batch, s = t.share, i = t.details, o = t.setting;
                        ee(c), me(n), ne(a), re(s), je(i), pe(o), 1 == c["page_box_row_num"] ? (T(9), P(3)) : (T(12), 
                        P(4)), c.page_bg_music && Ve(e, c.page_bg_music), setTimeout(function() {
                            y(!1), Ee(a.status);
                        }, 200);
                    }
                });
            }, ze = function() {
                return Le.params.id;
            }, Ee = function(e) {
                if (1 != e) return D(!0), !1;
                var t = .8, a = 137, c = 185, n = .8;
                3 == k && (n = 1.1);
                for (var s = function(e) {
                    for (var t = e.length, a = 0; a < t; a++) {
                        var c = Math.floor(Math.random() * (t - a)), n = e[c];
                        e[c] = e[a], e[a] = n;
                    }
                    return e;
                }, i = function(e, c) {
                    return (3 == k ? 75 * t : 50 * t) + a * n * t * e + (3 == k ? 70 * c * t : 65 * c * t);
                }, o = function(e, a, c) {
                    return (3 == k ? 50 : 80) * t + a * (3 == k ? 90 : 80) * t - 7 * e * t + 3 * c;
                }, r = function() {
                    var e = Math.floor(10 * Math.random());
                    0 == e && (e = 1);
                    for (var r = new Array(V), u = Math.ceil(Math.random() * e), l = 0; l < e; l++) r[l] = u == l ? {
                        an: !0
                    } : {};
                    var b = s(r);
                    for (var j in b) if (b.hasOwnProperty.call(b, j)) {
                        var O = b[j];
                        if (!O) continue;
                        var h = Math.floor(j / k), d = j % k;
                        b[j].style = {
                            bottom: "".concat(o(j, h, d), "rpx"),
                            left: "".concat(i(d, h), "rpx"),
                            zIndex: k - h,
                            width: "".concat(a * t * n, "rpx"),
                            height: "".concat(c * t * n, "rpx"),
                            position: "absolute"
                        };
                    }
                    return b;
                }, u = [], l = 0; l < 5; l++) u.push(r());
                z(u), D(!0);
            }, He = function() {
                return Object(g["jsxs"])(r["View"], {
                    className: "info",
                    children: [ Object(g["jsxs"])(r["View"], {
                        className: "info-title",
                        children: [ Object(g["jsxs"])(r["View"], {
                            className: "title",
                            children: [ Object(g["jsx"])(r["View"], {
                                className: "text white-shadow",
                                children: ce.title
                            }), ce.price ? Object(g["jsxs"])(r["View"], {
                                className: "price white-shadow",
                                children: [ Object(g["jsx"])(r["Text"], {
                                    className: "r",
                                    children: "￥"
                                }), Object(d["i"])(ce.price) ]
                            }) : null, Object(g["jsx"])(r["View"], {
                                className: "desc white-shadow",
                                children: ce.sub_title
                            }) ]
                        }), Object(g["jsxs"])(r["View"], {
                            className: "right-btns",
                            children: [ Object(g["jsx"])(r["View"], {
                                className: "b",
                                onClick: function() {
                                    return X(!0);
                                },
                                children: "开盒规则"
                            }), 2 == ce.type ? Object(g["jsx"])(r["View"], {
                                className: "c",
                                onClick: function() {
                                    return G(!0);
                                },
                                children: "往期揭晓"
                            }) : null ]
                        }) ]
                    }), 2 == ce.type && xe && 1 == ce.status ? Object(g["jsx"])(r["View"], {
                        className: "num-info",
                        children: Object(g["jsxs"])(r["View"], {
                            className: "i",
                            children: [ "当前进行:", Object(g["jsxs"])(r["Text"], {
                                className: "y",
                                children: [ "第", xe.batch_no, "期" ]
                            }), " ", "本期抽奖剩余：", Object(g["jsxs"])(r["Text"], {
                                className: "y",
                                children: [ xe.stock - xe.sold_num, "个" ]
                            }) ]
                        })
                    }) : null, $.page_banner_image && 1 == ce.status ? Object(g["jsx"])(r["View"], {
                        className: "pic",
                        children: Object(g["jsx"])(r["Image"], {
                            className: "banner-pic",
                            mode: "heightFix",
                            src: "".concat(w.attachurl).concat($.page_banner_image)
                        })
                    }) : null ]
                });
            };
            return Object(g["jsxs"])(r["View"], {
                className: "detail-page",
                style: {
                    paddingTop: "".concat(a.paddingTop, "px"),
                    paddingBottom: "".concat(a.paddingBottom, "px"),
                    backgroundColor: $.page_bg_color,
                    backgroundImage: "url(".concat(w.attachurl).concat($.page_bg_image, ")")
                },
                children: [ Object(g["jsx"])(j["a"], {
                    safeArea: a,
                    bgMp3Pased: Ce,
                    pauseMp3: Te,
                    pageConfig: $
                }), N ? Object(g["jsx"])(b["a"], {
                    fixed: !0
                }) : null, He(), Object(g["jsx"])(O["a"], {
                    boxId: ze(),
                    baseConfig: ce,
                    show: R,
                    list: q,
                    imageConfig: $,
                    userAuth: _e
                }), ce.price ? Object(g["jsx"])(l["a"], {
                    boxId: ze(),
                    userAuth: _e,
                    requestBoxDetails: qe,
                    showOpenBox: Je,
                    showRule: W,
                    detailsConfig: be,
                    settingConfig: de,
                    batchConfig: xe,
                    baseConfig: ce,
                    onRuleClose: function() {
                        return X(!1);
                    },
                    onLogClose: function() {
                        return G(!1);
                    },
                    showLog: U
                }) : null, ke ? Object(g["jsx"])(h["a"], {
                    orderNo: Re,
                    onClose: function() {
                        return Pe(!1);
                    }
                }) : null, Object(g["jsx"])(p["a"], {}) ]
            });
        }, m = x, w = {
            navigationBarTitleText: "",
            navigationStyle: "custom",
            navigationBarTextStyle: "white",
            enableShareAppMessage: !0
        };
        m.enableShareAppMessage = !0;
        Page(Object(c["createPageConfig"])(m, "pages/detail/index", {
            root: {
                cn: []
            }
        }, w || {}));
    }
}, [ [ 290, 0, 2, 1, 3 ] ] ]);