var requireReactExtend = require.config({
    paths: {
        'react': 'https://unpkg.com/react@16/umd/react.production.min', //结尾不写.js
        'react-dom': 'https://unpkg.com/react-dom@16/umd/react-dom.production.min', //结尾不写.js
    },
});
requireReactExtend(['react', 'react-dom'], function(React, ReactDOM) {

    ReactDOM.render(
        React.createElement('p', {}, 'Hello, AMD!'),
        document.getElementById('app')
    );
});